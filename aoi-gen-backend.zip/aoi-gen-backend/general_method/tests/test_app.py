import os
import sys
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

import json
from fastapi.testclient import TestClient

from app.main import app


client = TestClient(app)


def test_gm_gen_post():
    request_body = {
        'dataset_id': 'dataset_id',
        'inputs': [{'image': 'test_image1.bmp'}],
        'execute_on_backend': False,
        'number_gen':5,
        'AdditiveGaussianNoise': [
            {
                "mean": 0.0,
                "sigma": 0.1,
                "per_channel": True
            }
        ],
        'ElasticTransformation': [
            {
                "alpha": 80,
                "sigma": 20
            }
        ],
        'Cutout': [
            {
                "num_min": 1,
                "num_max": 3,
                "block_size": 0.2,
                "squared": False,
            }
        ],
        'Multiply': [
            {
                "value_from": 0.5,
                "value_to" : 1.5,
                "per_channel": 0.5
            }
        ],
        'GaussianBlur': [
            {
                "sigma_from": 0.0,
                "sigma_to": 2.0
            }
        ],
        'CLAHE': [
            {
                "clip_from": 1,
                "clip_to": 7
            }
        ],
        'Affine': [
            {
                "translate_x_from": -0.2,
                "translate_x_to": 0.2,
                "translate_y_from": -0.2,
                "translate_y_to": 0.2,
                "rotate_from": -45,
                "rotate_to": 45,
                "shear_from": -15,
                "shear_to": 15,
                "scale_from": 0.5,
                "scale_to": 1.5,
            }
        ],
    }
    response = client.post('/general_method/generate', json=request_body)
    assert response.status_code == 200
