from datetime import datetime
import logging

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from utils import BaseExecutor, ProgressRouter
from utils.system.gpu import GPUInfoAPIRouter
from utils.system.file_stream import FileStreamingAPIRouter
from .base_model import GeneralMethodInput, GeneralMethodOutput


logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(levelname)s - %(message)s",
    datefmt="%Y-%m-%d %H:%M:%S",
)
app = FastAPI()
app.add_middleware(
    CORSMiddleware,
    allow_origins=['*'],
    allow_credentials=True,
    allow_methods=['*'],
    allow_headers=['*'],
)
app.include_router(GPUInfoAPIRouter().router)
app.include_router(FileStreamingAPIRouter().router)
app.include_router(ProgressRouter().router)
gm_executor = BaseExecutor()


@app.post('/general_method/generate', response_model=GeneralMethodOutput)
def gm_gen_post(gm_gen_input: GeneralMethodInput) -> GeneralMethodOutput:
    """
    generate general method augmentation images
    """
    # set task_id
    task_id = f"GeneralMethod/{datetime.now().strftime('%Y%m%d_%H%M%S')}"
    logging.info("Task ID: %s", task_id)
    # init progress
    gm_executor.init_execution_status(task_id)
    gm_executor.update_execution_status(task_id=task_id, total=gm_gen_input.number_gen, current=0)
    # set dataset_id
    dataset_id = f"{task_id}/gen_images"
    logging.info("Dataset ID: %s", dataset_id)
    if gm_gen_input.dataset_source == 'local':
        gm_executor.create_task_id_folder(dataset_id)

    # save request to disk
    gm_executor.save_to_disk(file=gm_gen_input, task_id=task_id, file_name='gm_gen_input')
    # execute script via command line
    gm_executor.execute(
        execute_script='execute.py', execute_on_backend=gm_gen_input.execute_on_backend,
        task_id=task_id, dataset_id=dataset_id
    )

    # prepare response
    response = GeneralMethodOutput(task_id=task_id, dataset_id=dataset_id, dataset_source=gm_gen_input.dataset_source)
    return response
