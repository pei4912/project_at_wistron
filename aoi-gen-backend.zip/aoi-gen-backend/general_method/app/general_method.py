import imgaug.augmenters as iaa


def check_params_value(params):
    """
    check is there any None values in params

    Args
        params: List
    Return:
        True: if any None
    """
    check = [p for p in params if p is None]
    return len(check) > 0


def fliplr(params):
    """
    https://imgaug.readthedocs.io/en/latest/source/overview/flip.html?highlight=Flip#fliplr
    """
    prob = params['Fliplr'][0].get('prob', None)
    if not check_params_value([prob]):
        aug_fun = iaa.Fliplr(p=prob)
    else:
        aug_fun = None
    return aug_fun  


def flipud(params):
    """
    https://imgaug.readthedocs.io/en/latest/source/overview/flip.html?highlight=Flip#flipud
    """
    prob = params['Flipud'][0].get('prob', None)
    if not check_params_value([prob]):
        aug_fun = iaa.Flipud(p=prob)
    else:
        aug_fun = None
    return aug_fun  


def cut_out(params):
    """
    https://imgaug.readthedocs.io/en/latest/source/overview/arithmetic.html#cutout
    """
    num_min = params['Cutout'][0].get('num_min', None)
    num_max = params['Cutout'][0].get('num_max', None)
    block_size = params['Cutout'][0].get('block_size', None)
    if not check_params_value([num_min, num_max, block_size]):
        aug_fun = iaa.Cutout(
            nb_iterations=(num_min, num_max), size=block_size,
            fill_mode='gaussian', fill_per_channel=True, squared=False
        )
    else:
        aug_fun = None
    return aug_fun


def additive_gaussian_noise(params):
    """
    https://imgaug.readthedocs.io/en/latest/source/overview/arithmetic.html#additivegaussiannoise
    """
    mean = params['AdditiveGaussianNoise'][0].get('mean', None)
    sigma = params['AdditiveGaussianNoise'][0].get('sigma', None)
    per_channel = params['AdditiveGaussianNoise'][0].get('per_channel', None)
    if not check_params_value([mean, sigma, per_channel]):
        aug_fun = iaa.AdditiveGaussianNoise(
            scale=(mean, sigma * 255), per_channel=per_channel
        )
    else:
        aug_fun = None
    return aug_fun


def multiply(params):
    """
    https://imgaug.readthedocs.io/en/latest/source/overview/arithmetic.html#multiply
    """
    value_from = params['Multiply'][0].get('value_from', None)
    value_to = params['Multiply'][0].get('value_to', None)
    per_channel = params['Multiply'][0].get('per_channel', None)
    if not check_params_value([value_from, value_to, per_channel]):
        aug_fun = iaa.Multiply(
            (value_from, value_to),
            per_channel=per_channel
        )
    else:
        aug_fun = None
    return aug_fun


def gaussian_blur(params):
    """
    https://imgaug.readthedocs.io/en/latest/source/overview/blur.html#gaussianblur
    """
    sigma_from = params['GaussianBlur'][0].get('sigma_from', None)
    sigma_to = params['GaussianBlur'][0].get('sigma_to', None)
    if not check_params_value([sigma_from, sigma_to]):
        aug_fun = iaa.GaussianBlur(
            sigma=(sigma_from, sigma_to)
        )
    else:
        aug_fun = None
    return aug_fun


def clahe(params):
    """
    https://imgaug.readthedocs.io/en/latest/source/overview/contrast.html#clahe
    """
    clip_from = params['CLAHE'][0].get('clip_from', None)
    clip_to = params['CLAHE'][0].get('clip_to', None)
    if not check_params_value([clip_from, clip_to]):
        aug_fun = iaa.CLAHE(
            clip_limit=(clip_from, clip_to)
        )
    else:
        aug_fun = None
    return aug_fun


def affine_translate(params, mode='edge'):
    """
    https://imgaug.readthedocs.io/en/latest/source/overview/geometric.html#affine

    Args:
        mode: edge or constant
            edge: for full image, uniform sample from (0, 255)
            constant: for crop image, constant: 0
    """
    translate_x_from = params['Affine'][0].get('translate_x_from', None)
    translate_x_to = params['Affine'][0].get('translate_x_to', None)
    translate_y_from = params['Affine'][0].get('translate_y_from', None)
    translate_y_to = params['Affine'][0].get('translate_y_to', None)
    if not check_params_value([translate_x_from, translate_x_to, translate_y_from, translate_y_to]):
        aug_fun = iaa.Affine(
            translate_percent={
                'x': (translate_x_from, translate_x_to),
                'y': (translate_y_from, translate_y_to)
            },
            mode=mode, cval=(0, 255) if mode == 'edge' else 0
        )
    else:
        aug_fun = None
    return aug_fun


def affine_scale(params, mode='edge'):
    """
    https://imgaug.readthedocs.io/en/latest/source/overview/geometric.html#affine

    Args:
        mode: edge or constant
            edge: for full image, uniform sample from (0, 255)
            constant: for crop image, constant: 0
    """
    scale_from = params['Affine'][0].get('scale_from', None)
    scale_to = params['Affine'][0].get('scale_to', None)
    if not check_params_value([scale_from, scale_to]):
        aug_fun = iaa.Affine(
            scale=(scale_from, scale_to),
            mode=mode, cval=(0, 255) if mode == 'edge' else 0
        )
    else:
        aug_fun = None
    return aug_fun


def affine_rotate(params, mode='edge'):
    """
    https://imgaug.readthedocs.io/en/latest/source/overview/geometric.html#affine

    Args:
        mode: edge or constant
            edge: for full image, uniform sample from (0, 255)
            constant: for crop image, constant: 0
    """
    rotate_from = params['Affine'][0].get('rotate_from', None)
    rotate_to = params['Affine'][0].get('rotate_to', None)
    if not check_params_value([rotate_from, rotate_to]):
        aug_fun = iaa.Affine(
            rotate=(rotate_from, rotate_to),
            mode=mode, cval=(0, 255) if mode == 'edge' else 0
        )
    else:
        aug_fun = None
    return aug_fun


def affine_shear(params, mode='edge'):
    """
    https://imgaug.readthedocs.io/en/latest/source/overview/geometric.html#affine

    Args:
        mode: edge or constant
            edge: for full image, uniform sample from (0, 255)
            constant: for crop image, constant: 0
    """
    shear_from = params['Affine'][0].get('shear_from', None)
    shear_to = params['Affine'][0].get('shear_to', None)
    if not check_params_value([shear_from, shear_to]):
        aug_fun = iaa.Affine(
            shear=(shear_from, shear_to),
            mode=mode, cval=(0, 255) if mode == 'edge' else 0
        )
    else:
        aug_fun = None
    return aug_fun  


def general_augment(image, params, mask=None, mode='constant'):
    """
    apply general augment methods to image

    Args:
        image (np.array): [h, w, c], dtype: uint8
        params: dict of list of dict
        {
            'AugMethod1': [{
                'AugParam1',
                'AugParam2'
            }],
            'AugMethod2': [{
                'AugParam1',
                'AugParam2'
            }],
        }
        mask (np.array): [h, w, 1], dtype: uint8
        mode: edge or constant
            edge: for full image, uniform sample from (0, 255)
            constant: for crop image, constant: 0
    Returns:
        aug_image (np.array): [h, w, c], dtype: uint8
        aug_mask (np.array): [h, w, 1], dtype: uint8
    """

    # define augment methods
    aug_funs = []
    for aug_method in [fliplr, flipud, cut_out, additive_gaussian_noise, multiply, gaussian_blur, clahe, affine_translate, affine_scale, affine_rotate, affine_shear]:
        if aug_method in [affine_translate, affine_scale, affine_rotate, affine_shear]:
            aug_fun = aug_method(params, mode=mode)
        else:
            aug_fun = aug_method(params)
        if aug_fun is not None:
            aug_funs.append(aug_fun)
    if len(aug_funs) == 0:
        if mask is None:
            return image
        else:
            return image, mask
    # random order augment methods
    seq = iaa.Sequential(iaa.SomeOf((1, None), aug_funs, random_order=True), random_order=True)

    # apply augment methods
    if mask is not None:
        aug_image, aug_mask = seq(images=image[None], segmentation_maps=mask[None])
        aug_image = aug_image[0]
        aug_mask = aug_mask[0]
        return aug_image, aug_mask
    else:
        aug_image = seq(images=image[None])[0]
        return aug_image
