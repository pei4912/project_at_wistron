from typing import List, Dict
from pydantic import BaseModel

from utils._version import __version__


BaseModel.model_config['protected_namespaces'] = {}


class GeneralMethodInput(BaseModel):
    """
    config request input for general method

    Args:
        dataset_id: load images from $ROOT_FOLDER/dataset_id
        dataset_source: local / minio
            - local: load/save data from/to local disk
            - minio: load/save data from/to minio
        inputs:
        [
            {
                'image': image, as a file name
            }
        ]

        execute_on_backend: execute surface defect process on the backend process
        number_gen: number of generated images

        # parameters for general methods
        Fliplr: https://imgaug.readthedocs.io/en/latest/source/overview/flip.html?highlight=Flip#fliplr
        Flipud: https://imgaug.readthedocs.io/en/latest/source/overview/flip.html?highlight=Flip#flipud
        AdditiveGaussianNoise: https://imgaug.readthedocs.io/en/latest/source/overview/arithmetic.html#additivegaussiannoise
        ElasticTransformation: https://imgaug.readthedocs.io/en/latest/source/overview/geometric.html#elastictransformation
        Cutout: https://imgaug.readthedocs.io/en/latest/source/overview/arithmetic.html#cutout
        Multiply: https://imgaug.readthedocs.io/en/latest/source/overview/arithmetic.html#multiply
        GaussianBlur: https://imgaug.readthedocs.io/en/latest/source/overview/blur.html#gaussianblur
        CLAHE: https://imgaug.readthedocs.io/en/latest/source/overview/contrast.html#clahe
        Affine: https://imgaug.readthedocs.io/en/latest/source/overview/geometric.html#affine
    """
    dataset_id: str
    dataset_source: str = 'local'
    inputs: List[Dict]

    execute_on_backend: bool = True
    number_gen: int = 5

    Fliplr: List[Dict] = [{'prob': None}]
    Flipud: List[Dict] = [{'prob': None}]
    AdditiveGaussianNoise: List[Dict] = [{'mean': None, 'sigma': None, 'per_channel': None}]
    ElasticTransformation: List[Dict] = [{'alpha': None, 'sigma': None}]
    Cutout: List[Dict] = [{'num_min': None, 'sigma': None, 'block_size': None, 'squared': None}]
    Multiply: List[Dict] = [{'value_from': None, 'value_to': None, 'per_channel': None}]
    GaussianBlur: List[Dict] = [{'sigma_from': None, 'sigma_to': None}]
    CLAHE: List[Dict] = [{'clip_from': None, 'clip_to': None}]
    Affine: List[Dict] = [{'translate_x_from': None, 'translate_x_to': None, 'translate_y_from': None, 'translate_y_to': None, 'rotate_from': None, 'rotate_to': None, 'shear_from': None, 'shear_to': None, 'scale_from': None, 'scale_to': None}]    


class GeneralMethodOutput(BaseModel):
    """
    config response output for general method

    Args:
        task_id: folder to save task files
        dataset_id: folder to save dataset
        dataset_source: local or minio
        api_version: the version of api
    """
    task_id: str
    dataset_id: str
    dataset_source: str
    api_version: str = __version__
