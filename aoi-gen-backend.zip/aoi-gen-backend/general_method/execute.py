import os
import argparse
from random import sample
from tqdm import trange
import logging

from PIL import Image

from utils import BaseExecutor, BaseRequestProcessor, BaseResponseProcessor
from app.general_method import general_augment


# parse the commandline
parser = argparse.ArgumentParser()
parser.add_argument('--task-id', '--task_id', required=True, type=str)
parser.add_argument('--dataset-id', '--dataset_id', required=True, type=str)
args = parser.parse_args()


gm_executor = BaseExecutor()
gm_request_processor = BaseRequestProcessor()
gm_response_processor = BaseResponseProcessor()
# load data
gm_gen_input = gm_executor.load_from_disk(task_id=args.task_id, file_name="gm_gen_input")


def main(
    task_id, dataset_id,
    gen_input,
    executor, request_processor, response_processor
):
    # get dataset source
    dataset_source = gen_input.dataset_source

    if dataset_source == 'local':
        # prepare inputs from local disk
        inputs = request_processor.prepare_from_disk(request_inputs=gen_input.inputs, dataset_id=gen_input.dataset_id)
    elif dataset_source == 'minio':
        # prepare inputs from minio
        inputs = request_processor.prepare_from_minio(request_inputs=gen_input.inputs, dataset_id=gen_input.dataset_id)

    # augment images
    for gen_idx, _ in enumerate(trange(gen_input.number_gen)):
        input_dict = sample(inputs, 1)[0]
        aug_image = general_augment(input_dict['image_array'], gen_input.dict(), mode='edge')

        # convert to response format
        filename = input_dict.get('image', 'gen_image.png')
        gen_filename, _ = response_processor.gen_filename(full_filename=filename, idx=gen_idx)

        # save gen image
        image = Image.fromarray(aug_image)
        if dataset_source == 'local':
            image_save_path = os.path.join(executor.root_folder, dataset_id, gen_filename)
            image.save(image_save_path)
        elif dataset_source == 'minio':
            image_save_path = os.path.join(dataset_id, gen_filename)
            request_processor.minio.save_image(image, image_save_path)

        # update progress
        executor.update_execution_status(
            task_id=task_id,
            total=gen_input.number_gen,
            current=gen_idx + 1
        )


try:
    main(
        args.task_id, args.dataset_id,
        gm_gen_input,
        gm_executor, gm_request_processor, gm_response_processor
    )
    # update final progress
    gm_executor.update_execution_status(task_id=args.task_id, total=gm_gen_input.number_gen, current='completed')
except Exception as e:
    logging.error("Task ID %s failed: %s", args.task_id, e)
    # update error progress
    gm_executor.update_execution_status(task_id=args.task_id, total=gm_gen_input.number_gen, current='error')
