# aoi-gen-backend
- start services
```bash
docker compose up -d --build
```

## VoxelMorph
#### API for VoxelMorph (HyperMorph)
- Swagger UI: [localhost:3302/docs](localhost:3302/docs)
- Scripts Folder: voxelmorph/
- API Route:
    1. [POST] [localhost:3302/voxelmorph/train](localhost:3302/voxelmorph/train)
        - test script
        ```python
        python test_request.py --api-route train
        ```
    2. [POST] [localhost:3302/voxelmorph/inference](localhost:3302/voxelmorph/inference)
        - test script: $MODEL_ID can be retrieved from --api-route train
        ```python
        python test_request.py --api-route inference --model-id $MODEL_ID
        ```

## Random Deformation
#### API for Random Deformation
- Swagger UI: [localhost:3303/docs](localhost:3303/docs)
- Scripts Folder: random_deform/
- API Route:
    1. [POST] [localhost:3303/random_deform/generate](localhost:3303/random_deform/generate)
        - test script
        ```python
        python test_request.py
        ```

## Surface Defect
#### API for Surface Defect
- Swagger UI: [localhost:3305/docs](localhost:3305/docs)
- Scripts Folder: surface_defect/
- API Route:
    1. [POST] [localhost:3305/surface_defect/generate](localhost:3305/surface_defect/generate)
        - test script
        ```python
        python test_request.py
        ```

## General Method
#### API for General Method
- Scripts Folder: general_method/
- API Route:
    1. [POST] [localhost:8790/general_method/generate](localhost:8790/general_method/generate)


