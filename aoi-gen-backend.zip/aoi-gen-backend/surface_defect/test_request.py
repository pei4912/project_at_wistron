import requests

from app.base_model import SurfaceDefectInput


if __name__ == '__main__':
    # prepare data
    sd_gen_input = SurfaceDefectInput(
        dataset_id='dataset_id',
        dataset_source='local',
        src_inputs=[{'image': 'ok.jpg', 'annotations': 'ok.json', 'locations': [[50, 50]]}],
        trg_inputs=[{'image': 'ng.jpg', 'annotations': 'ng.json'}],
        execute_on_backend=False,
        number_gen=5,
        allow_overlap=False,
        RandomDeform=[
            {
                "amp_stddev": 0.5,
                "smooth_stddev": 0.5,
                'smooth_edge': 0.5,
                'random_vertical_offset': 0.5,
                'random_horizontal_offset': 0.5
            }
        ],
        AdditiveGaussianNoise=[
            {
                "mean": 0.0,
                "sigma": 0.1,
                "per_channel": True
            }
        ],
        ElasticTransformation=[
            {
                "alpha": 80,
                "sigma": 20
            }
        ],
        Cutout=[
            {
                "num_min": 1,
                "num_max": 3,
                "block_size": 0.2,
                "squared": False,
            }
        ],
        Multiply=[
            {
                "value_from": 0.5,
                "value_to" : 1.5,
                "per_channel": 0.5
            }
        ],
        GaussianBlur=[
            {
                "sigma_from": 0.0,
                "sigma_to": 2.0
            }
        ],
        CLAHE=[
            {
                "clip_from": 1,
                "clip_to": 7
            }
        ],
        Affine=[
            {
                "translate_x_from": -0.2,
                "translate_x_to": 0.2,
                "translate_y_from": -0.2,
                "translate_y_to": 0.2,
                "rotate_from": -45,
                "rotate_to": 45,
                "shear_from": -15,
                "shear_to": 15,
                "scale_from": 0.5,
                "scale_to": 1.5,
            }
        ],
    )
    response = requests.post('http://localhost:8000/surface_defect/generate', data=sd_gen_input.json())

    print(f'status code: {response.status_code}')
    print(f'api version: {response.json()["api_version"]}')
