import os
import argparse
import json
from random import sample
from tqdm import trange
import logging

from PIL import Image

from utils import polygon_to_mask
from utils import BaseExecutor, BaseRequestProcessor, BaseResponseProcessor
from app.surface_defect import deform_defect_area, paste_defect_to_source, gen_polygons, check_overlap


# parse the commandline
parser = argparse.ArgumentParser()
parser.add_argument('--task-id', '--task_id', required=True, type=str)
parser.add_argument('--dataset-id', '--dataset_id', required=True, type=str)
args = parser.parse_args()


sd_executor = BaseExecutor()
sd_request_processor = BaseRequestProcessor()
sd_response_processor = BaseResponseProcessor()
# load request
sd_gen_input = sd_executor.load_from_disk(task_id=args.task_id, file_name="sd_gen_input")


def main(
    task_id, dataset_id,
    gen_input,
    executor, request_processor, response_processor
):
    # get dataset source
    dataset_source = gen_input.dataset_source

    if dataset_source == 'local':
        # prepare inputs from local disk
        src_inputs = request_processor.prepare_from_disk(request_inputs=gen_input.src_inputs, dataset_id=gen_input.dataset_id)
        trg_inputs = request_processor.prepare_from_disk(request_inputs=gen_input.trg_inputs, dataset_id=gen_input.dataset_id)
    elif dataset_source == 'minio':
        # prepare inputs from minio
        src_inputs = request_processor.prepare_from_minio(request_inputs=gen_input.src_inputs, dataset_id=gen_input.dataset_id)
        trg_inputs = request_processor.prepare_from_minio(request_inputs=gen_input.trg_inputs, dataset_id=gen_input.dataset_id)
    # remove NG not annotated
    trg_inputs = [trg_input for trg_input in trg_inputs if len(trg_input.get('ng_shapes', [])) > 0]

    # generate surface defect images
    for gen_idx, _ in enumerate(trange(gen_input.number_gen)):
        # prepare input to gen_surface_defect
        # decide src image
        src_input = sample(src_inputs, 1)[0]
        deformed_image = src_input['image_array']
        # get ng_shapes
        ng_shapes = src_input.get('ng_shapes', [])
        # get locations
        locations = src_input['locations']
        locations = sample(locations, min(len(locations), gen_input.num_ng_on_background))

        # random sample trg input
        trg_input = sample(trg_inputs, 1)[0]
        trg_image = trg_input['image_array']

        # paste defect area to different locations
        for gen_loc_idx in range(len(locations)):
            location = tuple([int(l) for l in locations[gen_loc_idx]])

            # decide defect area
            defect_area = sample(trg_input['ng_shapes'], 1)[0]
            defect_label = defect_area['label']
            defect_polygons = [defect_area['points']]
            trg_mask = polygon_to_mask(shape=trg_input['shape'], polygon_points=defect_polygons, convert_format='np')

            # generate surface defect image
            # deform defect area
            _deformed_defect, _deformed_defect_mask = deform_defect_area(
                trg_image=trg_image, trg_mask=trg_mask,
                aug_params=gen_input.dict()
            )
            # paste defect area to source image
            _deformed_image, _deformed_mask = paste_defect_to_source(
                src_image=deformed_image, location=location,
                deformed_defect=_deformed_defect, deformed_defect_mask=_deformed_defect_mask,
                paste_method=gen_input.paste_method
            )
            # get polygon of defect area
            _polygons = gen_polygons(_deformed_mask)
            # check generated defect overlap or not
            if not gen_input.allow_overlap:
                # ng_shapes will be updated when iter locations
                ori_polygons = [shape['points'] for shape in ng_shapes]
                if ori_polygons != [] and check_overlap(deformed_image.shape, ori_polygons, _polygons):
                    continue
            deformed_image = _deformed_image
            polygons = _polygons

            # prepare response label shapes
            shapes = [
                {
                    'label': defect_label,
                    'points': polygon,
                    'group_id': None,
                    'shape_type': 'polygon',
                    'flags': {}
                }
                for polygon in polygons
                if polygon != [()]
            ]
            ng_shapes = ng_shapes + shapes

            # update progress
            executor.update_execution_status(
                task_id=task_id,
                total=gen_input.number_gen * gen_input.num_ng_on_background,
                current=(gen_idx * gen_input.num_ng_on_background) + gen_loc_idx + 1
            )

        # convert to response format
        src_filename = src_input.get('image', 'gen_image.png')
        gen_filename, file_format = response_processor.gen_filename(full_filename=src_filename, idx=gen_idx)

        # save gen image
        image = Image.fromarray(deformed_image)
        if dataset_source == 'local':
            image_save_path = os.path.join(executor.root_folder, dataset_id, gen_filename)
            image.save(image_save_path)
        elif dataset_source == 'minio':
            image_save_path = os.path.join(dataset_id, gen_filename)
            request_processor.minio.save_image(image, image_save_path)
        # save json
        h, w, _ = deformed_image.shape
        labelme_file = {
            "version": "5.0.1",
            "flags": {},
            "shapes": ng_shapes,
            "imageHeight": h,
            "imageWidth": w,
            "imagePath": gen_filename,
            "imageData": None,
        }
        json_save_path = image_save_path.replace(file_format, 'json')
        if dataset_source == 'local':
            with open(json_save_path, mode='w') as f:
                json.dump(labelme_file, f)
        elif dataset_source == 'minio':
            request_processor.minio.save_annotations(labelme_file, json_save_path)


try:
    main(
        args.task_id, args.dataset_id,
        sd_gen_input,
        sd_executor, sd_request_processor, sd_response_processor
    )
    # update final progress
    sd_executor.update_execution_status(task_id=args.task_id, total=sd_gen_input.number_gen * sd_gen_input.num_ng_on_background, current='completed')
except Exception as e:
    logging.error("Task ID %s failed: %s", args.task_id, e)
    # update error progress
    sd_executor.update_execution_status(task_id=args.task_id, total=sd_gen_input.number_gen * sd_gen_input.num_ng_on_background, current='error')
