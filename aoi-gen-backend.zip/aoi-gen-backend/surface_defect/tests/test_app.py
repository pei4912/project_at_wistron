import os
import sys
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

from fastapi.testclient import TestClient

from app.main import app


client = TestClient(app)


def test_sd_gen_post():
    request_body = {
        'dataset_id': 'dataset_id',
        'src_inputs': [{'image': 'test_image1.bmp', 'annotations': 'test_image1.json', 'locations': [[50, 50]]}],
        'trg_inputs': [{'image': 'test_image2.bmp', 'annotations': 'test_image2.json'}],
        'execute_on_backend': False,
        'number_gen':5,
        'allow_overlap': False,
        'RandomDeform': [
            {
                "amp_stddev": 0.5,
                "smooth_stddev": 0.5,
                'smooth_edge': 0.5,
                'random_vertical_offset': 0.5,
                'random_horizontal_offset': 0.5
            }
        ],
        'AdditiveGaussianNoise': [
            {
                "mean": 0.0,
                "sigma": 0.1,
                "per_channel": True
            }
        ],
        'ElasticTransformation': [
            {
                "alpha": 80,
                "sigma": 20
            }
        ],
        'Cutout': [
            {
                "num_min": 1,
                "num_max": 3,
                "block_size": 0.2,
                "squared": False,
            }
        ],
        'Multiply': [
            {
                "value_from": 0.5,
                "value_to" : 1.5,
                "per_channel": 0.5
            }
        ],
        'GaussianBlur': [
            {
                "sigma_from": 0.0,
                "sigma_to": 2.0
            }
        ],
        'CLAHE': [
            {
                "clip_from": 1,
                "clip_to": 7
            }
        ],
        'Affine': [
            {
                "translate_x_from": -0.2,
                "translate_x_to": 0.2,
                "translate_y_from": -0.2,
                "translate_y_to": 0.2,
                "rotate_from": -45,
                "rotate_to": 45,
                "shear_from": -15,
                "shear_to": 15,
                "scale_from": 0.5,
                "scale_to": 1.5,
            }
        ],
    }

    response = client.post('/surface_defect/generate', json=request_body)
    assert response.status_code == 200
