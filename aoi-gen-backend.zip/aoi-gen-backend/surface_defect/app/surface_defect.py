from typing import List, Dict, Tuple

import numpy as np
import cv2
from PIL import ImageFilter

from random_deform import random_deform_image, AMP_STDDEV_FACTOR, SMOOTH_STDDEV_FACTOR, RANDOM_OFFSET_FACTOR
from general_method import general_augment
from utils import crop_roi, image_to_mask, polygon_to_mask
from utils import DeepImageBlendingPaste, DirectPaste, SeamlessPaste


deep_image_blending_paster = DeepImageBlendingPaste(epochs=1000)
direct_paster = DirectPaste()
seamless_paster = SeamlessPaste()


def deform_defect_area(
    trg_image: np.array, trg_mask: np.array,
    aug_params: dict
) -> Tuple[np.array, np.array]:
    """
    deform defect area
        1) random deformation
        2) crop defect area
        3) general augmentation

    Args:
        trg_image: defect image, [h, w, c], dtype: uint8
        trg_mask: defect mask, [h, w, 1], dtype: uint8
        aug_params: parameters to do augmentation, ref: app.base_model.SurfaceDefectInput
    Returns:
        deformed_defect: image, [h, w, c], dtype: uint8
        deformed_defect_mask: mask, [h, w, 1], dtype: uint8
    """
    # random deformation
    amp_stddev = aug_params['RandomDeform'][0].get('amp_stddev', None)
    smooth_stddev = aug_params['RandomDeform'][0].get('smooth_stddev', None)
    smooth_edge = aug_params['RandomDeform'][0].get('smooth_edge', 0.0)
    smooth_edge = smooth_edge if smooth_edge else 0
    random_vertical_offset = aug_params['RandomDeform'][0].get('random_vertical_offset', 0.0)
    random_vertical_offset = random_vertical_offset if random_vertical_offset else 0
    random_horizontal_offset = aug_params['RandomDeform'][0].get('random_horizontal_offset', 0.0)
    random_horizontal_offset = random_horizontal_offset if random_horizontal_offset else 0
    if amp_stddev and smooth_stddev:
        amp_stddev = AMP_STDDEV_FACTOR * amp_stddev
        smooth_stddev = SMOOTH_STDDEV_FACTOR * smooth_stddev
        random_vertical_offset = RANDOM_OFFSET_FACTOR * random_vertical_offset
        random_horizontal_offset = RANDOM_OFFSET_FACTOR * random_horizontal_offset
        deformed_defect, deformed_defect_mask = random_deform_image(
            trg_image, trg_mask,
            amp_stddev=amp_stddev, smooth_stddev=smooth_stddev,
            smooth_edge=smooth_edge,
            random_vertical_offset=random_vertical_offset, random_horizontal_offset=random_horizontal_offset
        )
    else:
        deformed_defect = trg_image * trg_mask
        deformed_defect_mask = image_to_mask(deformed_defect)

    # general augmentation
    # crop roi
    deformed_defect = crop_roi(deformed_defect, deformed_defect_mask)[0]
    deformed_defect_mask = crop_roi(deformed_defect_mask, deformed_defect_mask)[0]
    # padding
    h, w, _ = deformed_defect.shape
    deformed_defect = cv2.copyMakeBorder(deformed_defect, h, h, w, w, cv2.BORDER_CONSTANT, 0)
    deformed_defect_mask = cv2.copyMakeBorder(deformed_defect_mask, h, h, w, w, cv2.BORDER_CONSTANT, 0)[..., None]
    # augment image
    deformed_defect, deformed_defect_mask = general_augment(deformed_defect, aug_params, mask=deformed_defect_mask, mode='constant')
    deformed_defect = deformed_defect[h:2*h, w:2*w]
    deformed_defect_mask = deformed_defect_mask[h:2*h, w:2*w]

    return deformed_defect, deformed_defect_mask


def paste_defect_to_source(
    src_image: np.array, location,
    deformed_defect: np.array, deformed_defect_mask: np.array,
    paste_method: str='auto'
) -> Tuple[np.array, np.array]:
    """
    paste defect to source image
    if paste_method == 'auto':
        1) direct paste
        2) try seamless paste
        3) compare direct and seamless paste for visible

    Args:
        src_image: background image, [h, w, c], dtype: uint8
        location: the location to paste defect
        deformed_defect: defect image, [h, w, c], dtype: uint8
        deformed_defect_mask: defect mask, [h, w, 1], dtype: uint8
        paste_method: defect paste method: auto / direct / seamless
    Returns:
        deformed_image: image, [h, w, c], dtype: uint8
        deformed_mask: mask, [h, w, 1], dtype: uint8
    """
    # deep image blending paste
    if paste_method == 'dip':
        try:
            _deformed_image_dip = deep_image_blending_paster(src_image, deformed_defect, deformed_defect_mask * 255, location)
        except Exception as e:
            _deformed_image_dip = direct_paster(src_image, deformed_defect, deformed_defect_mask * 255, location, image_filter=ImageFilter.SMOOTH_MORE)
    # direct paste
    if paste_method in ['auto', 'direct']:
        _deformed_image_direct = direct_paster(src_image, deformed_defect, deformed_defect_mask * 255, location, image_filter=ImageFilter.SMOOTH_MORE)
    # seamless paste
    if paste_method in ['auto', 'seamless']:
        try:
            _deformed_image_seamless = seamless_paster(src_image, deformed_defect, deformed_defect_mask * 255, location, paste_method=cv2.MIXED_CLONE)
        except Exception as e:
            _deformed_image_seamless = direct_paster(src_image, deformed_defect, deformed_defect_mask * 255, location, image_filter=ImageFilter.SMOOTH_MORE)
    # generate mask
    _deformed_mask = direct_paster(np.zeros((*src_image.shape[:2], 1), dtype='uint8'), deformed_defect_mask * 255, deformed_defect_mask * 255, location)
    _deformed_mask = (_deformed_mask / 255).astype('uint8')

    # none auto paste
    if paste_method == 'dip':
        return _deformed_image_dip, _deformed_mask[..., :1]
    elif paste_method == 'direct':
        return _deformed_image_direct, _deformed_mask[..., :1]
    elif paste_method == 'seamless':
        return _deformed_image_seamless, _deformed_mask[..., :1]
    else:
        # compare image similarity to decide which paste method
        img1 = src_image * _deformed_mask
        img2 = _deformed_image_seamless * _deformed_mask
        similaity = (abs(img1 - img2) / 255).sum() / (_deformed_mask.sum() + 1e-10)
        if similaity <= 0.2:
            return _deformed_image_direct, _deformed_mask[..., :1]
        else:
            return _deformed_image_seamless, _deformed_mask[..., :1]


def gen_polygons(
    deformed_mask: np.array,
) -> list:
    """
    generate polygons of deformed mask

    Args:
        deformed_mask: mask, [h, w, 1], dtype: uint8
    Returns:
        polygons: polygons of deformed mask
            [
                [
                    [x1, y1],
                    [x2, y1],
                    [x2, y2],
                    [x1, y2]
                ]
            ]
    """
    # generate polygons
    h, w, _ = deformed_mask.shape
    if deformed_mask.sum() == 0:
        polygons = [[(0, 0)]]
    else:
        contours, _ = cv2.findContours(deformed_mask, cv2.RETR_TREE, cv2.CHAIN_APPROX_SIMPLE)
        contours = sorted(contours, key=cv2.contourArea, reverse=True)
        contours = [contour for contour in contours if cv2.contourArea(contour) > 0]
        polygons = []
        for contour in contours:
            contour = contour[:, 0].tolist()
            polygons.append(contour)
        # clip values
        polygons = [
            [
                (clip_value(p[0], 0, w), clip_value(p[1], 0, h))
                for p in polygon
            ]
            for polygon in polygons
        ]

    return polygons


def clip_value(value, vmin, vmax):
    """
    clip value from vmin to vmax
    """
    return sorted((vmin, vmax, value))[1]


def check_overlap(shape, polygons_a, polygons_b):
    """
    check 2 polygons overlap or not

    Args:
        shape
        polygons_a
        polygons_b
            [
                [
                    [x1, y1],
                    [x2, y1],
                    [x2, y2],
                    [x1, y2]
                ]
            ]
    """
    # convert to mask
    mask_a = (np.array(polygon_to_mask(shape, polygons_a)) / 255).astype('uint8')[..., None]
    mask_b = (np.array(polygon_to_mask(shape, polygons_b)) / 255).astype('uint8')[..., None]
    # cal intersection
    intersection = (mask_a * mask_b).sum()
    return intersection > 0
