from datetime import datetime
import logging

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
import numpy as np

from utils import polygon_to_mask
from utils import BaseExecutor, ProgressRouter
from utils.system.gpu import GPUInfoAPIRouter
from utils.system.file_stream import FileStreamingAPIRouter
from .base_model import SurfaceDefectInput, SurfaceDefectOutput, GenerateLocationInput, GenerateLocationOutput


logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(levelname)s - %(message)s",
    datefmt="%Y-%m-%d %H:%M:%S",
)
app = FastAPI()
app.add_middleware(
    CORSMiddleware,
    allow_origins=['*'],
    allow_credentials=True,
    allow_methods=['*'],
    allow_headers=['*'],
)
app.include_router(GPUInfoAPIRouter().router)
app.include_router(FileStreamingAPIRouter().router)
app.include_router(ProgressRouter().router)
sd_executor = BaseExecutor()


@app.post('/surface_defect/generate', response_model=SurfaceDefectOutput)
def sd_gen_post(sd_gen_input: SurfaceDefectInput) -> SurfaceDefectOutput:
    """
    generate surface defect images from OK and NG images
    """
    # set task_id
    task_id = f"SurfaceDefect/{datetime.now().strftime('%Y%m%d_%H%M%S')}"
    logging.info("Task ID: %s", task_id)
    # init progress
    sd_executor.init_execution_status(task_id)
    sd_executor.update_execution_status(task_id=task_id, total=sd_gen_input.number_gen * sd_gen_input.num_ng_on_background, current=0)
    # set dataset_id
    dataset_id = f"{task_id}/gen_images"
    logging.info("Dataset ID: %s", dataset_id)
    if sd_gen_input.dataset_source == 'local':
        sd_executor.create_task_id_folder(dataset_id)

    # save request to disk
    sd_executor.save_to_disk(file=sd_gen_input, task_id=task_id, file_name='sd_gen_input')
    # execute script via command line
    sd_executor.execute(
        execute_script='execute.py', execute_on_backend=sd_gen_input.execute_on_backend,
        task_id=task_id, dataset_id=dataset_id
    )

    # prepare response
    response = SurfaceDefectOutput(task_id=task_id, dataset_id=dataset_id, dataset_source=sd_gen_input.dataset_source)
    return response


@app.post('/surface_defect/generate_locations', response_model=GenerateLocationOutput)
def gen_loc_post(gen_loc_input: GenerateLocationInput) -> GenerateLocationOutput:
    generate_locations = []
    for loc_input in gen_loc_input.inputs:
        filename = loc_input.get('filename', '')
        # generate annotation mask
        h, w = loc_input['imageHeight'], loc_input['imageWidth']
        mask = polygon_to_mask(shape=(h, w), polygon_points=loc_input['polygons'], convert_format='np')[..., 0]
        # generate locations
        points = np.argwhere(mask != 0)
        idxs = np.random.choice(len(points), size=loc_input['number_gen'], replace=False)
        # switch x, y coordinate
        locations = [points[idx][::-1].tolist() for idx in idxs]
        generate_locations.append({
            'filename': filename,
            'locations': locations
        })

    response = GenerateLocationOutput(gen_locations=generate_locations)
    return response
