from typing import List, Dict
from pydantic import BaseModel

from utils._version import __version__


BaseModel.model_config['protected_namespaces'] = {}


class SurfaceDefectInput(BaseModel):
    """
    config request input for surface defect

    Args:
        dataset_id: load images from $ROOT_FOLDER/dataset_id
        dataset_source: local / minio
            - local: load/save data from/to local disk
            - minio: load/save data from/to minio
        src_inputs:
        [
            {
                'image': source image, as a file name
                'annotations': annotations of source image, as a file name
                'locations': random location of source image, List[Tuple]
            }
        ]
        trg_inputs:
        [
            {
                'image': target image, as a file name
                'annotations': annotations of target image, as a file name
            }
        ]

        execute_on_backend: execute surface defect process on the backend process
        number_gen: number of generated images
        num_ng_on_background: number of generated ng on the background (used to sample locations)
        allow_overlap: allow overlap or not
        paste_method: defect paste method: auto / direct / seamless

        # parameters for random deformation
        RandomDeform

        # parameters for general methods
        Fliplr: https://imgaug.readthedocs.io/en/latest/source/overview/flip.html?highlight=Flip#fliplr
        Flipud: https://imgaug.readthedocs.io/en/latest/source/overview/flip.html?highlight=Flip#flipud
        AdditiveGaussianNoise: https://imgaug.readthedocs.io/en/latest/source/overview/arithmetic.html#additivegaussiannoise
        ElasticTransformation: https://imgaug.readthedocs.io/en/latest/source/overview/geometric.html#elastictransformation
        Cutout: https://imgaug.readthedocs.io/en/latest/source/overview/arithmetic.html#cutout
        Multiply: https://imgaug.readthedocs.io/en/latest/source/overview/arithmetic.html#multiply
        GaussianBlur: https://imgaug.readthedocs.io/en/latest/source/overview/blur.html#gaussianblur
        CLAHE: https://imgaug.readthedocs.io/en/latest/source/overview/contrast.html#clahe
        Affine: https://imgaug.readthedocs.io/en/latest/source/overview/geometric.html#affine
    """
    dataset_id: str
    dataset_source: str = 'local'
    src_inputs: List[Dict]
    trg_inputs: List[Dict]

    execute_on_backend: bool = True
    number_gen: int = 5
    num_ng_on_background: int = 1
    allow_overlap: bool = True
    paste_method: str = 'auto'

    RandomDeform: List[Dict] = [{'amp_stddev': None, 'smooth_stddev': None, 'smooth_edge': None, 'random_vertical_offset': None, 'random_horizontal_offset': None}]
    Fliplr: List[Dict] = [{'prob': None}]
    Flipud: List[Dict] = [{'prob': None}]
    AdditiveGaussianNoise: List[Dict] = [{'mean': None, 'sigma': None, 'per_channel': None}]
    ElasticTransformation: List[Dict] = [{'alpha': None, 'sigma': None}]
    Cutout: List[Dict] = [{'num_min': None, 'sigma': None, 'block_size': None, 'squared': None}]
    Multiply: List[Dict] = [{'value_from': None, 'value_to': None, 'per_channel': None}]
    GaussianBlur: List[Dict] = [{'sigma_from': None, 'sigma_to': None}]
    CLAHE: List[Dict] = [{'clip_from': None, 'clip_to': None}]
    Affine: List[Dict] = [{'translate_x_from': None, 'translate_x_to': None, 'translate_y_from': None, 'translate_y_to': None, 'rotate_from': None, 'rotate_to': None, 'shear_from': None, 'shear_to': None, 'scale_from': None, 'scale_to': None}]


class SurfaceDefectOutput(BaseModel):
    """
    config response output for surface defect

    Args:
        task_id: folder to save task files
        dataset_id: folder to save dataset
        dataset_source: local or minio
        api_version: the version of api
    """
    task_id: str
    dataset_id: str
    dataset_source: str
    api_version: str = __version__


class GenerateLocationInput(BaseModel):
    """
    config request input for generate location

    Args:
        inputs:
        [
            {
                'filename': filename of image
                'number_gen': number of generated locations
                'imageHeight'
                'imageWidth'
                'polygons': [
                        [
                            [x1, y1],
                            [x2, y1],
                            [x2, y2],
                            [x1, y2]
                        ]
                    ]
            }
        ]
    """
    inputs: List[Dict]


class GenerateLocationOutput(BaseModel):
    """
    config response output for generate location

    Args:
        gen_locations: list of generated random locations
        [
            {
                'filename': filename of image
                'locations': generated random locations, List[Tuple]
                    [
                        [x, y]
                    ]
            }
        ]
        api_version: the version of api
    """
    gen_locations: List[Dict]
    api_version: str = __version__
