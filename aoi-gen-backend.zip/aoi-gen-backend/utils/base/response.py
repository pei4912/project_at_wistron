import os
from typing import Union


class BaseResponseProcessor:
    def gen_filename(
        self,
        full_filename: str='gen_image.png',
        idx: Union[str, int]=''
    ):
        """
        generate the filename of generated image

        Args:
            full_filename: xxx.png
            filename: xxx
            fileformat: png
            idx: 1
        Returns:
            gen_full_filename: x-1.png
            fileformat: png
        """
        if os.sep in full_filename:
            full_filename = full_filename.split(os.sep)[-1]
        filename, fileformat = full_filename.split('.')
        gen_full_filename = f"{filename}-{idx}.{fileformat}"
        return gen_full_filename, fileformat
