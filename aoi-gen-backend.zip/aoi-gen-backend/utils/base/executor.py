import os
from pathlib import Path
import pickle
from datetime import datetime
import pytz
from fastapi import APIRouter, HTTPException
from pydantic import BaseModel

from .._version import __version__
from ..utils import get_root_folder


ROOT_FOLDER = get_root_folder('request_data')


class BaseExecutor:
    root_folder=ROOT_FOLDER

    def set_task_id_folder(
        self,
        task_id
    ):
        """
        set task id folder: root_folder / task_id
        
        Args:
            task_id
        """
        return Path(self.root_folder) / task_id

    def create_task_id_folder(
        self,
        task_id
    ):
        """
        create folder: root_folder / task_id
        """
        task_folder = self.set_task_id_folder(task_id)
        os.makedirs(task_folder, exist_ok=True)
        return task_folder

    def save_to_disk(
        self,
        file,
        task_id, file_name
    ):
        """
        save file as pickle: root_folder / task_id / file_name.pkl

        Args:
            file
            task_id
            file_name
        """
        # create task folder if not existed
        task_folder = self.create_task_id_folder(task_id)

        # save file
        path = task_folder / f"{file_name}.pkl"
        with open(path, "wb") as f:
            pickle.dump(file, f)
        return str(path)

    def load_from_disk(
        self,
        task_id, file_name
    ):
        """
        load file from pickle: root_folder / task_id / file_name.pkl

        Args:
            task_id
            file_name
        """
        task_folder = self.set_task_id_folder(task_id)
        path = task_folder / f"{file_name}.pkl"

        # load file
        with open(path, "rb") as f:
            file = pickle.load(f)
        return file

    def get_execution_status(
        self,
        task_id
    ):
        """
        get execution status: root_folder / task_id / progress.txt

        Args:
            task_id
        """
        task_folder = self.set_task_id_folder(task_id)
        with open(task_folder / 'progress.txt', mode='r') as f:
            total, current, time = f.readlines()[-1].strip().split(",")
        return total, current, time

    def init_execution_status(
        self,
        task_id
    ):
        """
        init execution status
        """
        # create task folder if not existed
        task_folder = self.create_task_id_folder(task_id)

        with open(task_folder / 'progress.txt', mode='a') as f:
            f.write('total,current,time\n')

    def update_execution_status(
        self,
        task_id,
        total, current
    ):
        """
        update execution status
        """
        task_folder = self.set_task_id_folder(task_id)
        with open(task_folder / 'progress.txt', mode='a') as f:
            f.write(f"{total},{current},{datetime.now(pytz.timezone('Asia/Taipei'))}\n")

    def execute(
        self,
        execute_script='execute.py', execute_on_backend=True,
        **kwargs
    ):
        """
        execute python script with args
        """
        # prepare command
        command = f'python {execute_script}'
        if kwargs:
            args = [f'--{arg} {value}' for arg, value in kwargs.items()]
            args = ' '.join(args)
            command += f" {args}"

        # run script in backend process
        if execute_on_backend:
            command += '&'

        executed_result = os.system(command)
        return executed_result


class ProgressInput(BaseModel):
    """
    config request input for execution progress

    Args:
        task_id
    """
    task_id: str


class ProgressOutput(BaseModel):
    """
    config request output for execution progress

    Args:
        task_id
        api_version: the version of api
        total: total execution numbers
        current: current execution numbers
    """
    task_id: str
    api_version: str = __version__
    total: str = 'error'
    current: str = 'error'


class ProgressRouter(BaseExecutor):
    def __init__(self):
        self.router = APIRouter()
        self.router.add_api_route(
            path='/progress',
            endpoint=self.get_progress,
            methods=['POST'],
            response_model=ProgressOutput
        )

    async def get_progress(self, progress_input: ProgressInput):
        task_id = progress_input.task_id
        try:
            total, current, _ = self.get_execution_status(task_id)
            response = ProgressOutput(task_id=task_id, total=total, current=current)
            return response
        except HTTPException as e:
            raise HTTPException(status_code=500, detail=f"get status {task_id} error") from e
