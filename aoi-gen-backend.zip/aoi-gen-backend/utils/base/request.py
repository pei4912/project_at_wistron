import json
from pathlib import Path, PosixPath
from typing import Union, List, Dict, Tuple

from PIL import Image
import numpy as np

from ..utils import get_root_folder
from ..image_base64 import base64_to_image
from ..minio_client import MinioFileHandler


ROOT_FOLDER = get_root_folder('request_data')
BG_LABELS = ['OK', '__background__']


class BaseRequestProcessor:
    root_folder=ROOT_FOLDER
    bg_labels=BG_LABELS

    def __init__(
        self
    ):
        self.minio = MinioFileHandler()

    def _base64_to_image(
        self,
        base64_string: str
    ) -> Image.Image:
        """
        convert base 64 string to PIL.Image
        """
        return base64_to_image(base64_string)

    def _diskfile_to_image(
        self,
        path: str
    ) -> Image.Image:
        """
        load image from path and convert to PIL.Image
        """
        return Image.open(path)

    def _minio_to_image(
        self,
        file_path: str
    ) -> Image.Image:
        """
        retrive image from minio server
        """
        return self.minio.get_image(file_path)

    def convert_image(
        self,
        content: str,
        convert_format: str='np',
        dataset_source: str='local'
    ) -> Tuple[Union[Image.Image, np.ndarray], Tuple]:
        """
        convert to image from
            1. path
            2. base64 string
            3. minio path

        Args:
            content
        Returns:
            image: np.ndarray or PIL.Image
            shape: [h, w]
            dataset_source: local or minio
        """
        if dataset_source == 'local':
            if isinstance(content, PosixPath):
                image = self._diskfile_to_image(content)
            elif isinstance(content, str):
                image = self._base64_to_image(content)
        elif dataset_source == 'minio':
            image = self._minio_to_image(content)

        # convert to np
        if convert_format == 'np':
            image = np.array(image)
            return image, image.shape[:2]
        else:
            return image, image.size[::-1]
        return None, None

    def _list_to_polygon_shapes(
        self,
        shapes: List,
    ) -> Tuple[List, List]:
        """
        convert list to polygon shapes

        Args:
            shapes: list of shape
                shape: {
                    'label': str,
                    'points': list of [x, y]
                }
        """
        bg_shapes = [shape for shape in shapes if shape['label'] in self.bg_labels]
        ng_shapes = [shape for shape in shapes if shape['label'] not in self.bg_labels]
        return bg_shapes, ng_shapes

    def _diskfile_to_polygon_shapes(
        self,
        path: Union[str, PosixPath]
    ) -> Tuple[List, List]:
        """
        convert path to polygon shapes
        """
        with open (path, mode='r') as f:
            annotations = json.load(f)
        bg_shapes = [shape for shape in annotations['shapes'] if shape['label'] in self.bg_labels]
        ng_shapes = [shape for shape in annotations['shapes'] if shape['label'] not in self.bg_labels]
        return bg_shapes, ng_shapes

    def _minio_to_polygon_shapes(
        self,
        file_path: str
    ) -> Tuple[List, List]:
        """
        retrive polygons from minio server
        """
        annotations = self.minio.get_annotations(file_path)
        bg_shapes = [shape for shape in annotations['shapes'] if shape['label'] in self.bg_labels]
        ng_shapes = [shape for shape in annotations['shapes'] if shape['label'] not in self.bg_labels]
        return bg_shapes, ng_shapes

    def convert_polygon_shapes(
        self,
        content: Union[str, PosixPath, List],
        dataset_source: str='local'
    ) -> Tuple[List, List]:
        """
        convert to polygon shapes from
            1. path
            2. list
            3. minio path

        Args:
            content
            dataset_source: local or minio
        Returns:
            bg_shapes: list of background shape
            ng_shapes: list of ng shape
                shape: {
                    'label': str,
                    'points': list of [x, y]
                }
        """
        if dataset_source == 'local':
            if isinstance(content, PosixPath):
                return self._diskfile_to_polygon_shapes(content)
            if isinstance(content, List):
                return self._list_to_polygon_shapes(content)
        elif dataset_source == 'minio':
            return self._minio_to_polygon_shapes(content)
        return [], []

    def prepare_from_base64(self, request_inputs: List[Dict]) -> List[Dict]:
        """
        prepare request inputs as
            1. image_array: np.ndarray
            2. shape: tuple
            3. have_annotation: bool
            4. ng_shapes: list
            5. bg_shapes: list

        Args:
            request_inputs: [{
                'image': base64 string,
                'annotations': list of shape
            }]
        Returns:
            request_inputs: [{
                'image_array': np.ndarray,
                'shape': tuple,
                'have_annotation': bool,
                'ng_shapes': list,
                'bg_shapes': list
            }]
        """
        # prepare inputs
        for request_input in request_inputs:
            request_input['image_array'], request_input['shape'] = self.convert_image(content=request_input['image'], convert_format='np', dataset_source='local')

            # set default have_annotation
            request_input['have_annotation'] = False
            # load annotations
            if request_input.get('annotations'):
                request_input['have_annotation'] = True
                request_input['bg_shapes'], request_input['ng_shapes'] = self.convert_polygon_shapes(content=request_input['annotations'], dataset_source='local')

        return request_inputs

    def prepare_from_disk(self, request_inputs: List[Dict], dataset_id: str) -> List[Dict]:
        """
        prepare request inputs as
            1. image_array: np.ndarray
            2. shape: tuple
            3. have_annotation: bool
            4. ng_shapes: list
            5. bg_shapes: list

        Args:
            request_inputs: [{
                'image': file path,
                'annotations': file path
            }]
            dataset_id: load files
                root_folder / {dataset_id} / {files}
            dataset_source: local or minio
        Returns:
            request_inputs: [{
                'image_array': np.ndarray,
                'shape': tuple,
                'have_annotation': bool,
                'ng_shapes': list,
                'bg_shapes': list
            }]
        """
        # prepare inputs
        dataset_folder = Path(self.root_folder) / dataset_id
        for request_input in request_inputs:
            # load image from file
            path = dataset_folder / request_input['image']
            request_input['image_array'], request_input['shape'] = self.convert_image(content=path, convert_format='np', dataset_source='local')

            # set default have_annotation
            request_input['have_annotation'] = False
            # load annotations from file
            if request_input.get('annotations'):
                request_input['have_annotation'] = True
                request_input['bg_shapes'], request_input['ng_shapes'] = self.convert_polygon_shapes(content=dataset_folder / request_input['annotations'], dataset_source='local')

        return request_inputs

    def prepare_from_minio(self, request_inputs: List[Dict], dataset_id: str) -> List[Dict]:
        """
        prepare request inputs as
            1. image_array: np.ndarray
            2. shape: tuple
            3. have_annotation: bool
            4. ng_shapes: list
            5. bg_shapes: list

        Args:
            request_inputs: [{
                'image': file path,
                'annotations': file path
            }]
            dataset_id: load files
                {dataset_id} / {files}
        Returns:
            request_inputs: [{
                'image_array': np.ndarray,
                'shape': tuple,
                'have_annotation': bool,
                'ng_shapes': list,
                'bg_shapes': list
            }]
        """
        # prepare inputs
        dataset_folder = Path(dataset_id)
        for request_input in request_inputs:
            # load image from file
            path = dataset_folder / request_input['image']
            request_input['image_array'], request_input['shape'] = self.convert_image(content=path, convert_format='np', dataset_source='minio')

            # set default have_annotation
            request_input['have_annotation'] = False
            # load annotations from file
            if request_input.get('annotations'):
                request_input['have_annotation'] = True
                request_input['bg_shapes'], request_input['ng_shapes'] = self.convert_polygon_shapes(content=dataset_folder / request_input['annotations'], dataset_source='minio')

        return request_inputs

    def __call__(self):
        raise NotImplementedError
