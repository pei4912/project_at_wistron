from typing import Union, List, Tuple

from PIL import Image, ImageDraw
import numpy as np


def polygon_to_mask(
    shape: Tuple,
    polygon_points: List[List[List]] = [[[None, None]]],
    convert_format: str='PIL'
) -> Union[Image.Image, np.ndarray]:
    """
    convert list of points of multiple polygons to mask

    Args:
        shape: h, w
        polygon_points: list of points of multiple polygons
            [
                [
                    [x1, y1],
                    [x2, y2]
                ],
                [
                    [x1, y1],
                    [x2, y2]
                ],
            ]
        convert_format: PIL or np
    Returns:
        mask: label mask
    """

    # create a empty mask
    mask = np.zeros(shape[:2], dtype=np.uint8)
    mask = Image.fromarray(mask)
    draw = ImageDraw.Draw(mask)

    # draw points to mask
    for points in polygon_points:
        xy = [tuple(point) for point in points]
        draw.polygon(xy=xy, outline=1, fill=1)
    mask = np.array(mask, dtype=bool)

    # convert to PIL.Image
    mask = Image.fromarray(mask).convert('L')
    if convert_format == 'np':
        mask = np.array(mask)[..., None]
        mask = (mask / 255).astype('uint8')
    return mask


def crop_roi(image, mask):
    """
    crop image from given mask

    Args:
        image (np.array): [h, w, c], dtype: uint8
        mask (np.array): [h, w, 1], dtype: uint8
    Returns:
        crop_image (np.array): [h, w, c], dtype: uint8
        coordinate: (top, bottom, left, right)
    """
    # coordinate
    top = np.where((mask != 0).sum(axis=1))[0][0]
    left = np.where((mask != 0).sum(axis=0))[0][0]
    bottom = np.where((mask != 0).sum(axis=1))[0][-1]
    right = np.where((mask != 0).sum(axis=0))[0][-1]
    # crop
    crop_image = image[top:bottom, left:right]
    return crop_image, (top, bottom, left, right)


def image_to_mask(image):
    """
    convert image roi to mask

    Args:
        image (np.array): [h, w, c], dtype: uint8
    Returns:
        mask (np.array): [h, w, 1], dtype: uint8
    """
    mask = (image.sum(axis=2) != 0).astype('uint8')[..., np.newaxis]
    return mask
