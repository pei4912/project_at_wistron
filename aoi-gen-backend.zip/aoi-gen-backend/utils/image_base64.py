import base64
from io import BytesIO

from PIL import Image


def image_to_base64(image: Image.Image, file_format: str='png') -> str:
    """
    convert PIL.Image to base64 string

    Args:
        image
    Returns:
        base64_string
    """
    if file_format == 'jpg':
        file_format = 'jpeg'
    buffered = BytesIO()
    image.save(buffered, format=file_format)
    base64_string = base64.b64encode(buffered.getvalue()).decode()
    return base64_string

def base64_to_image(base64_string: str) -> Image.Image:
    """
    convert base64 string to PIL.Image

    Args:
        base64_string
    Returns:
        image
    """
    image = Image.open(BytesIO(base64.b64decode(base64_string)))
    return image
