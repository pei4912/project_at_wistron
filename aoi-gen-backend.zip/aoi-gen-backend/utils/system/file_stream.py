import os
import zipfile
import logging
from pathlib import Path
from datetime import datetime
from typing import Union

from fastapi import APIRouter, File, UploadFile, Query, HTTPException, Request
from fastapi.responses import FileResponse

from utils._version import __version__
from utils.utils import get_root_folder


ROOT_FOLDER = get_root_folder("request_data")
DEFAULT_SERVICE = "APIUpload"

class FileStreaming:
    def __init__(
        self,
        root_folder: str=ROOT_FOLDER,
        service: str=DEFAULT_SERVICE
    ):
        self.root_folder = Path(root_folder)
        self.service = service
        os.makedirs(self.root_folder / self.service, exist_ok=True)

    def delete_file(
        self,
        path: Union[Path, str]
    ):
        """
        delete file
        """
        path = self.root_folder / path
        path.unlink()

    def zip_folder(
        self,
        folder_path: Union[Path, str]
    ):
        """
        zip folder as folder.zip
        """
        folder_path = self.root_folder / folder_path
        zip_path = folder_path.with_suffix('.zip')
        with zipfile.ZipFile(zip_path, 'w', zipfile.ZIP_DEFLATED) as f:
            for file_path in folder_path.rglob('*'):
                if file_path.is_file():
                    f.write(file_path, file_path.relative_to(folder_path))

    def unzip_file(
        self,
        zip_path: Union[Path, str]
    ):
        """
        unzip zip_path as folder
        """
        zip_path = self.root_folder / zip_path
        with zipfile.ZipFile(zip_path, 'r') as f:
            f.extractall(zip_path.with_suffix(''))

    def upload_file(
        self,
        file_path: Union[Path, str],
        file: UploadFile=File(...)
    ):
        """
        upload file
        """
        file_path = self.root_folder / file_path
        with open(file_path, "wb+") as f:
            f.write(file.file.read())

    def download_file(
        self,
        filename: Union[Path, str]
    ):
        """
        download file
        """
        path = self.root_folder / filename
        if path.exists():
            return FileResponse(path=path, filename=filename)
        else:
            raise HTTPException(status_code=404, detail='file not found')


class FileStreamingAPIRouter(FileStreaming):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.router = APIRouter()
        self.router.add_api_route('/upload_zip', self.upload_zip, methods=['POST'])
        self.router.add_api_route('/download_zip', self.download_zip, methods=['GET'])

    def upload_zip(
        self,
        file: UploadFile=File(...),
        request: Request=None
    ):
        """
        upload zip and unzip as folder
        """
        logging.info('Upload Zip File')
        user = request.headers.get("User")
        if user:
            logging.info('User: %s', user)

        # generate dataset id
        fname, fformat = file.filename.split('.')
        dataset_id = f"{self.service}/{fname}_{datetime.now().strftime('%Y%m%d_%H%M%S')}"
        logging.info("Dataset ID: %s", dataset_id)

        zip_path = f"{dataset_id}.{fformat}"
        # upload file
        self.upload_file(file_path=zip_path, file=file)
        # unzip file
        self.unzip_file(zip_path=zip_path)
        # delete file
        self.delete_file(path=zip_path)
        return {'dataset_id': dataset_id}

    def download_zip(
        self,
        dataset_id: str=Query(..., description="The ID of the dataset"),
        request: Request=None
    ):
        """
        zip folder and download
        """
        logging.info('Download Zip File')
        user = request.headers.get("User")
        if user:
            logging.info('User: %s', user)
        logging.info("Dataset ID: %s", dataset_id)

        if not (self.root_folder / dataset_id).exists():
            raise HTTPException(status_code=404, detail='dataset_id not found')
        # zip folder
        self.zip_folder(folder_path=dataset_id)
        # download file
        return self.download_file(filename=f"{dataset_id}.zip")
