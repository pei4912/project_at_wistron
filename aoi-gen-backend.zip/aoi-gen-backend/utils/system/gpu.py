import subprocess as sp
import xml.etree.ElementTree as ET

from fastapi import APIRouter

from utils._version import __version__


class GPUInfo:
    @classmethod
    def run_command(cls, command='nvidia-smi'):
        """
        run linux command to get gpu info
        """
        try:
            print(f"command: {command}")
            info = sp.run(command, capture_output=True, text=True, shell=True)
            print(f"info run: {info}")
            info = sp.check_output(command.split())
            print(f"info: {info}")
        except:
            return 'NO_GPU_AVAILABLE'
        # decode
        info = info.decode('ascii')
        # split
        info = info.split('\n')
        return info

    @property
    def gpu_available(self):
        """
        check gpu available or not
        """
        try:
            return self._gpu_available
        except:
            self._gpu_available = self.run_command('nvidia-smi') != 'NO_GPU_AVAILABLE'
            return self._gpu_available

    @property
    def is_mig(self):
        """
        check multi-gpu instance
        for AIML deployment
        """
        try:
            return self._is_mig
        except:
            if not self.gpu_available:
                self._is_mig = False
            else:
                self._is_mig = self.run_command('nvidia-smi mig  -lgip') != 'NO_GPU_AVAILABLE'
            return self._is_mig

    @property
    def total_memory(self):
        try:
            return self._total_memory
        except:
            self._total_memory = self.get_total_memory()
            return self._total_memory 

    def _get_gpu_memory(self, query):
        """
        parse gpu info from nvidia-smi
        """
        if not self.gpu_available:
            return 'NO_GPU_AVAILABLE'
        command = f'nvidia-smi --query-gpu={query} --format=csv,noheader,nounits'
        memory_value = self.run_command(command)
        memory_value = memory_value[:-1]
        memory_value = [int(x.split()[0]) for i, x in enumerate(memory_value)][0]
        return memory_value

    def _get_mig_memory(self, xml_path):
        """
        parse gpu info in mig mode
        """
        command = 'nvidia-smi -a -x'
        info = sp.check_output(command.split())
        gpu_tree = ET.ElementTree(ET.fromstring(info))
        memory_value = gpu_tree.find(xml_path).text
        memory_value = memory_value.split(' ')[0]
        memory_value = int(memory_value)
        return memory_value

    def get_total_memory(self):
        """
        get total gpu memory
        """
        try:
            if self.is_mig:
                memory_value = self._get_mig_memory('gpu/mig_devices/mig_device/fb_memory_usage/total')
            else:
                memory_value = self._get_gpu_memory('memory.total')
        except:
            memory_value = -1
        return memory_value

    def get_free_memory(self):
        """
        get free gpu memory
        """
        try:
            if self.is_mig:
                memory_value = self._get_mig_memory('gpu/mig_devices/mig_device/fb_memory_usage/free')
            else:
                memory_value = self._get_gpu_memory('memory.free')
        except:
            memory_value = -1
        return memory_value


class GPUInfoAPIRouter(GPUInfo):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.router = APIRouter()
        self.router.add_api_route('/gpu_info', self.gpu_info, methods=['GET'])

    def gpu_info(self):
        gpu_info = {
            'api_version': __version__
        }
        if self.gpu_available:
            gpu_info['total_memory_value'] = self.total_memory
            gpu_info['free_memory_value'] = self.get_free_memory()
        else:
            gpu_info['total_memory_value'] = -1
            gpu_info['free_memory_value'] = -1
        return gpu_info
