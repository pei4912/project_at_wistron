import os


def get_root_folder(default="request_data"):
    return os.getenv("ROOT_FOLDER", default)
