import json
import logging
import os
from io import BytesIO
from pathlib import Path
from typing import Dict, List

from minio import Minio
from PIL import Image
from urllib3 import PoolManager


ENDPOINT = os.getenv('MINIO_ENDPOINT', '')
ACCESS_KEY = os.getenv('MINIO_ACCESS_KEY', '')
SECRET_KEY = os.getenv('MINIO_SECRET_KEY', '')
BUCKET_NAME = os.getenv('MINIO_BUCKET_NAME', '')
DEPLOY_ENV = os.getenv('DEPLOY_ENV', '')
DEFAULT_FOLDER = f"aoi-genai-{DEPLOY_ENV}"
CA_CERTS = '/mnt/secrets-store/MINIO_CA_CERTS'


class MinioFileHandler:
    def __init__(
        self,
        default_folder: str=DEFAULT_FOLDER,
        bucket_name: str=BUCKET_NAME
    ):
        self.default_folder = Path(default_folder)
        self.bucket_name = bucket_name
        self.client = Minio(
            endpoint=ENDPOINT,
            access_key=ACCESS_KEY, secret_key=SECRET_KEY,
            http_client=PoolManager(cert_reqs='CERT_REQUIRED', ca_certs=CA_CERTS), secure=True
        )
        # check bucket
        try:
            found = self.client.bucket_exists(self.bucket_name)
        except:
            found = False
        if not found:
            logging.error(f'{bucket_name} doesnt exist')

    def list_objects(
        self,
        folder_path: str,
        recursive: bool=False
    ) -> List:
        """
        list all objects under folder path

        Args:
            folder_path: folder path
            recursive: retrieve all objects recursively
        """
        prefix = str(self.default_folder / folder_path) + '/'
        objs = [obj.object_name.split(prefix)[-1] for obj in self.client.list_objects(self.bucket_name, prefix=prefix, recursive=recursive)]
        return objs

    def get_image(self, file_path: str) -> Image.Image:
        """
        get image from minio server

        Args:
            file_path: image path
        """
        response = self.client.get_object(self.bucket_name, str(self.default_folder / file_path))
        image = Image.open(BytesIO(response.read()))
        response.close()
        response.release_conn()
        return image

    def get_annotations(self, file_path: str) -> dict:
        """
        get annotations from minio server

        Args:
            file_path: json path
        """
        response = self.client.get_object(self.bucket_name, str(self.default_folder / file_path))
        annotations = json.loads(response.read())
        return annotations

    def save_image(self, image: Image.Image, file_path: str, file_format: str='png') -> str:
        """
        save image to minio server

        Args:
            image
            file_path
            file_format
        """
        if file_format == 'jpg':
            file_format = 'jpeg'
        # convert to bytes
        buffered = BytesIO()
        image.save(buffered, format=file_format)
        buffered.seek(0)
        # save to minio
        self.client.put_object(
            self.bucket_name,
            str(self.default_folder / file_path),
            data=buffered,
            length=buffered.getbuffer().nbytes
        )
        return file_path

    def save_annotations(self, annotations: Dict, file_path: str) -> str:
        """
        save annotations to minio server

        Args:
            annotations
            file_path
        """
        # convert to bytes
        buffered = BytesIO(json.dumps(annotations, ensure_ascii=False).encode('utf-8'))
        # save to minio
        self.client.put_object(
            self.bucket_name,
            str(self.default_folder / file_path),
            data=buffered,
            length=buffered.getbuffer().nbytes
        )
        return file_path
