import os
import json
import requests
from typing import Tuple

from PIL import Image
import numpy as np

from utils import image_to_base64, base64_to_image
from .base import ImagePaste


DEEP_IMAGE_BLENDING_API_URL = os.getenv('DEEP_IMAGE_BLENDING_API_URL', 'http://172.28.0.5:8000')


class DeepImageBlendingPaste(ImagePaste):
    def __init__(self, epochs: int=300):
        self.epochs = epochs

    def __call__(
        self,
        image: np.array,
        pasted_image: np.array, pasted_mask: np.array,
        location: Tuple
    ):
        """
        request deep image blending to paste pasted_image onto the image
    
        Args:
            image: original image, [h, w, c], dtype: uint8
            pasted_image: image wants to be pasted onto original image, [h, w, c], dtype: uint8
            pasted_mask: region where should be crop, [h, w, 1], dtype: uint8
            location: center
        Returns:
            syn_image: new image with pasted_image pasted, [h, w, c], dtype: uint8
        """
        # convert to PIL
        image = Image.fromarray(image)
        pasted_image = Image.fromarray(pasted_image)
        pasted_mask = Image.fromarray(pasted_mask[..., 0], mode='L')
        # set request body
        request_body = {
            'src_inputs': [{'image': image_to_base64(image), 'location': location}],
            'trg_inputs': [{'image': image_to_base64(pasted_image), 'mask': image_to_base64(pasted_mask)}],
            'epochs': self.epochs
        }

        # request
        response = requests.post(f'{DEEP_IMAGE_BLENDING_API_URL}/deep_image_blending/generate', data=json.dumps(request_body), verify=False)

        # response
        if response.status_code == 200:
            syn_image = response.json()['gen_images'][0]['image']
            syn_image = base64_to_image(syn_image)
            syn_image = np.array(syn_image)
            return syn_image
        else:
            raise Exception("Deep Image Blending API Error")
