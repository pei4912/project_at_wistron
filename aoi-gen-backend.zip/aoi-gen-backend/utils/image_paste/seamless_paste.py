from typing import Tuple

import numpy as np
import cv2

from .base import ImagePaste


class SeamlessPaste(ImagePaste):
    def __call__(
        self,
        image: np.array,
        pasted_image: np.array, pasted_mask: np.array,
        location: Tuple,
        paste_method=cv2.MIXED_CLONE
    ):
        """
        paste pasted_image onto the image seamlessly

        Args:
            image: original image, [h, w, c], dtype: uint8
            pasted_image: image wants to be pasted onto original image, [h, w, c], dtype: uint8
            pasted_mask: region where should be crop, [h, w, 1], dtype: uint8
            location: center
            paste_method: cv2.MIXED_CLONE, cv2.NORMAL_CLONE, cv2.MONOCHROME_TRANSFER, 0
        Returns:
            syn_image: new image with pasted_image pasted, [h, w, c], dtype: uint8
        """
        # crop roi
        pasted_image, pasted_mask = self.crop_roi(pasted_image, pasted_mask)

        # check boundary to pad
        check_boundary = self.check_boundary(location, pasted_image.shape, image.shape)
        if check_boundary:
            # padding
            h, w, _ = image.shape
            top, bottom, left, right = h, h, w, w
            image = cv2.copyMakeBorder(image, top, bottom, left, right, cv2.BORDER_REPLICATE)
            location = [location[0] + left, location[1] + top]

        # seamless clone
        syn_image = cv2.seamlessClone(pasted_image, image, pasted_mask, location, paste_method)

        # crop
        if check_boundary:
            syn_image = syn_image[top:top+h, left:left+w]

        return syn_image
