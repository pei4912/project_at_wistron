from typing import Tuple

from PIL import Image
import numpy as np

from .base import ImagePaste


class DirectPaste(ImagePaste):
    def _apply_filter(
        self,
        image: np.array,
        region: Tuple,
        image_filter=None
    ):
        """
        apply image filter to region

        Args:
            image: original image, [h, w, c], dtype: uint8
            region: (left, top, right, bottom)
            image_filter: ImageFilter from PIL
        Returns:
            image: new image with image_filter in region, [h, w, c], dtype: uint8
        """
        image = Image.fromarray(image)
        image_filter = image.crop(region).filter(image_filter)
        image.paste(image_filter, region)
        image = np.array(image)
        return image
        
    def __call__(
        self,
        image: np.array,
        pasted_image: np.array, pasted_mask: np.array,
        location: Tuple,
        image_filter=None
    ):
        """
        paste pasted_image onto the image directly
    
        Args:
            image: original image, [h, w, c], dtype: uint8
            pasted_image: image wants to be pasted onto original image, [h, w, c], dtype: uint8
            pasted_mask: region where should be crop, [h, w, 1], dtype: uint8
            location: center
            image_filter: ImageFilter from PIL
        Returns:
            syn_image: new image with pasted_image pasted, [h, w, c], dtype: uint8
        """
        # crop roi
        pasted_image, pasted_mask = self.crop_roi(pasted_image, pasted_mask)

        # set location as center
        x, y = location
        h, w, _ = pasted_image.shape
        top = y - h // 2
        bottom = top + h
        left = x - w // 2
        right = left + w
        location = [left, top]

        # check mask
        _, _, c = image.shape
        mode = 'L' if c == 1 else 'RGB'
        if mode == 'L':
            image = image[..., 0]
            pasted_image = pasted_image[..., 0]

        # to PIL
        syn_image = Image.fromarray(image, mode=mode)
        pasted_image = Image.fromarray(pasted_image, mode=mode)
        pasted_mask = Image.fromarray(pasted_mask[..., 0], mode='L')

        # paste image
        syn_image.paste(pasted_image, location, pasted_mask)
        syn_image = np.array(syn_image)

        if image_filter:
            syn_image = self._apply_filter(syn_image, (left, top, right, bottom), image_filter)

        if mode == 'L':
            syn_image = syn_image[..., None]

        return syn_image
