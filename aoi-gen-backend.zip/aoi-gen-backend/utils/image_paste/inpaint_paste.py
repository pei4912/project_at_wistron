import numpy as np
import cv2

from .base import ImagePaste


class InpaintPaste(ImagePaste):
    def __call__(
        self,
        image: np.array, mask: np.array,
        pasted_image: np.array, pasted_mask: np.array
    ):
        """
        paste pasted_image onto the image with image inpaint method
    
        Args:
            image: original image, [h, w, c], dtype: uint8
            mask: region where should be inpaint, [h, w, 1], dtype: uint8
            pasted_image: image wants to be pasted onto original image, [h, w, c], dtype: uint8
            pasted_mask: region where should be crop, [h, w, 1], dtype: uint8
        Returns:
            syn_image: new image with pasted_image pasted, [h, w, c], dtype: uint8
        """
        # inpaint original image
        image_inpaint = image * (mask != True)
        image_inpaint = cv2.inpaint(image_inpaint, mask, 3, cv2.INPAINT_TELEA)

        # blend deformed image to original image
        kernel = cv2.getStructuringElement(cv2.MORPH_RECT, (3, 3))
        pasted_mask = cv2.erode(pasted_mask, kernel)[..., None]
        syn_image = image_inpaint * (pasted_mask != 1) + pasted_image * (pasted_mask)
        return syn_image
