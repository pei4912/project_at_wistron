from typing import Tuple

import numpy as np

from utils import crop_roi


class ImagePaste:
    @classmethod
    def check_boundary(
        cls,
        location: Tuple,
        src_shape: Tuple,
        dst_shape: Tuple
    ):
        """
        check pasted location out of boundary or not
    
        Args:
            location: center
            src_shape: shape of the image wants to be pasted onto original image
            dst_shape: shape of the original image
        """
        x, y = location
        src_h, src_w = src_shape[:2]
        dst_h, dst_w = dst_shape[:2]

        # check src bound
        top_bound = y - src_h // 2
        bottom_bound = y + src_h // 2
        left_bound = x - src_w // 2
        right_bound = x + src_w // 2

        # check boundary
        if (top_bound < 0) or (left_bound < 0) or (bottom_bound > dst_h) or (right_bound > dst_w):
            return True
        else:
            return False

    def crop_roi(
        self,
        pasted_image: np.array,
        pasted_mask: np.array
    ):
        """
        Args:
            pasted_image: image wants to be pasted onto original image, [h, w, c], dtype: uint8
            pasted_mask: region where should be crop, [h, w, 1], dtype: uint8
        """
        # crop roi
        pasted_image, _ = crop_roi(pasted_image, pasted_mask)
        pasted_mask, _ = crop_roi(pasted_mask, pasted_mask)
        return pasted_image, pasted_mask
