from .deep_image_blending_paste import DeepImageBlendingPaste
from .direct_paste import DirectPaste
from .inpaint_paste import InpaintPaste
from .seamless_paste import SeamlessPaste
