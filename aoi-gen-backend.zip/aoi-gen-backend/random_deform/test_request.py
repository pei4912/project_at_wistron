import requests

from app.base_model import RandomDeformInput


if __name__ == '__main__':
    # prepare data
    rd_gen_input = RandomDeformInput(
        dataset_id='dataset_id',
        dataset_source='local',
        inputs=[
            {'image': 'test_image1.bmp', 'annotations': 'test_image1.json'},
            {'image': 'test_image2.bmp', 'annotations': 'test_image2.json'},
        ],
        execute_on_backend=False,
        number_gen=5,
        amp_stddev=0.5,
        smooth_stddev=0.5,
        smooth_edge=0.5,
        random_vertical_offset=0.5,
        random_horizontal_offset=0.5
    )
    response = requests.post('http://localhost:8000/random_deform/generate', data=rd_gen_input.json())

    print(f'status code: {response.status_code}')
    print(f'api version: {response.json()["api_version"]}')
