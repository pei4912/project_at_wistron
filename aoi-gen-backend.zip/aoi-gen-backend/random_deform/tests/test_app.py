import os
import sys
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

from fastapi.testclient import TestClient

from app.main import app


client = TestClient(app)


def test_rd_gen_post():
    request_body = {
        'dataset_id': 'dataset_id',
        'inputs': [
            {'image': 'test_image1.bmp', 'annotations': 'test_image1.json'},
            {'image': 'test_image2.bmp', 'annotations': 'test_image2.json'}
        ],
        'execute_on_backend': False,
        'number_gen': 5,
        'amp_mean': 0,
        'amp_stddev': 0.5,
        'smooth_stddev': 0.5,
        'smooth_edge': 0.5,
        'random_vertical_offset': 0.5,
        'random_horizontal_offset': 0.5
    }

    response = client.post('/random_deform/generate', json=request_body)
    assert response.status_code == 200
