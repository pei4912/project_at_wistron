from typing import List, Dict

import numpy as np
import tensorflow as tf
import neurite as ne
import voxelmorph as vxm
from skimage.transform import PiecewiseAffineTransform, warp

from utils import image_to_mask, crop_roi


gpus = tf.config.list_physical_devices('GPU')
if gpus:
    [tf.config.experimental.set_memory_growth(gpu, True) for gpu in gpus]


def gaussian_smoothing(x, sigmas):
    """
    Blur Tensor of shape [*vol_shape, features] by applying a Gaussian  kernel.

    Important: last channel *must* be number of features! If it's not,
        the algorithm will likely not do what you want

    This function uses a (fixed) separable kernel.

    TODO: would be nice to have the ability to change the filter values
        without needing to re-create a tf graph.

    Args:
        x (Tensor): Tensor to be smoothed, of size [*vol_shape, C]
        sigmas (scalar or list of scalars): gaussian sigma

    Returns:
        Tensor: a smoothed Tensor of size [*vol_shape, C]

    Author: adalca
    https://github.com/adalca/neurite-sandbox/blob/master/neurite_sandbox/tf/utils/utils.py#L73
    """

    # input checking
    if x.dtype != tf.float32:
        x = tf.cast(x, 'float32')
    shape = x.shape.as_list()
    ndim = len(shape) - 1
    if not isinstance(sigmas, (tuple, list)):
        sigmas = [sigmas] * ndim
    assert len(sigmas) == ndim, \
        'incorrect number of sigmas passed: %d (needed: %d)' % (len(sigmas), ndim)

    kernel = [ne.utils.gaussian_kernel(s) for s in sigmas]
    return ne.utils.separable_conv(x, kernel)


def random_diffeomorphic_warp(vol_shape,
                              nb_steps=5,
                              amp_mean=0,
                              amp_stddev=1,
                              smooth_stddev=1,
                              return_inverse=False):
    """ Generate a random diffeomorphic deformation field

    Args:
        vol_shape (list): size of the volume, e.g. [100, 100, 100]
        nb_steps (int): number of integration steps for diffeomorphic integration
        amp_mean (int, optional): mean displacement amplitude. Defaults to 0.
        amp_stddev (int, optional): standard deviation of amplitude. Defaults to 1.
        smooth_stddev (int, optional): smoothness standard deviation.. Defaults to 1.
        return_inverse (bool): whether to return the inverse field as well.

    Returns:
        a warp field of size volshape + [ndim], e.g. [100, 100, 100, 3]
        or
        a tuple of the warp field *and* the inverse of the same size

    Author: adalca
    https://github.com/adalca/voxelmorph-sandbox/blob/master/voxelmorph_sandbox/tf/utils/utils.py#L363
    """

    field_shape = list(vol_shape) + [len(vol_shape)]

    field_rnd = tf.random.normal(shape=field_shape, mean=amp_mean, stddev=amp_stddev)
    smoothed_svf = gaussian_smoothing(field_rnd, smooth_stddev)

    field = vxm.utils.integrate_vec(smoothed_svf, nb_steps=nb_steps)

    if return_inverse:
        inv_field = vxm.utils.integrate_vec(-smoothed_svf, nb_steps=nb_steps)
        return field, inv_field

    else:
        return field


def _random_deform_image(
    image,
    amp_mean=0, amp_stddev=1, smooth_stddev=1,
    smooth_edge=0,
    random_vertical_offset=0, random_horizontal_offset=0
):
    """
    apply random deformation to input image

    Args:
        image (np.array): [h, w, c], dtype: uint8
        amp_mean (int, optional): mean displacement amplitude. Defaults to 0.
        amp_stddev (int, optional): standard deviation of amplitude. Defaults to 1.
        smooth_stddev (int, optional): smoothness standard deviation.. Defaults to 1.
        smooth_edge  (float, optional): make the edge of deformed image more smooth, default is 0 (no change)
        random_vertical_offset (int): vertical offset intensity. Defaults to 0 (no change)
        random_horizontal_offset (int): offset horizontal intensity. Defaults to 0 (no change)
    """
    h, w, c = image.shape
    # generate a random diffeomorphic deformation field
    rdw = random_diffeomorphic_warp(
        (h, w),
        amp_mean=amp_mean,
        amp_stddev=amp_stddev,
        smooth_stddev=smooth_stddev,
        return_inverse=False
    )
    # smooth edge
    if smooth_edge != 0:
        rdw *= linear_dec_std_tensor(vol_shape=(h, w, 2), alpha=1-smooth_edge)
    # deform image by channel
    image = image.astype('float32')
    deform_image = tf.concat([
        vxm.layers.SpatialTransformer(fill_value=0)([
            tf.expand_dims(image[..., i:i+1], axis=0),
            tf.expand_dims(rdw, axis=0)
        ])
        for i in range(c)
    ], axis=c)[0].numpy()
    deform_image = deform_image.astype('uint8')
    # random vertical offset
    deform_image = random_vertical_offset_image(deform_image, random_offset=random_vertical_offset)
    # random vertical offset
    deform_image = random_horizontal_offset_image(deform_image, random_offset=random_horizontal_offset)
    return deform_image


def random_deform_image(
    image, mask=None,
    amp_mean=0, amp_stddev=1, smooth_stddev=1,
    smooth_edge=0,
    random_vertical_offset=0, random_horizontal_offset=0
):
    """
    apply random deformation to input image
    if mask is not None: deform mask area and blend it to the original image

    Args:
        image (np.array): [h, w, c], dtype: uint8
        mask (np.array): [h, w, 1], dtype: uint8
        amp_mean (int, optional): mean displacement amplitude. Defaults to 0.
        amp_stddev (int, optional): standard deviation of amplitude. Defaults to 1.
        smooth_stddev (int, optional): smoothness standard deviation. Defaults to 1.
        smooth_edge  (float, optional): make the edge of deformed image more smooth, default is 0 (no change)
        random_vertical_offset (int): vertical offset intensity. Defaults to 0 (no change)
        random_horizontal_offset (int): offset horizontal intensity. Defaults to 0 (no change)
    Returns:
        deformed_image: deformed image
        deformed_mask: deformed mask
    """
    if mask is None:
        deformed_image = _random_deform_image(
            image,
            amp_mean, amp_stddev, smooth_stddev,
            smooth_edge=smooth_edge,
            random_vertical_offset=random_vertical_offset, random_horizontal_offset=random_horizontal_offset
        )
        return deformed_image, None

    # deform mask area
    deformed_image = np.zeros(image.shape, dtype=np.uint8)
    image, (top, bottom, left, right) = crop_roi(image * mask, mask)
    _deformed_image = _random_deform_image(
        image,
        amp_mean, amp_stddev, smooth_stddev,
        smooth_edge=smooth_edge,
        random_vertical_offset=random_vertical_offset, random_horizontal_offset=random_horizontal_offset
    )
    deformed_image[top:bottom, left:right] = _deformed_image
    deformed_mask = image_to_mask(deformed_image)
    return deformed_image, deformed_mask


def linear_dec_std_tensor(vol_shape, alpha=1):
    """
    Args:
        vol_shape (list): size of the volume, e.g. [100, 100, 2]
        alpha (float): exponent parameter to adjust the fall-off rate towards the edges, default is 1 (no change)
    Returns:
        std_decrement: normalized matrix, the center point is 1 and the edges are 0
    """
    num_dims = len(vol_shape)
    # create a grid of coordinates
    coords = [tf.range(s, dtype=tf.float32) for s in vol_shape]
    mesh = tf.meshgrid(*coords, indexing='ij')
    # calculate the distance from center of each point in the grid
    half_shape = [s // 2 for s in vol_shape]
    distances = sum([(mg - hs) ** 2 for mg, hs in zip(mesh, half_shape)])
    distances = distances ** (1/2)
    # normalize distances
    max_dist = tf.reduce_max(distances)
    normalized_distances = distances / (max_dist + 1e-7)
    # calculate linear decrement of standard deviation
    std_decrement = 1.0 - normalized_distances ** alpha
    return std_decrement


def random_vertical_offset_image(image, random_offset=0, size=2):
    """
    random vertical offset some locations of image

    Args:
        image (np.array): [h, w, c], dtype: uint8
        random_offset (int): offset intensity. Defaults to 0 (no change)
        size (int): number of location to offset
    Returns:
        offset_image (np.array): [h, w, c], dtype: uint8
    """
    if random_offset == 0:
        return image

    h, w, _ = image.shape
    # generate grid points of image
    num_grids = 10
    src_w = np.linspace(0, w, num_grids)
    src_h = np.linspace(0, h, num_grids)
    # for vertical
    src_h, src_w = np.meshgrid(src_h, src_w)
    src = np.vstack([src_w.flat, src_h.flat]).T

    # decide offset location
    dst = src.copy()
    # random locations and not include edge
    for l in range(1, num_grids - 1):
        # random direction
        direct = np.random.choice([1, -1, 0])
        dst[l*10:(l+1)*10, 1] += np.sin(np.linspace(0, np.pi, 10)) * random_offset * direct
    tform = PiecewiseAffineTransform()
    tform.estimate(src, dst)
    offset_image = warp(image, tform)
    offset_image = (offset_image * 255).astype('uint8')
    return offset_image


def random_horizontal_offset_image(image, random_offset=0, size=2):
    """
    random horizontal offset some locations of image

    Args:
        image (np.array): [h, w, c], dtype: uint8
        random_offset (int): offset intensity. Defaults to 0 (no change)
        size (int): number of location to offset
    Returns:
        offset_image (np.array): [h, w, c], dtype: uint8
    """
    if random_offset == 0:
        return image

    h, w, _ = image.shape
    # generate grid points of image
    num_grids = 10
    src_w = np.linspace(0, w, num_grids)
    src_h = np.linspace(0, h, num_grids)
    # for horizontal
    src_w, src_h = np.meshgrid(src_w, src_h)
    src = np.vstack([src_w.flat, src_h.flat]).T

    # decide offset location
    dst = src.copy()
    # random locations and not include edge
    for l in range(1, num_grids - 1):
        # random direction
        direct = np.random.choice([1, -1, 0])
        direct = 1 if np.random.uniform() > 0.5 else -1
        dst[l*10:(l+1)*10, 0] += np.sin(np.linspace(0, np.pi, 10)) * random_offset * direct
    tform = PiecewiseAffineTransform()
    tform.estimate(src, dst)
    offset_image = warp(image, tform)
    offset_image = (offset_image * 255).astype('uint8')
    return offset_image
