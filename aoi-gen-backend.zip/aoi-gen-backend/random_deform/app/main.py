from datetime import datetime
import logging

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from utils import BaseExecutor, ProgressRouter
from utils.system.gpu import GPUInfoAPIRouter
from utils.system.file_stream import FileStreamingAPIRouter
from .base_model import RandomDeformInput, RandomDeformOutput


logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(levelname)s - %(message)s",
    datefmt="%Y-%m-%d %H:%M:%S",
)
app = FastAPI()
app.add_middleware(
    CORSMiddleware,
    allow_origins=['*'],
    allow_credentials=True,
    allow_methods=['*'],
    allow_headers=['*'],
)
app.include_router(GPUInfoAPIRouter().router)
app.include_router(FileStreamingAPIRouter().router)
app.include_router(ProgressRouter().router)
rd_executor = BaseExecutor()


@app.post('/random_deform/generate', response_model=RandomDeformOutput)
def rd_gen_post(rd_gen_input: RandomDeformInput) -> RandomDeformOutput:
    """
    generate random deformed images
    """
    # set task_id
    task_id = f"RandomDeform/{datetime.now().strftime('%Y%m%d_%H%M%S')}"
    logging.info("Task ID: %s", task_id)
    # init progress
    rd_executor.init_execution_status(task_id)
    rd_executor.update_execution_status(task_id=task_id, total=rd_gen_input.number_gen, current=0)
    # set dataset_id
    dataset_id = f"{task_id}/gen_images"
    logging.info("Dataset ID: %s", dataset_id)
    if rd_gen_input.dataset_source == 'local':
        rd_executor.create_task_id_folder(dataset_id)

    # save request to disk
    rd_executor.save_to_disk(file=rd_gen_input, task_id=task_id, file_name='rd_gen_input')
    # execute script via command line
    rd_executor.execute(
        execute_script='execute.py', execute_on_backend=rd_gen_input.execute_on_backend,
        task_id=task_id, dataset_id=dataset_id
    )

    # execute script via command line
    rd_executor.execute(
        execute_script='execute.py', execute_on_backend=rd_gen_input.execute_on_backend,
        task_id=task_id, dataset_id=dataset_id,
        number_gen=rd_gen_input.number_gen
    )

    # prepare response
    response = RandomDeformOutput(task_id=task_id, dataset_id=dataset_id, dataset_source=rd_gen_input.dataset_source)
    return response
