from typing import List, Dict
from pydantic import BaseModel

from utils._version import __version__


BaseModel.model_config['protected_namespaces'] = {}


class RandomDeformInput(BaseModel):
    """
    config request input for random deformation

    Args:
        dataset_id: load images from $ROOT_FOLDER/dataset_id
        dataset_source: local / minio
            - local: load/save data from/to local disk
            - minio: load/save data from/to minio
        inputs:
        [
            {
                'image': image, as a file name
                'annotations': annotations of source image, as a file name
            }
        ]

        execute_on_backend: execute surface defect process on the backend process
        number_gen: number of generated images

        amp_mean: mean displacement amplitude. Defaults to 0.
        amp_stddev: standard deviation of amplitude. Defaults to 0.5.
        smooth_stddev: smoothness standard deviation. Defaults to 0.5.
        smooth_edge: make edge more smooth. Defaults to 0.0
        random_vertical_offset: random vertical offset image. Defaults to 0.0
        random_horizontal_offset: random vertical offset image. Defaults to 0.0
    """
    dataset_id: str
    dataset_source: str = 'local'
    inputs: List[Dict]

    execute_on_backend: bool = True
    number_gen: int = 5

    amp_mean: float = 0.0
    amp_stddev: float = 0.5
    smooth_stddev: float = 0.5
    smooth_edge: float = 0.0
    random_vertical_offset: float = 0.0
    random_horizontal_offset: float = 0.0


class RandomDeformOutput(BaseModel):
    """
    config response output for random deformation

    Args:
        task_id: folder to save task files
        dataset_id: folder to save dataset
        dataset_source: local or minio
        api_version: the version of api
    """
    task_id: str
    dataset_id: str
    dataset_source: str
    api_version: str = __version__
