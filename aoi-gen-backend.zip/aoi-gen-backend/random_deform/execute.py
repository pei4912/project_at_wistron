import os
import argparse
from random import sample
from tqdm import trange
import logging

import numpy as np
from PIL import Image

from utils import BaseExecutor, BaseRequestProcessor, BaseResponseProcessor
from utils import InpaintPaste, polygon_to_mask
from app import AMP_STDDEV_FACTOR, SMOOTH_STDDEV_FACTOR, RANDOM_OFFSET_FACTOR
from app.random_deform import random_deform_image


# parse the commandline
parser = argparse.ArgumentParser()
parser.add_argument('--task-id', '--task_id', required=True, type=str)
parser.add_argument('--dataset-id', '--dataset_id', required=True, type=str)
args = parser.parse_args()


rd_executor = BaseExecutor()
rd_request_processor = BaseRequestProcessor()
rd_response_processor = BaseResponseProcessor()
# load data
rd_gen_input = rd_executor.load_from_disk(task_id=args.task_id, file_name="rd_gen_input")
inpaint_paster = InpaintPaste()


def main(
    task_id, dataset_id,
    gen_input,
    executor, request_processor, response_processor
):
    # get dataset source
    dataset_source = gen_input.dataset_source

    if dataset_source == 'local':
        # prepare inputs from local disk
        inputs = request_processor.prepare_from_disk(request_inputs=gen_input.inputs, dataset_id=gen_input.dataset_id)
    elif dataset_source == 'minio':
        # prepare inputs from minio
        inputs = request_processor.prepare_from_minio(request_inputs=gen_input.inputs, dataset_id=gen_input.dataset_id)

    amp_stddev = AMP_STDDEV_FACTOR * gen_input.amp_stddev
    smooth_stddev = SMOOTH_STDDEV_FACTOR * gen_input.smooth_stddev
    smooth_edge = gen_input.smooth_edge
    random_vertical_offset = RANDOM_OFFSET_FACTOR * gen_input.random_vertical_offset
    random_horizontal_offset = RANDOM_OFFSET_FACTOR * gen_input.random_horizontal_offset

    for gen_idx, _ in enumerate(trange(gen_input.number_gen)):
        # random sample src input
        input_dict = sample(inputs, 1)[0]
        src_image = input_dict['image_array']

        # decide defect area
        if input_dict['have_annotation'] and len(input_dict['ng_shapes']) > 0:
            defect_polygons = [shape['points'] for shape in input_dict['ng_shapes']]
            src_mask = polygon_to_mask(shape=input_dict['shape'], polygon_points=defect_polygons, convert_format='np')
            have_mask = True
        else:
            src_mask = None
            have_mask = False

        # deform defect area
        deformed_image, deformed_mask = random_deform_image(
            src_image, src_mask,
            amp_stddev=amp_stddev, smooth_stddev=smooth_stddev,
            smooth_edge=smooth_edge,
            random_vertical_offset=random_vertical_offset, random_horizontal_offset=random_horizontal_offset
        )

        # inpaint image
        if have_mask:
            deformed_image = inpaint_paster(src_image, src_mask, deformed_image, deformed_mask)

        # convert to response format
        src_filename = input_dict.get('image', 'gen_image.png')
        gen_filename, _ = response_processor.gen_filename(full_filename=src_filename, idx=gen_idx)

        # save gen image
        image = Image.fromarray(deformed_image)
        if dataset_source == 'local':
            image_save_path = os.path.join(executor.root_folder, dataset_id, gen_filename)
            image.save(image_save_path)
        elif dataset_source == 'minio':
            image_save_path = os.path.join(dataset_id, gen_filename)
            request_processor.minio.save_image(image, image_save_path)

        # update progress
        executor.update_execution_status(
            task_id=task_id,
            total=gen_input.number_gen,
            current=gen_idx + 1
        )


try:
    main(
        args.task_id, args.dataset_id,
        rd_gen_input,
        rd_executor, rd_request_processor, rd_response_processor
    )
    # update final progress
    rd_executor.update_execution_status(task_id=args.task_id, total=rd_gen_input.number_gen, current='completed')
except Exception as e:
    logging.error("Task ID %s failed: %s", args.task_id, e)
    # update error progress
    rd_executor.update_execution_status(task_id=args.task_id, total=rd_gen_input.number_gen, current='error')
