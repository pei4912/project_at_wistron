import json
import requests

from PIL import Image
from utils import image_to_base64, polygon_to_mask
from app.base_model import DeepImageBlendingInput


if __name__ == '__main__':
    trg_image = Image.open('test_data/trg_image.bmp')
    with open('test_data/trg_image.json', 'r') as f:
        trg_label = json.load(f)
    points = [shape['points'] for shape in trg_label['shapes']]
    trg_mask = polygon_to_mask(trg_image.size[::-1], points)

    dib_input = DeepImageBlendingInput(
        src_inputs=[{'image': image_to_base64(trg_image), 'location': [60, 60]}],
        trg_inputs=[{'image': image_to_base64(trg_image), 'mask': image_to_base64(trg_mask)}],
        epochs=1
    )
    response = requests.post('http://localhost:8000/deep_image_blending/generate', data=dib_input.json())

    print(f'status code: {response.status_code}')
    print(f'api version: {response.json()["api_version"]}')
