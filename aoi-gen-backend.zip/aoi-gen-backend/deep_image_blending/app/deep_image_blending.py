from typing import List, Dict

from utils import BaseRequestProcessor


class DeepImageBlendingRequestProcessor(BaseRequestProcessor):
    def prepare_from_base64(self, request_inputs: List[Dict]) -> List[Dict]:
        """
        prepare request inputs as
            1. image_array: np.ndarray
            2. shape: tuple
            3. mask_array
        Args:
            request_inputs: {
                'image': base64 string,
                'mask': base64 string,
                'location': [x, y]
            }
        Returns:
            request_inputs
        """
        # prepare inputs
        for request_input in request_inputs:
            request_input['image_array'], request_input['shape'] = self.convert_image(content=request_input['image'], convert_format='np')

            # for mask
            mask = request_input.get('mask', None)
            if mask is not None:
                request_input['mask_array'], _ = self.convert_image(content=request_input['mask'], convert_format='np')
        return request_inputs

    def __call__(self, request_inputs: List[Dict]) -> List[Dict]:
        """
        Args:
            request_inputs: {
                'image': base64 string,
                'mask': base64 string,
                'location': [x, y]
            }
        Returns:
            request_inputs
        """
        request_inputs = self.prepare_from_base64(request_inputs)
        return request_inputs
