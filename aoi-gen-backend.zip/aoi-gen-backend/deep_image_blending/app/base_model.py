from typing import Optional, List, Dict
from pydantic import BaseModel

from utils._version import __version__


BaseModel.model_config['protected_namespaces'] = {}


class DeepImageBlendingInput(BaseModel):
    """
    config request input for deep image blending

    Args:
        src_inputs:
        [
            {
                'image': source image, str
                'location': random location of source image, Tuple, [x, y]
            }
        ]
        trg_inputs:
        [
            {
                'image': target image, str
                'mask': target mask, str
            }
        ]
        epochs: number of epochs for training DeepImageBlending
    """
    src_inputs: List[Dict]
    trg_inputs: List[Dict]
    epochs: int = 300


class DeepImageBlendingOutput(BaseModel):
    """
    config response output for deep image blending, used base64 string as response

    Args:
        gen_images: list of generated images as base64 format
        [
            {
                'image': generated image as base64 format, str
            }
        ]
        api_version: the version of api
    """
    gen_images: List[Dict]
    api_version: str = __version__
