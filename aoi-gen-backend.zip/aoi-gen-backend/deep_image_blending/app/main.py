import os
import logging
from datetime import datetime
from pathlib import Path

from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from PIL import Image
import numpy as np

from utils import image_to_base64, DirectPaste, get_root_folder
from utils import BaseExecutor, ProgressRouter
from utils.system.gpu import GPUInfoAPIRouter
from utils.system.file_stream import FileStreamingAPIRouter
from .base_model import DeepImageBlendingInput, DeepImageBlendingOutput
from .deep_image_blending import DeepImageBlendingRequestProcessor


app = FastAPI()
app.add_middleware(
    CORSMiddleware,
    allow_origins=['*'],
    allow_credentials=True,
    allow_methods=['*'],
    allow_headers=['*'],
)
gpu_info_api_router = GPUInfoAPIRouter()
app.include_router(gpu_info_api_router.router)
app.include_router(FileStreamingAPIRouter().router)
app.include_router(ProgressRouter().router)
deep_image_blending_request = DeepImageBlendingRequestProcessor()
deep_image_blending_executor = BaseExecutor()
direct_paster = DirectPaste()
GPU_MEMORY_USAGE = 2622
ROOT_FOLDER = get_root_folder('request_data')


@app.post('/deep_image_blending/generate', response_model=DeepImageBlendingOutput)
def deep_image_blending_post(dib_input: DeepImageBlendingInput) -> DeepImageBlendingOutput:
    """
    run deep image blending
    """
    # check gpu available
    memory_free_value = gpu_info_api_router.get_free_memory()
    if memory_free_value == 'NO_GPU_AVAILABLE':
        raise HTTPException(status_code=500, detail='NO_GPU_AVAILABLE')
    else:
        if memory_free_value < GPU_MEMORY_USAGE * 1.05:
            raise HTTPException(status_code=500, detail='NO_GPU_AVAILABLE')

    # get source and target image
    src_inputs = deep_image_blending_request(dib_input.src_inputs)
    trg_inputs = deep_image_blending_request(dib_input.trg_inputs)

    # image blending
    blended_images = []
    for src_input, trg_input in zip(src_inputs, trg_inputs):

        # execute script via command line to release gpu memory
        task_id = f"DeepImageBlending/{datetime.now().strftime('%Y%m%d_%H%M%S')}"
        logging.info("Task ID: %s", task_id)
        tmp_model_folder = Path(ROOT_FOLDER) / task_id
        os.makedirs(tmp_model_folder, exist_ok=True)

        # get background and defect
        src_image = src_input['image_array']
        src_shape = src_input['shape']
        src_location = src_input['location']
        trg_image = trg_input['image_array']
        trg_mask = trg_input['mask_array'][..., None]
        trg_shape = trg_input['shape']

        # calculate crop and scale defect area
        scale = determine_largest_scale(location=src_location, src_shape=src_shape, trg_shape=trg_shape)
        if scale >= 1:
            # calculate crop and scale defect area
            crop_h = scale * trg_shape[0]
            crop_w = scale * trg_shape[1]
            crop_top = src_location[1] - crop_h
            crop_left = src_location[0] - crop_w
            # crop bg image and paste to fg image
            bg_image = src_image[crop_top:crop_top+crop_h*2, crop_left:crop_left+crop_w*2]
            location = (crop_w, crop_h)
            do_scale_crop = True
        else:
            bg_image = src_image
            location = src_location
            do_scale_crop = False
        bg_shape = bg_image.shape[:2]
        fg_image = direct_paster(bg_image, trg_image, trg_mask, location=location)
        fg_mask = direct_paster(np.zeros((*bg_shape, 1), dtype='uint8'), trg_mask, trg_mask, location=location)

        # save to execute Deep Image Blending
        path_bg_image = tmp_model_folder / 'bg_image.bmp'
        Image.fromarray(bg_image).save(path_bg_image)
        path_fg_image = tmp_model_folder / 'fg_image.bmp'
        Image.fromarray(fg_image).save(path_fg_image)
        path_fg_mask = tmp_model_folder / 'fg_mask.bmp'
        Image.fromarray(fg_mask[..., 0], mode='L').save(path_fg_mask)

        # execute script via command line
        executed_result = deep_image_blending_executor.execute(
            execute_script='run.py', execute_on_backend=False,
            source_file=path_fg_image, mask_file=path_fg_mask, target_file=path_bg_image,
            output_dir=tmp_model_folder,
            ss=512, ts=512, x=256, y=256,
            gpu=0, num_steps=dib_input.epochs
        )
        if executed_result != 0:
            raise HTTPException(status_code=500, detail='deep image blending error')

        # load gen image and background image
        gen_image = Image.open(tmp_model_folder / 'first_pass.png')
        gen_image = gen_image.resize(bg_shape[::-1])
        blended_image = Image.fromarray(src_image)

        if do_scale_crop:
            paste_left = crop_left
            paste_top = crop_top
        else:
            # crop defect area
            h, w = trg_shape
            paste_left = location[0] - w // 2
            paste_top = location[1] - h // 2
            gen_image = gen_image.crop((paste_left, paste_top, paste_left + w, paste_top + h))
        blended_image.paste(gen_image, (paste_left, paste_top))

        # convert to base64
        blended_images.append({'image': image_to_base64(blended_image)})

    # prepare response
    response = DeepImageBlendingOutput(gen_images=blended_images)
    return response


def determine_largest_scale(
    location,
    src_shape, trg_shape,
    max_scale=5
):
    src_h, src_w = src_shape
    trg_h, trg_w = trg_shape

    # calculate maximize candicated scale
    scale_h = min(location[1], src_h - location[1]) // trg_h
    scale_w = min(location[0], src_w - location[0]) // trg_w
    scale = max(min(scale_h, scale_w, max_scale), 0)
    return scale
