import argparse
import json
import requests

from PIL import Image
from utils import image_to_base64


def prepare_data():
    src_image = Image.open('test_data/src_image.bmp')
    src_image = image_to_base64(src_image)
    trg_image = Image.open('test_data/trg_image.bmp')
    trg_image = image_to_base64(trg_image)

    with open('test_data/src_image.json', 'r') as f:
        src_label = json.load(f)
    src_label = [shape['points'] for shape in src_label['shapes'] if shape['label'] == 'line']
    with open('test_data/trg_image.json', 'r') as f:
        trg_label = json.load(f)
    trg_label = [shape['points'] for shape in trg_label['shapes'] if shape['label'] == 'line']
    return src_image, src_label, trg_image, trg_label


if __name__ == '__main__':
    # parse the commandline
    parser = argparse.ArgumentParser()
    parser.add_argument('--api-route', required=True, type=str, help='which route to be tested. (train or inference)')
    parser.add_argument('--model-id', type=str, help='must have if api-route is inference')
    args = parser.parse_args()

    # prepare data
    src_image, src_label, trg_image, trg_label = prepare_data()

    if args.api_route == 'train':
        bodys = {
            'src_inputs': [
                {'image': src_image, 'polygons': src_label, 'filname': 'src_image.bmp'} for _ in range(5)
            ],
            'trg_inputs': [
                {'image': trg_image, 'polygons': trg_label, 'filname': 'trg_image.bmp'} for _ in range(1)
            ],
            'hyp_min': 0.0,
            'hyp_max': 1.0,
            'number_gen': 5,
            'epochs': 1,
            'batch_size': 1
        }
        response = requests.post('http://localhost:8000/voxelmorph/train', data=json.dumps(bodys))
    elif args.api_route == 'inference':
        bodys = {
            'model_id': args.model_id,
            'src_inputs': [
                {'image': src_image, 'polygons': src_label} for _ in range(5)
            ],
            'trg_inputs': [
                {'image': trg_image, 'polygons': trg_label} for _ in range(1)
            ],
            'hyp_min': 0.0,
            'hyp_max': 1.0,
            'number_gen': 40,
            'response_type': 'dataset_id'
        }
        response = requests.post('http://localhost:8000/voxelmorph/inference', data=json.dumps(bodys))
    else:
        raise(f'error arguments: {args.api_route}')

    print(f'status code: {response.status_code}')
    print(f'model id: {response.json()["model_id"]}')
    print(f'api version: {response.json()["api_version"]}')
