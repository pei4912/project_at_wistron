import os
from typing import Tuple, List, Dict
import logging
from datetime import datetime
import pytz

import numpy as np
import cv2
import voxelmorph as vxm
import tensorflow as tf
from tensorflow.keras import backend as K

from utils import image_to_mask, crop_roi
from .base import RequestProcessor


tf.compat.v1.disable_eager_execution()
tf.compat.v1.experimental.output_all_intermediates(True)
[tf.config.experimental.set_memory_growth(device, True) for device in tf.config.list_physical_devices('GPU')]
tf.keras.backend.clear_session()


ROOT_FOLDER = 'request_data'
INSHAPE = (160, 160)
NUM_FEATS = 3
BATCH_SIZE = 32
# batch_size 32: 2578
# batch_size 1: 1042
GPU_MEMORY_USAGE = 2578
EPOCHS = 1000
LEARNING_RATE = 1e-4


class VoxelMorphRequestProcessor(RequestProcessor):
    def __init__(self, resize_shape: Tuple[int, int] = INSHAPE, **kwargs):
        self.resize_shape = resize_shape
        super().__init__(**kwargs)

    def prepare_vxm_inputs(self, inputs: List[Dict]) -> List[Dict]:
        """
        add vxm's preprocessing
            1. vxm_image: np.ndarray
            2. vxm_mask: np.ndarray
            3. crop_infos
        """
        for input in inputs:
            # set default vxm_image
            input['vxm_image'] = input['image']
            if self.convert_polygons_to_mask and input['have_annotation']:
                input['vxm_image'] = input['image'] * input['mask']

            # crop image and mask
            if input['mask'].sum() == 0:
                # if no mask -> use all image
                do_crop = False
                (crop_top, crop_bottom, crop_left, crop_right) = (0, 0, *input['shape'])
            else:
                do_crop = True
                input['vxm_image'], (crop_top, crop_bottom, crop_left, crop_right) = crop_roi(input['vxm_image'], input['mask'])
            input['vxm_mask'] = image_to_mask(input['vxm_image'] != 0)
            input['crop_infos'] = {
                'do_crop': do_crop,
                'crop_top': crop_top,
                'crop_left': crop_left,
                'crop_bottom': crop_bottom,
                'crop_right': crop_right,
                'crop_shape': input['vxm_image'].shape[:2]
            }

            # resize image and mask
            if self.resize_shape != (None, None):
                input['vxm_image'] = cv2.resize(input['vxm_image'], self.resize_shape)
                input['vxm_mask'] = image_to_mask(input['vxm_image'] != 0)

            # convert to 0~1
            input['vxm_image'] = input['vxm_image'] / 255.0
        return inputs

    def __call__(self, inputs: List[Dict]) -> List[Dict]:
        """
        Args:
            inputs: {
                'image': base64 string,
                'polygons': [[[x, y]]]
            }
        Returns:
            inputs
        """
        inputs = self.prepare_from_base64(inputs)
        inputs = self.prepare_vxm_inputs(inputs)
        return inputs


class HyperMorph:
    """
    Ref:
    https://ahoopes.github.io/hypermorph/tutorial.html
    https://github.com/voxelmorph/voxelmorph/blob/dev/scripts/tf/train_hypermorph.py
    """
    def __init__(
        self,
        model_id: str
    ):
        self.model_id = model_id
        self.model_folder = os.path.join(ROOT_FOLDER, 'VoxelMorph', model_id)
        self.model_weights = os.path.join(self.model_folder, 'model_weights.h5')
        # initialize HyperMorph
        self.model = vxm.networks.HyperVxmDense(
            inshape=INSHAPE,
            nb_unet_features=[[16, 32, 32, 32], [32, 32, 32, 32, 32, 16, 16]],
            int_steps=7,
            int_resolution=2,
            src_feats=NUM_FEATS,
            trg_feats=NUM_FEATS,
            svf_resolution=2
        )
        # check model exists or prepare folder
        if os.path.exists(self.model_weights):
            logging.info(f'load weights from: {self.model_weights}')
            self.model.load_weights(self.model_weights)
            self.load_model = True
        else:
            logging.info(f'create folder at: {self.model_folder}')
            os.makedirs(self.model_folder, exist_ok=True)
            self.load_model = False

    def random_hyperparam(self, oversample_rate):
        if np.random.rand() < oversample_rate:
            return np.random.choice([0, 1])
        else:
            return np.random.rand()

    def hyp_generator(self, src_images, trg_images, batch_size: int = BATCH_SIZE, oversample_rate: float = 0.2):
        """
        Args:
            src_images: list of src image
            trg_images: list of trg image
            batch_size: batch_size
            oversample_rate: hyperparameter end-point over-sample rate
        """
        # random training index
        num_src = len(src_images)
        index_src = np.random.randint(low=0, high=num_src, size=batch_size)
        num_trg = len(trg_images)
        index_trg = np.random.randint(low=0, high=num_trg, size=batch_size)
        # filter training pairs
        src_image = np.concatenate([src_images[i][None] for i in index_src])
        trg_image = np.concatenate([trg_images[i][None] for i in index_trg])
        zeros = np.zeros([batch_size, *INSHAPE, NUM_FEATS], dtype='float32')

        while True:
            hyp = np.expand_dims([self.random_hyperparam(oversample_rate) for _ in range(batch_size)], -1)
            hyp_inputs = [src_image, trg_image, hyp]
            hyp_outputs = [trg_image, zeros]
            yield (hyp_inputs, hyp_outputs)

    def train(
        self,
        src_images: List[np.array], trg_images: List[np.array],
        batch_size: int = BATCH_SIZE, epochs: int = EPOCHS, lr: float = LEARNING_RATE
    ):
        # add data generator
        generator = self.hyp_generator(src_images=src_images, trg_images=trg_images, batch_size=batch_size)

        # prepare loss functions and compile model
        scaling = 1.0 / (0.05 ** 2)
        image_loss_func = lambda x1, x2: scaling * K.mean(K.batch_flatten(K.square(x1 - x2)), -1)

        def image_loss(y_true, y_pred):
            hyp = (1 - tf.squeeze(self.model.references.hyper_val))
            return hyp * image_loss_func(y_true, y_pred)

        def grad_loss(y_true, y_pred):
            hyp = tf.squeeze(self.model.references.hyper_val)
            return hyp * vxm.losses.Grad('l2', loss_mult=2).loss(y_true, y_pred)

        # compile model
        self.model.compile(optimizer=tf.keras.optimizers.legacy.Adam(lr=lr), loss=[image_loss, grad_loss])

        # train model
        progress_callback = ProgressCallBack(model_id=self.model_id, total_epochs=epochs)
        save_callback = tf.keras.callbacks.ModelCheckpoint(self.model_weights, period=200)
        history = self.model.fit_generator(
            generator,
            epochs=epochs,
            steps_per_epoch=1,
            verbose=0,
            callbacks=[progress_callback, save_callback]
        )

        # save model weights
        self.model.save_weights(self.model_weights)

        # record complete model training
        progress_callback.on_epoch_end(epoch='completed')
        return history

    def predict(
        self,
        src_image: np.array, trg_image: np.array,
        hyp: float
    ) -> np.array:

        slice, flow = self.model.predict([src_image[None], trg_image[None], np.array([hyp])])
        return slice, flow


class ProgressCallBack(tf.keras.callbacks.Callback):
    def __init__(
        self,
        model_id: str, total_epochs: int
    ):
        self.model_id = model_id
        self.total_epochs = total_epochs
        self.progress_file = os.path.join(ROOT_FOLDER, 'VoxelMorph', model_id, 'progress.txt')
        with open(self.progress_file, 'a') as f:
            f.write('total,current,time\n')

    def on_epoch_end(self, epoch, logs=None):
        # epoch +1
        if type(epoch) == str:
            pass
        else:
            epoch += 1
        with open(self.progress_file, 'a') as f:
            f.write(f"{self.total_epochs},{epoch},{datetime.now(pytz.timezone('Asia/Taipei'))}\n")
