import os
from datetime import datetime
from typing import Union

from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from PIL import Image
import numpy as np
import cv2

from utils import image_to_base64, image_to_mask, InpaintPaste
from utils.system.gpu import GPUInfoAPIRouter
from utils.system.file_stream import FileStreamingAPIRouter
from app.base import ResponseProcessor, BaseExecutor
from app.base_model import VxmTrainInput, VxmTrainOutput, VxmInferInput, VxmInferBase64Output, VxmInferIDOutput, VxmProgressInput, VxmProgressOutput, VxmCurrentOutput
from app.voxel_morph import VoxelMorphRequestProcessor, HyperMorph, GPU_MEMORY_USAGE


app = FastAPI()
app.add_middleware(
    CORSMiddleware,
    allow_origins=['*'],
    allow_credentials=True,
    allow_methods=['*'],
    allow_headers=['*'],
)
app.infer_model_id = ''
app.infer_model_id_training = ''
app.infer_model = None
gpu_info_api_router = GPUInfoAPIRouter()
app.include_router(gpu_info_api_router.router)
app.include_router(FileStreamingAPIRouter().router)

vxm_request = VoxelMorphRequestProcessor(convert_polygons_to_mask=True)
vxm_executor = BaseExecutor()
inpaint_paster = InpaintPaste()


@app.get('/voxelmorph/train', response_model=VxmCurrentOutput)
def vxm_train_get() -> VxmCurrentOutput:
    """
    voxelmorph training model_id
    """
    response = VxmCurrentOutput(model_id=app.infer_model_id_training)
    return response


@app.post('/voxelmorph/train', response_model=VxmTrainOutput)
def vxm_train_post(vxm_train_input: VxmTrainInput) -> VxmTrainOutput:
    """
    voxelmorph training
    """
    # check gpu available
    memory_free_value = gpu_info_api_router.get_free_memory()
    if memory_free_value == 'NO_GPU_AVAILABLE':
        gpu_number = -1
    else:
        if memory_free_value < GPU_MEMORY_USAGE * 1.05:
            raise HTTPException(status_code=500, detail='NO_GPU_AVAILABLE')
        else:
            gpu_number = 0

    # model_id
    model_id = datetime.now().strftime('%Y%m%d_%H%M%S')
    print(f'train model_id: {model_id}')
    app.infer_model_id_training = model_id

    # get source and target image
    src_inputs = vxm_request(vxm_train_input.src_inputs)
    trg_inputs = vxm_request(vxm_train_input.trg_inputs)

    # execute script via command line to release gpu memory
    dataset_id = os.path.join('VoxelMorph', model_id)
    vxm_executor.save_to_disk(file=[input['vxm_image'] for input in src_inputs], dataset_id=dataset_id, file_name='vxm_src_images')
    vxm_executor.save_to_disk(file=[input['vxm_image'] for input in trg_inputs], dataset_id=dataset_id, file_name='vxm_trg_images')

    executed_result = vxm_executor.execute(
        execute_script='execute.py', run_on_backend=True,
        model_id=model_id,
        epochs=vxm_train_input.epochs, batch_size=vxm_train_input.batch_size
    )
    if executed_result != 0:
        raise HTTPException(status_code=500, detail=f'model_id: {model_id} training error.')

    # prepare for response
    response = VxmTrainOutput(model_id=model_id)
    return response


@app.post('/voxelmorph/inference', response_model=Union[VxmInferBase64Output, VxmInferIDOutput])
def vxm_infer_post(vxm_infer_input: VxmInferInput) -> Union[VxmInferBase64Output, VxmInferIDOutput]:
    """
    voxelmorph inference
    """
    print(f'Number of Gen Images: {vxm_infer_input.number_gen}')
    response_type = vxm_infer_input.response_type
    if response_type == 'base64':
        dataset_id = ''
        dataset_save_folder = ''
    elif response_type == 'dataset_id':
        dataset_id = os.path.join('VoxelMorph', vxm_infer_input.model_id, datetime.now().strftime('%Y%m%d_%H%M%S'))
        dataset_save_folder = os.path.join('request_data', dataset_id)
        os.makedirs(dataset_save_folder)
    print(f"Response Type: {response_type} {dataset_id}")

    # check whether to switch a new model
    if vxm_infer_input.model_id != app.infer_model_id:
        # initiate a new model
        app.infer_model_id = vxm_infer_input.model_id
        hyper_morph = HyperMorph(app.infer_model_id)
        app.infer_model = hyper_morph
        # check model exist or not
        if not hyper_morph.load_model:
            raise HTTPException(status_code=404, detail=f'model_id: {app.infer_model_id} is not existed.')
    else:
        # inherit model from app.infer_model
        hyper_morph = app.infer_model
    print(f'infer model_id: {app.infer_model_id}')

    # get source and target image
    src_inputs = vxm_request(vxm_infer_input.src_inputs)
    trg_inputs = vxm_request(vxm_infer_input.trg_inputs)

    # predict
    hyps = np.linspace(vxm_infer_input.hyp_min, vxm_infer_input.hyp_max, vxm_infer_input.number_gen)
    # random pred index
    num_src = len(src_inputs)
    index_srcs = np.random.randint(low=0, high=num_src, size=len(hyps))
    num_trg = len(trg_inputs)
    index_trgs = np.random.randint(low=0, high=num_trg, size=len(hyps))

    moved_images = []
    for gen_idx, (hyp, index_src, index_trg) in enumerate(zip(hyps, index_srcs, index_trgs)):
        src_input = src_inputs[index_src]
        trg_input = trg_inputs[index_trg]
        # predict moved image
        slice, _ = hyper_morph.predict(src_input['vxm_image'], trg_input['vxm_image'], hyp)
        moved_image = (slice[0] * 255).astype('uint8')

        # recover crop image
        if src_input['crop_infos']['do_crop']:
            moved_image = cv2.resize(moved_image, src_input['crop_infos']['crop_shape'][::-1])
            pasted_image = np.zeros((*src_input['shape'], 3), dtype='uint8')
            crop_top, crop_left, crop_bottom, crop_right = [src_input['crop_infos'][c] for c in ['crop_top', 'crop_left', 'crop_bottom', 'crop_right']]
            pasted_image[crop_top:crop_bottom, crop_left:crop_right] = moved_image
        else:
            pasted_image = cv2.resize(moved_image, src_input['shape'][::-1])
        pasted_mask = image_to_mask(pasted_image != 0)

        # inpaint image
        syn_image = inpaint_paster(
            src_input['image'],
            src_input['mask'],
            pasted_image,
            pasted_mask
        )

        # convert to response format
        src_filename = src_input.get('filename', '')
        trg_filename = trg_input.get('filename', '')
        gen_filename, file_format = ResponseProcessor.gen_filename(filename=src_filename, idx=gen_idx)

        # prepare response depends on response_type
        image = Image.fromarray(syn_image)
        if response_type == 'base64':
            moved_images.append({
                'hyp': hyp,
                'src_id': index_src,
                'trg_id': index_trg,
                'moved_image': image_to_base64(image, file_format=file_format),
                'src_filename': src_filename,
                'trg_filename': trg_filename,
                'gen_filename': gen_filename
            })
        elif response_type == 'dataset_id':
            image_save_path = os.path.join(dataset_save_folder, gen_filename)
            image.save(image_save_path)

    # prepare response
    if response_type == 'base64':
        response = VxmInferBase64Output(moved_images=moved_images, model_id=app.infer_model_id)
    elif response_type == 'dataset_id':
        response = VxmInferIDOutput(dataset_id=dataset_id, model_id=app.infer_model_id)
    return response


@app.post('/voxelmorph/progress', response_model=VxmProgressOutput)
def vxm_progress_post(vxm_progress_input: VxmProgressInput) -> VxmProgressOutput:
    """
    voxelmorph training progress
    """
    try:
        model_id = vxm_progress_input.model_id
        dataset_id = os.path.join('VoxelMorph', model_id)
        total_epochs, current_epochs, current_time = vxm_executor.get_execution_status(dataset_id=dataset_id)
        response = VxmProgressOutput(
            model_id=vxm_progress_input.model_id,
            total_epochs=total_epochs,
            current_epochs=current_epochs
        )
    except Exception:
        response = VxmProgressOutput(model_id=vxm_progress_input.model_id)
    return response
