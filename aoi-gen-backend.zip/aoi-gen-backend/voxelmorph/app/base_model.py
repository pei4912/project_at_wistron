from typing import List, Dict, Union
from pydantic import BaseModel

from utils._version import __version__


BaseModel.model_config['protected_namespaces'] = {}


class VxmTrainInput(BaseModel):
    """
    config request input for voxelmorph training

    Args:
        src_inputs:
        [
            {
                'image': source image as base64 format, str
                'polygons': polygon points of source image, [List[List[Tuple]]
                'filename': filename of image
            }
        ]
        trg_inputs:
        [
            {
                'image': target image as base64 format, str
                'polygons': polygon points of target image, [List[List[Tuple]]
                'filename': filename of image
            }
        ]
        hyp_min: a hyperparameter to control the tradeoff between similarity and smoothness
        hyp_max: a hyperparameter to control the tradeoff between similarity and smoothness
        number_gen: number of moved images, hyp from np.linspace(hyp_min, hyp_max, number_gen)
        epochs: number of epochs for HyperMorph training
        batch_size: batch size for HyperMorph training
    """
    src_inputs: List[Dict]
    trg_inputs: List[Dict]
    hyp_min: float = 0.0
    hyp_max: float = 1.0
    number_gen: int = 5
    epochs: int = 1000
    batch_size: int = 32


class VxmTrainOutput(BaseModel):
    """
    config request output for voxelmorph training

    Args:
        model_id: used for inference
        api_version: the version of api
    """
    model_id: str
    api_version: str = __version__


class VxmInferInput(BaseModel):
    """
    config request input for voxelmorph inference

    Args:
        model_id: used for inference
        src_inputs:
        [
            {
                'image': source image as base64 format, str
                'polygons': polygon points of source image, [List[List[Tuple]]
            }
        ]
        trg_inputs:
        [
            {
                'image': target image as base64 format, str
                'polygons': polygon points of target image, [List[List[Tuple]]
            }
        ]
        hyp_min: a hyperparameter to control the tradeoff between similarity and smoothness
        hyp_max: a hyperparameter to control the tradeoff between similarity and smoothness
        number_gen: number of moved images, hyp from np.linspace(hyp_min, hyp_max, number_gen)
        response_type: base64 or dataset_id
            - base64: VxmInferBase64Output
            - dataset_id: VxmInferIDOutput
    """
    model_id: str
    src_inputs: List[Dict]
    trg_inputs: List[Dict]
    hyp_min: float = 0.0
    hyp_max: float = 1.0
    number_gen: int = 5
    response_type: str = 'base64'


class VxmInferBase64Output(BaseModel):
    """
    config response output for voxelmorph inference, used base64 string as response

    Args:
        moved_images: list of moved images as base64 format
        [
            {
                'hyp': hyp 1
                'src_id': src id 1
                'trg_id': trg id 1
                'moved_image': moved image 1
                'src_filename'
                'trg_filename'
                'gen_filename'
            }
        ]
        model_id: used for inference
        api_version: the version of api
    """
    moved_images: List[Dict[str, Union[float, str]]]
    model_id: str
    api_version: str = __version__


class VxmInferIDOutput(BaseModel):
    """
    config response output for voxelmorph inference, used dataset_id as response

    Args:
        dataset_id: folder to save files
        model_id: used for inference
        api_version: the version of api
    """
    dataset_id: str
    model_id: str
    api_version: str = __version__


class VxmProgressInput(BaseModel):
    """
    config request input for voxelmorph training progress

    Args:
        model_id
    """
    model_id: str


class VxmProgressOutput(BaseModel):
    """
    config request output for voxelmorph training progress

    Args:
        model_id
        api_version: the version of api
        total_epochs: total epochs for hypermorph model training
        current_epochs: current epochs for hypermorph model training
    """
    model_id: str
    api_version: str = __version__
    total_epochs: str = '0'
    current_epochs: str = '0'


class VxmCurrentOutput(BaseModel):
    """
    current loaded model

    Args:
        model_id
        api_version: the version of api
    """
    model_id: str
    api_version: str = __version__
