import os
import json
from pathlib import Path, PosixPath
from typing import Union, List, Dict, Tuple
import pickle

from PIL import Image
import numpy as np

from utils import get_root_folder, base64_to_image, polygon_to_mask


ROOT_FOLDER = get_root_folder('request_data')
NOT_INCLUDE_LABEL = ['OK', '__background__']


class RequestProcessor:
    root_folder=ROOT_FOLDER
    not_include_label=NOT_INCLUDE_LABEL

    def __init__(self, convert_polygons_to_mask: bool=False):
        """
        Args:
            convert_polygons_to_mask: convert polygons to mask if polygons are given
        """
        self.convert_polygons_to_mask = convert_polygons_to_mask

    def _base64_to_image(self, base64_string: str, format: str='np') -> Union[Image.Image, np.ndarray]:
        """
        convert base 64 string to PIL.Image
        """
        image = base64_to_image(base64_string)
        if format == 'np':
            image = np.array(image)
        return image

    def _binaryfile_to_image(self, format: str='np') -> Union[Image.Image, np.ndarray]:
        """
        convert binary file to PIL.Image
        """
        raise NotImplementedError

    def _diskfile_to_image(self, path: str, format: str='np') -> Union[Image.Image, np.ndarray]:
        """
        load image from path and convert to PIL.Image
        """
        image = Image.open(path).convert('RGB')
        if format == 'np':
            image = np.array(image)
        return image

    def convert_image(self, content: str, format: str='np') -> Tuple[Union[Image.Image, np.ndarray], Tuple]:
        """
        convert to image from
            1. path
            2. base64 string
            3. binary file
        Args:
            content
        Returns:
            image: np.ndarray or PIL.Image
            shape: [h, w]
        """
        if isinstance(content, PosixPath):
            image = self._diskfile_to_image(content, format=format)
        elif isinstance(content, str):
            image = self._base64_to_image(content, format=format)
        shape = image.shape[:2]
        return image, shape

    def prepare_from_base64(self, inputs: List[Dict]) -> List[Dict]:
        """
        prepare request inputs as
            1. image: np.ndarray
            2. shape
            3. have_annotation
            4. mask: if have_annotation
        Args:
            inputs: {
                'image': base64 string,
                'polygons': [[[x, y]]]
            }
        Returns:
            inputs
        """
        # prepare inputs
        for input in inputs:
            input['image'], input['shape'] = self.convert_image(content=input['image'], format='np')

            # set default have_annotation
            input['have_annotation'] = False
            # load polygons from file
            if input.get('polygons'):
                if input['polygons'] != [[[None, None]]]:
                    input['have_annotation'] = True

            # convert polygons to mask
            if self.convert_polygons_to_mask and input['have_annotation']:
                mask = polygon_to_mask(input['shape'], input['polygons'])
                mask = (np.array(mask)[..., None] / 255).astype('uint8')
                input['mask'] = mask
            else:
                input['mask'] = np.zeros((*input['shape'], 1), dtype='uint8')
        return inputs

    def prepare_from_disk(self, inputs: List[Dict], dataset_id: str) -> List[Dict]:
        """
        prepare request inputs as
            1. image: np.ndarray
            2. shape
            3. have_annotation
            4. ng_shapes: if have_annotation
            5. bg_shapes: if have_annotation
            6. mask: if have_annotation
        Args:
            inputs: {
                'image': file path,
                'polygons': file path
            }
            dataset_id: load files
                root_folder / {dataset_id} / {files}
        Returns:
            inputs
        """
        # check dataset id to decide load images/polygons from files or request values
        dataset_folder = Path(self.root_folder) / dataset_id

        # prepare inputs
        for input in inputs:
            # load image from file
            path = dataset_folder / input['image']
            input['image'], input['shape'] = self.convert_image(content=path, format='np')

            # set default have_annotation
            input['have_annotation'] = False
            # load polygons from file
            if input.get('polygons'):
                input['have_annotation'] = True
                path = dataset_folder / input['polygons']
                with open (path, 'r') as f:
                    annotations = json.load(f)
                input['ng_shapes'] =  [shape for shape in annotations['shapes'] if shape['label'] not in self.not_include_label]
                input['bg_shapes'] =  [shape for shape in annotations['shapes'] if shape['label'] in self.not_include_label]

            # convert polygons to mask
            if self.convert_polygons_to_mask and input['have_annotation']:
                raise NotImplementedError
            else:
                input['mask'] = np.zeros((*input['shape'], 1), dtype='uint8')
        return inputs

    def __call__(self):
        raise NotImplementedError


class ResponseProcessor:
    @classmethod
    def gen_filename(
        cls,
        filename: str='', idx: Union[str, int]='',
        _filename: str='gen_image', fileformat: str='png'
    ):
        """
        generate the filename of generated image
        Args:
            filename: xxx.png
            idx: 1
        Returns:
            gen_filename: x-1.png
            fileformat: png
        """
        if filename:
            _filename, fileformat = filename.split('.')
        gen_filename = f"{_filename}-{idx}.{fileformat}"
        return gen_filename, fileformat


class BaseExecutor:
    root_folder=ROOT_FOLDER

    def set_dataset_id_folder(
        self,
        dataset_id
    ):
        """
        set dataset id folder: root_folder / datset_id
        
        Args:
            dataset_id
        """
        return Path(self.root_folder) / dataset_id

    def save_to_disk(
        self,
        file,
        dataset_id, file_name
    ):
        """
        save file as pickle: root_folder / dataset_id / file_name.pkl

        Args:
            file
            dataset_id
            file_name
        """
        dataset_folder = self.set_dataset_id_folder(dataset_id)
        os.makedirs(dataset_folder, exist_ok=True)
        path = dataset_folder / f"{file_name}.pkl"
        with open(path, "wb") as f:
            pickle.dump(file, f)
        return str(path)

    def load_from_disk(
        self,
        dataset_id, file_name
    ):
        """
        load file from pickle: root_folder / dataset_id / file_name.pkl

        Args:
            dataset_id
            file_name
        """
        dataset_folder = self.set_dataset_id_folder(dataset_id)
        path = dataset_folder / f"{file_name}.pkl"
        with open(path, "rb") as f:
            file = pickle.load(f)
        return file

    def get_execution_status(
        self,
        dataset_id
    ):
        """
        get execution status: root_folder / dataset_id / progress.txt

        Args:
            dataset_id
        """
        dataset_folder = self.set_dataset_id_folder(dataset_id)
        with open(dataset_folder / 'progress.txt', 'r') as f:
            total, current, time = f.readlines()[-1].strip().split(",")
        return total, current, time

    def execute(
        self,
        execute_script='execute.py', run_on_backend=True,
        **kwargs
    ):
        """
        execute python script with args
        """
        # prepare command
        command = f'python {execute_script}'
        if kwargs:
            args = [f'--{arg} {value}' for arg, value in kwargs.items()]
            args = ' '.join(args)
            command += f" {args}"

        # run script in backend process
        if run_on_backend:
            command += '&'

        executed_result = os.system(command)
        return executed_result
