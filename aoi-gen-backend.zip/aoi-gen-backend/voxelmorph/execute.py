import os
import argparse

from app.base import BaseExecutor
from app.voxel_morph import HyperMorph


# parse the commandline
parser = argparse.ArgumentParser()
parser.add_argument('--model-id', '--model_id', required=True, type=str)
parser.add_argument('--epochs', required=True, type=int)
parser.add_argument('--batch-size', '--batch_size', required=True, type=int)
args = parser.parse_args()

# load data
vxm_executor = BaseExecutor()
dataset_id = os.path.join('VoxelMorph', args.model_id)
vxm_src_images = vxm_executor.load_from_disk(dataset_id=dataset_id, file_name="vxm_src_images")
vxm_trg_images = vxm_executor.load_from_disk(dataset_id=dataset_id, file_name="vxm_trg_images")

# train model
hyper_morph = HyperMorph(args.model_id)
history = hyper_morph.train(vxm_src_images, vxm_trg_images, epochs=args.epochs, batch_size=args.batch_size)
