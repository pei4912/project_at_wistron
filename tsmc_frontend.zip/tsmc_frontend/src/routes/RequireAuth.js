import { Navigate, useLocation } from "react-router-dom";

export default function RequireAuth(props) {
  const { children } = props;
  const isAuth = localStorage.getItem('auth')
  const { pathname, search, hash } = useLocation();

  if (!isAuth) {
    return <Navigate replace to="/login" state={{ from: { pathname, search, hash } }} />
  }
  return children
}