import LoginPage from "../pages/Login";

export const publicRoutes = [
  {
    path: '/login',
    Component: LoginPage
  }
];

export const privateRoutes = [
  {
    index: true, lazy: () => import('../pages/Analysis/index'),
  },
  {
    path: 'analysis', lazy: () => import('../pages/Analysis/index')
  }
]