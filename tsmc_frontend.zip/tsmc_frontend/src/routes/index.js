import { Outlet, createBrowserRouter } from "react-router-dom";
import { privateRoutes, publicRoutes } from "./routes";
import RequireAuth from "./RequireAuth";
import '../App.less';

const router = createBrowserRouter([
  ...publicRoutes,
  {
    path: '/',
    element: (
      <RequireAuth>
        <div className="App">
          <Outlet />
        </div>
      </RequireAuth>
    ),
    children: privateRoutes,
  }
]);

export default router