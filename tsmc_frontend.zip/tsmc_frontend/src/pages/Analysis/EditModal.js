import { useEffect } from "react";
import { Col, Form, Modal, Row, Select } from "antd";
import { useDispatch, useSelector } from "react-redux"
import { setEditModalVisible, modalSubmit } from "../../store/slice/analysisSlice";
import TextArea from "antd/es/input/TextArea";
import { TextButton, TextButtonFilled } from "../../components/Button";

const EditModal = () => {
  const [form] = Form.useForm();
  const { editModalVisible, editData, cols } = useSelector(state => state.analysis);
  const { selectedModel } = useSelector(state => state.menu);
  const dispatch = useDispatch();

  const handleOk = () => {
    form
      .validateFields()
      .then((values) => {
        dispatch(setEditModalVisible(false));
        dispatch(modalSubmit(values))
        form.resetFields();
      })
      .catch((info) => {
        console.log('Validate Failed', info);
        form.resetFields();
      });
  };
  const handleCancel = () => {
    dispatch(setEditModalVisible(false));
  };
  const getLabel = (labelKey) => {
    return cols.find(col => col.dataIndex === labelKey)?.title
  };
  
  useEffect(() => {
    editData['醫師分級'] !== undefined ? form.setFieldsValue(editData) : form.resetFields();
  }, [editData]);

  return (
    <Modal title={editData.col0 ? `代碼 ${editData.col0}` : 'Edit'} open={editModalVisible} onCancel={handleCancel} width={600} footer={null} centered forceRender >
      <div style={{ height: 500, overflow: 'auto' }}>
        {
          Object.keys(editData).map((title) => (
            (
              title === '代碼'
              || title === 'Chest CT胸(肺)部電腦斷層'
              || title === '靜態心電圖'
              || title === 'Coronary CT冠狀動脈電腦斷層'
              || title === '緯創分級結果'
            ) &&
            <Row key={title} style={{ marginBottom: 25 }}>
              <Col span={8} style={{ textAlign: 'right', paddingRight: 8 }}>{getLabel(title)} :</Col>
              <Col span={16} style={{ paddingLeft: 10, whiteSpace: "pre-wrap" }}>
                {editData[title]}
              </Col>
            </Row>
          ))
        }
        <Form
          form={form}
          labelCol={{ span: 8 }}
          name={editData.key}
          onFinish={handleOk}
        >
          <Form.Item label='醫師分級' name='醫師分級'>
            <Select
              key='醫師分級'
              options={selectedModel && selectedModel.levels}
            />
          </Form.Item>
          <Form.Item label='醫師說明' name='醫師說明'>
            <TextArea autoSize={{ minRows: 3, maxRows: 6 }} />
          </Form.Item>
          <div style={{ width: '100%', display: 'flex', justifyContent: 'end' }}>
            <TextButton onClick={(e) => { e.preventDefault(); handleCancel() }}>Cancel</TextButton>
            <TextButtonFilled type="submit" style={{ marginLeft: '6px' }}>Submit</TextButtonFilled>
          </div>
        </Form>
      </div>
    </Modal>
  )
};

export default EditModal;