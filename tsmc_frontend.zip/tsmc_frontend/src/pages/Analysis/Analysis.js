import React from "react";
import { useNavigate } from "react-router-dom";
import { useDispatch, useSelector } from "react-redux";
import { Layout, Menu, message, Row, Col, Table, Spin, Tooltip, Button, Upload } from 'antd';
import { ExcelRenderer } from 'react-excel-renderer';
import { apiGetAllFiles, apiLogout, apiPostEditedAnalysis, apiPostRawData } from "../../utils/API";
import { convertDate2String } from '../../utils';
import { COL_WIDTH_SETTING, INIT_MENU_ITEMS } from '../../utils/constant';
import { IconButton, TextButton, TextButtonFilled } from '../../components/Button';
import EditModal from "./EditModal";
import './Analysis.css';
// reducer function
import { setSelectedModel, setMenu, setSelectedMenu } from "../../store/slice/menuSlice";
import { setCols, setRows, setDataCnt, setIsLoading, setEditData, setEditModalVisible, setIsEditing, updateTable, setUploadData } from "../../store/slice/analysisSlice";
// Images
import ImgLogoWistronMed from '../../static/logo_wistron_med.png';
import { ReactComponent as IconEdit } from '../../static/IconEdit.svg';
import { ReactComponent as IconEditDisabled } from '../../static/IconEditDisable.svg';
import { ReactComponent as IconPlus } from '../../static/IconPlus.svg';

const { Header, Content, Sider } = Layout;
const { Dragger } = Upload;

const Analysis = () => {
  const { model, selectedModel, menu, selectedMenu } = useSelector(state => state.menu);
  const { rows, cols, dataCnt, isLoading, isEditing, originRows, uploadData } = useSelector(state => state.analysis);
  const { token } = useSelector(state => state.auth);

  const dispatch = useDispatch();

  const navigate = useNavigate();

  const handleLogout = () => {
    apiLogout(token);
    localStorage.clear();
    navigate('/');
  };

  // 取得所有檔案列表
  const getAllFiles = (fileId) => {
    dispatch(setUploadData({}));
    apiGetAllFiles(selectedModel.key)
      .then((response) => {
        const responseData = response.data.results.data;
        const result = JSON.parse(JSON.stringify(INIT_MENU_ITEMS));
        responseData.forEach((item) => {
          result.push({
            key: item.file_id,
            label: <Tooltip title={item.file_name}>
              <div className="menu-item-label">
                {getStatusLight(item.status)}{item.file_name}
              </div>
            </Tooltip>,
            file_name: item.file_name,
            created_at: convertDate2String(item.created_at),
            file_url: item.file_url,
          })
        });

        dispatch(setMenu(result));
        dispatch(setSelectedMenu(fileId
          ? result.find((element) => element.key === fileId)
          : INIT_MENU_ITEMS[0]))
      })
  };

  // 逐行編輯
  const rowEditOnclick = (record) => {
    dispatch(setEditData(record));
    dispatch(setEditModalVisible(true));
  };

  const uploadOnclick = () => {
    apiPostRawData(uploadData)
      .then((response) => {
        const fileId = response.data.results.id;
        getAllFiles(fileId);
      })
  }

  // 上傳excel參數
  const uploadProps = {
    name: 'file',
    multiple: true,
    fileList:[],
    headers: {
      authorization: 'authorization-text',
    },
    showUploadList: false,
    // 上傳檔案時的提示文字
    onChange(info) {
      const { status } = info.file;
      if (status === 'done') {
        message.success(`${info.file.name} file uploaded successfully.`);
      } else if (status === 'error') {
        message.error(`${info.file.name} file upload failed.`);
      }
    },
    // 把excel的處理放在beforeUpload事件，否則要把文件上傳到通過action指定的地址去後台處理
    beforeUpload: (file, fileList) => {
      var rABS = true;
      const f = fileList[0];
      var reader = new FileReader();
      // 檢查一次只能上傳一個
      if (fileList.length > 1) {
        message.error("請勿上傳多個檔案！");
        dispatch(setUploadData({}));
        return false;
      }
      // 如果不是 excel(目前僅支援.xlsx)，則不處理檔案
      let fileSuffix = file.name.substr(file.name.lastIndexOf("."));
      if (".xlsx" !== fileSuffix) {
        message.error("請上傳 .xlsx 格式的檔案!");
        dispatch(setUploadData({}));
        return false;
      } else {
        ExcelRenderer(file, (err, resp) => {
          if (err) {
            console.log(err);
            dispatch(setUploadData({}));
          } else if (!resp.rows
            || (selectedModel.key === 'ldct' && !resp.rows[0].includes('Chest CT胸(肺)部電腦斷層'))
            || (selectedModel.key === 'ekg' && !resp.rows[0].includes('靜態心電圖'))
            || (selectedModel.key === 'cct' && !resp.rows[0].includes('Coronary CT冠狀動脈電腦斷層'))
          ) {
            message.error("檔案欄位名稱錯誤，請參考範本!")
          } else {
            dispatch(setUploadData({
              'file_name': file.name,
              'file_data': file,
              'category': selectedModel.key,
              'data_cnt': resp.rows.length - 1,
            }))
          }
        });
      }
      if (rABS) reader.readAsBinaryString(f); else reader.readAsArrayBuffer(f);
      return false;
    }
  };

  // 將 excel 檔案轉成 table 的格式
  const excelToTable = (fileObj) => {
    //just pass the fileObj as parameter
    ExcelRenderer(fileObj, (err, resp) => {
      if (err) {
        console.log(err);
      }
      else {
        const tempTitleArr = []
        // 檔案內的第一列為標題列，如果有緯創分級結果出現就增加編輯行
        const col = resp.rows[0].map(
          (colName, idx) => {
            tempTitleArr.push(colName)
            return {
              title: colName,
              dataIndex: colName,
              key: colName,
              width: COL_WIDTH_SETTING[colName] && COL_WIDTH_SETTING[colName],
            }
          }
        )
        const colsNew = resp.rows[0].includes('緯創分級結果') ? col.concat([{
          title: <TextButton style={{ backgroundColor: 'white', border: 'white' }} onClick={() => dispatch(setIsEditing(true))}>Edit</TextButton>,
          width: 120,
          align: 'center',
          render: (_, record) => {
            return (
              <div style={{ display: 'flex', justifyContent: 'center' }}>
                <IconButton onClick={() => rowEditOnclick(record)} disabled>
                  <IconEditDisabled width={20} height={20} />
                </IconButton>
              </div>
            )
          }
        }]) : col;
        // 第二列之後的資料對應標題塞值，其中 Object 裡的 key 為標題的 dataIndex
        const rowsNew = resp.rows.slice(1, 101).map(
          (rowData, idx) => {
            let temp = { key: `row${idx}` };
            rowData.forEach(
              (row, idxCol) => {
                temp[tempTitleArr[idxCol]] = row;
              }
            );
            return temp;
          }
        );
        dispatch(setCols(colsNew));
        dispatch(setRows(rowsNew));
        dispatch(setDataCnt(resp.rows.length - 1));
        dispatch(setIsLoading(false));
      }
    });
  };

  // 根據分析狀態，顯示不同的狀態燈號
  const getStatusLight = (status) => {
    switch (status) { //0:處理中 1:處理成功 2:處理失敗 3:已刪除
      case 0:
        return <div className="status-light-process" />;
      case 1:
        return <div className="status-light-success" />;
      case 2:
        return <div className="status-light-error" />;
      default:
        return <div className="status-light-process" />;
    }
  };

  // 表格送出上傳
  const tableEditedUpload = () => {
    const colArr = [];
    const targetTitleArr = [...cols];
    targetTitleArr.pop();
    targetTitleArr.map((col) => colArr.push(col.title));
    const rowArr = rows.map(row =>
      targetTitleArr.reduce((acc, title) => {
        acc[title.title] = row[title.key] || '';
        return acc;
      }, {})
    );

    apiPostEditedAnalysis({ id: selectedMenu.key, data: { columns: [...colArr], data: [...rowArr] } })
      .then(response => console.log(response))
      .catch(err => console.log(err))
    dispatch(updateTable('submit'));
    dispatch(setIsEditing(false));
  }

  // 初始畫面，取得所有檔案
  React.useEffect(() => {
    selectedModel && getAllFiles()
  }, [selectedModel]);

  // menu item 有變更時，取得檔案內容
  React.useEffect(() => {
    dispatch(setIsEditing(false))
    dispatch(setCols([]));
    dispatch(setRows([]));
    dispatch(setUploadData({}));
    if (selectedMenu.key !== 'add') {
      dispatch(setDataCnt(0));
      dispatch(setIsLoading(true));
      fetch(selectedMenu.file_url)
        .then(res => res.blob()) // returns URL data a blob
        .then((fileObj) => excelToTable(fileObj))
    }
  }, [selectedMenu]);

  // 表格編輯按鈕啟動/送出/取消處理
  React.useEffect(() => {
    const copyCols = [...cols];
    if (copyCols.find(value => value.title === '緯創分級結果')) {
      copyCols.splice(cols.length - 1, 1, !isEditing ? {
        title: <TextButton style={{ backgroundColor: 'white', border: 'white' }} onClick={() => dispatch(setIsEditing(true))}>Edit</TextButton>,
        width: 120,
        align: 'center',
        fixed: 'right',
        render: (_, record) => {
          return (
            <div style={{ display: 'flex', justifyContent: 'center' }}>
              <IconButton onClick={() => rowEditOnclick(record)} disabled>
                <IconEditDisabled width={20} height={20} />
              </IconButton>
            </div>
          )
        }
      } : {
        title: <div>
          <TextButton
            style={{ color: 'white', borderColor: 'white' }}
            onClick={() => {
              dispatch(updateTable('cancel'));
              dispatch(setIsEditing(false));
            }}>Cancel</TextButton>
          <TextButton
            style={{ backgroundColor: JSON.stringify(originRows) === JSON.stringify(rows) ? '#c4c4c4' : 'white', borderColor: JSON.stringify(originRows) === JSON.stringify(rows) ? '#c4c4c4' : 'white', marginLeft: 4 }}
            disabled={JSON.stringify(originRows) === JSON.stringify(rows)}
            onClick={() => tableEditedUpload()}>Upload</TextButton>
        </div>,
        width: 200,
        align: 'center',
        fixed: 'right',
        render: (_, record) => {
          return (
            <div style={{ display: 'flex', justifyContent: 'center' }}>
              <IconButton onClick={() => rowEditOnclick(record)}>
                <IconEdit width={20} height={20} fill='#C4C4C4' />
              </IconButton>
            </div>
          )
        }
      })
      dispatch(setCols(copyCols))
    }
  }, [isEditing, originRows, rows]);

  return (
    <Layout>
      <Header className="header-container">
        <img src={ImgLogoWistronMed} alt="" className="logo" />
        <Menu
          mode="horizontal"
          items={model}
          onClick={(item) => { dispatch(setSelectedModel(model.find((element) => element.key === item.key))) }}
          selectedKeys={selectedModel.key}
          className="menu"
        />
        <Button onClick={handleLogout}>Logout</Button>
      </Header>
      <Layout className="content-container">
        <Sider style={{ backgroundColor: 'black' }}>
          <Menu
            // theme="dark"
            items={menu}
            onClick={(item) => { !isEditing || JSON.stringify(originRows) === JSON.stringify(rows) ? dispatch(setSelectedMenu(menu.find((element) => element.key === item.key))) : alert('請先上傳編輯資料！') }}
            selectedKeys={selectedMenu.key}
          />
        </Sider>
        <Layout className="content">
          <Content>
            {(selectedMenu.key !== 'add') && <Row style={{ paddingTop: 12, paddingBottom: 12 }}>
              <Col span={12}>◆檔案名稱：{selectedMenu.file_name}</Col>
              <Col span={8}>◆上傳時間：{selectedMenu.created_at}</Col>
              <Col span={4}>◆總筆數：{dataCnt}</Col>
            </Row>}
            {(selectedMenu.key === 'add') &&
              <>
                <Row>
                  <Col span={8} style={{ display: 'flex', alignItems: 'center' }}>◆請上傳您的檔案(*.xlsx)：</Col>
                  <Col span={8} offset={8} style={{ display: 'flex', justifyContent: 'flex-end' }}>
                    <div style={{ padding: '10px' }}>
                      <a
                        className="download-temp-file"
                        download
                        href={`/temp_file/${selectedModel.label}_Temp.xlsx`}
                      >下載範本</a>
                    </div>
                  </Col>
                </Row>
                <Row style={{ paddingBlock: 15 }}>
                  <Col style={{ display: "flex", justifyContent: "center", width: "100%" }}>
                    <Dragger {...uploadProps}>
                      <p className="ant-upload-drag-icon">
                        <IconPlus width={100} height={100} />
                      </p>
                      {uploadData.file_name && <div style={{ marginTop: '-1em' }}>{uploadData.file_name}</div>}
                      <p className="ant-upload-text" style={{ color: 'gray' }}>上傳（拖拉或是瀏覽檔案）</p>
                    </Dragger>
                  </Col>
                </Row>
                <Row>
                  <Col span={24} style={{ display: 'flex', flexDirection: 'row', alignItems: 'center', justifyContent: 'flex-end' }}>
                    <div style={{ display: 'flex', marginRight: 14 }}>總筆數：{uploadData.data_cnt ? uploadData.data_cnt : 0} 筆</div>
                    <TextButtonFilled disabled={!uploadData.data_cnt} onClick={() => uploadOnclick()}>確認上傳</TextButtonFilled>
                  </Col>
                </Row>
              </>
            }
            {(selectedMenu.key !== 'add') &&
              <Row style={{ marginTop: 15 }}>
                <div className="analysis-add" style={{ width: '100%' }}>
                  {isLoading
                    ? <Spin style={{ display: 'flex', justifyContent: 'center' }} />
                    : <>
                      <Table
                        dataSource={rows}
                        columns={cols}
                        style={{ width: '100%', whiteSpace: "break-spaces" }}
                        rowClassName={(_, idx) =>
                          idx % 2 === 0 ? "table-row-light" : "table-row-dark"
                        }
                        scroll={{ y: "calc(100vh - 240px)", x: cols.find(value => value.title === '醫師分級') !== undefined ? 1400 : {}, }}
                      />
                      <EditModal />
                    </>
                  }
                </div>
              </Row>
            }
          </Content>
        </Layout>
      </Layout>
    </Layout>
  )
};

export default Analysis;
