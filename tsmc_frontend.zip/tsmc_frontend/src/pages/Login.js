import React from 'react';
import { useNavigate } from 'react-router-dom';
import { Button, Col, Form, Input, Row } from 'antd';
import { useDispatch } from 'react-redux';
import { setUserName } from '../store/slice/authSlice';
import { apiLogin } from '../utils/API';
import Axios from '../utils/Axios';

const LoginPage = (props) => {
  const navigate = useNavigate();
  const dispatch = useDispatch();

  const login = (value) => {
    apiLogin(value)
      .then((response) => {
        const responseData = response.data.results;
        Axios.defaults.headers.common.Authorization = responseData.token;
        dispatch(setUserName({
          account: value.account, 
          token: responseData.token, 
          userID: responseData.user_id 
        }));
        localStorage.setItem('token', responseData.token)
        localStorage.setItem('auth', true);
        navigate('/')
      })
      .catch(err => console.log(err))
  }

  const onFinishFailed = (errorInfo) => {
    console.log('Failed:', errorInfo);
  };
  return (
    <div style={{ height: '100vh' }}>
      <Row justify="space-around" align="middle" style={{ height: '100%' }}>
        <Col span={6} justify="space-around" align="middle">
          <div style={{ marginBottom: '30px', marginTop: '-10px', fontSize: '30px', fontWeight: '700' }}>Login</div>
          <Form
            name="login"
            style={{
              maxWidth: 300,
            }}
            initialValues={{
              remember: true,
            }}
            onFinish={login}
            onFinishFailed={onFinishFailed}
            autoComplete="off"
          >
            <Form.Item
              label="Username"
              name="account"
              rules={[
                {
                  required: true,
                  message: 'Please input your username!',
                },
              ]}
            >
              <Input />
            </Form.Item>

            <Form.Item
              label="Password"
              name="password"
              rules={[
                {
                  required: true,
                  message: 'Please input your password!',
                },
              ]}
            >
              <Input.Password />
            </Form.Item>

            <Form.Item>
              <Button type="primary" htmlType="submit">
                Submit
              </Button>
            </Form.Item>
          </Form>
        </Col>
      </Row>
    </div>
  )
}

export default LoginPage;
