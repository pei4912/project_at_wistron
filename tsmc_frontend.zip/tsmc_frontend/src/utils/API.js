import Axios from './Axios';

// 登入
export const apiLogin = async (requestBody) => {
  return Axios.post('/auth/login', requestBody);
};

// 登出
export const apiLogout = async () => {
  return Axios.post('/auth/logout');
};

// 上傳 raw data
export const apiPostRawData = async (formData) => {
  return Axios.post('/analysisstatus/upload', formData, {
    headers: {
      'Content-Type': 'multipart/form-data',
    },
  });
};

// 取得所有檔案
export const apiGetAllFiles = async (category) => {
  return Axios.get(`/analysisstatus/${category}`);
};

// 上傳編輯後的Analysis表格
export const apiPostEditedAnalysis = async (postData) => {
  return Axios.post(`/analysisstatus/feedback/${postData.id}`, postData.data);
};