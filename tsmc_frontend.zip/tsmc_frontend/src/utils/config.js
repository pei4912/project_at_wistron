const CONFIG = process.env.REACT_APP_ENV === 'production' ? {
  brand: '正式',
  baseUrl: document.location.origin.replace(/:\d+/, ':3000') + '/api',
  intervalsTime: 60000,
} : {
  brand: '測試',
  baseUrl: 'http://104.199.165.251:3000/api',
  intervalsTime: 60000,
};

export default CONFIG;
