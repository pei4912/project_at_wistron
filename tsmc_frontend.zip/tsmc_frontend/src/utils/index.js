// yyyy-mm-dd HH:MM:SS
export const convertDate2String = (date) => {
	const result = `${date.substr(0, 10)} ${date.substr(11, 5)}`;
	return result;
};