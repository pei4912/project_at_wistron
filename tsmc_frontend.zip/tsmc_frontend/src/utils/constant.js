
export const MODEL_ITEMS = [
  {
    key: 'ldct',
    label: 'LDCT',
    levels: [
      { key: '正常', label: '正常' },
      { key: '低', label: '低度' },
      { key: '中低', label: '中低度' },
      { key: '中高', label: '中高度' },
      { key: '高', label: '高度' },
    ],
  }, {
    key: 'ekg',
    label: 'EKG',
    levels: [
      { key: '正常', label: '正常' },
      { key: '低', label: '低度' },
      { key: '中低', label: '中低度' },
      { key: '中高', label: '中高度' },
      { key: '高', label: '高度' },
    ],
  }, { // 鈣化指數
    key: 'cct',
    label: 'CCT',
    levels: [
      { key: '無明顯異常', label: '無明顯異常' },
      { key: '低', label: '低度' },
      { key: '中', label: '中度' },
      { key: '高', label: '高度' },
    ],
  // }, { // 頸超
  //   key: 'ds',
  //   label: 'DS',
  //   levels: [
  //     { key: '正常', label: '正常' },
  //     { key: '低', label: '低度' },
  //     { key: '中', label: '中度' },
  //     { key: '高', label: '高度' },
  //   ],
  // }, { // 心超
  //   key: 'ce',
  //   label: 'CE',
  //   levels: [
  //     { key: '正常', label: '正常' },
  //     { key: '低', label: '低度' },
  //     { key: '中', label: '中度' },
  //     { key: '高', label: '高度' },
  //   ],
  },
];

export const COL_WIDTH_SETTING = {
  '代碼': 100,
  '分級結果': 100,
  '醫師分級': 100,
  '緯創分級結果': 120,
};

export const INIT_MENU_ITEMS = [
  {
    key: 'add',
    label: '新增分析資料',
  },
];