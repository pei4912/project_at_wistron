import axios from 'axios';
import APPCONFIG from './config';
import CONFIG from './config';
const { baseUrl } = CONFIG;
const token = localStorage.getItem('token');

const instance = axios.create({
	baseURL: baseUrl,
	timeout: APPCONFIG.intervalsTime,
	headers: token ? { Authorization: token } : {},
});


const spinnerHide = []; // 不要有loading的api
let responseQueue = []; // 存是否還有任務未回應

instance.interceptors.request.use((config) => {
	if (spinnerHide && !spinnerHide.includes(config.url)) {
		responseQueue.push(config.url);
	}
	return config;
});

instance.interceptors.response.use((response) => {
	responseQueue = responseQueue.filter((data) => data !== response.config.url);
	return response;
}, (error) => {
	console.log(error.message)
	if (error && error.response) {
		if (error.response.status === 401) {
			localStorage.removeItem('token');
			localStorage.removeItem('auth');
			window.location.replace('');
		}
	}
	responseQueue = [];
	return Promise.reject(error);
});

export default instance;
