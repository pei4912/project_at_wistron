import styled from "styled-components";

export const IconButton = styled.button`
  background: transparent;
  border: 0;
  cursor: ${(props) => props.disabled ? 'not-allowed' : 'pointer'}
`;

export const TextButton = styled.button`
  background: transparent;
  border: 1px solid #729bb4;
  cursor: ${(props) => props.disabled ? 'not-allowed' : 'pointer'};
  padding: 8px 15px;
  border-radius: 3px;
  color: #729bb4;
`

export const TextButtonFilled = styled.button`
  background: ${(props) => props.disabled ? '#a4becf' : '#729bb4'};
  border: ${(props) => props.disabled ? '1px solid #a4becf' : '1px solid #729bb4'};
  cursor: ${(props) => props.disabled ? 'not-allowed' : 'pointer'};
  padding: 8px 15px;
  border-radius: 3px;
  color: white;
`