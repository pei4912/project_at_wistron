import { combineReducers } from "@reduxjs/toolkit";
import authReducer from "./slice/authSlice";
import menuReducer from "./slice/menuSlice";
import analysisReducer from "./slice/analysisSlice";

export const rootReducer = combineReducers({
  auth: authReducer,
  menu: menuReducer,
  analysis: analysisReducer
})