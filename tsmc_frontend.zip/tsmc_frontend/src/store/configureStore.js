import storage from 'redux-persist/lib/storage';
import persistReducer from 'redux-persist/es/persistReducer';
import { rootReducer } from './reducer';
import persistStore from 'redux-persist/es/persistStore';
import { configureStore } from '@reduxjs/toolkit';
import thunk from 'redux-thunk';

const persistConfig = {
  key: 'root',
  storage,
  whitelist: ['auth']
};

const persistedReducer = persistReducer(persistConfig, rootReducer)

export default () => {
  let store = configureStore({
    reducer: persistedReducer,
    middleware: [thunk]
  });
  
  let persistor = persistStore(store)
  return { store, persistor }
}