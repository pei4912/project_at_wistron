import { createSlice } from "@reduxjs/toolkit";
import { INIT_MENU_ITEMS, MODEL_ITEMS } from "../../utils/constant";

const INIT_MENU_STATE = {
  model: MODEL_ITEMS,
  selectedModel: MODEL_ITEMS[0],
  menu: INIT_MENU_ITEMS,
  selectedMenu: INIT_MENU_ITEMS[0],
}

export const menuSlice = createSlice({
  name: 'menu',
  initialState: INIT_MENU_STATE,
  reducers: {
    setModel: (state, action) => {
      state.model = action.payload;
    },
    setSelectedModel: (state, action) => {
      state = {
        ...state,
        selectedModel: action.payload,
        menu: INIT_MENU_STATE.menu,
        selectedMenu: INIT_MENU_STATE.selectedMenu
      }
      return state
    },
    setMenu: (state, action) => {
      state.menu = action.payload;
    },
    setSelectedMenu: (state, action) => {
      state.selectedMenu = action.payload;
    },
  }
});

export const { setModel, setSelectedModel, setMenu, setSelectedMenu } = menuSlice.actions;
export default menuSlice.reducer;