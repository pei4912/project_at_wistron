import { createSlice } from "@reduxjs/toolkit";

export const authSlice = createSlice({
  name: 'auth',
  initialState: {
    userName: null,
    token: null,
    userID: '',
  },
  reducers: {
    setUserName: (state, action) => {
      state.userName = action.payload.account;
      state.token = action.payload.token;
      state.userID = action.payload.userID
    }
  }
});

export const { setUserName } = authSlice.actions;
export default authSlice.reducer;