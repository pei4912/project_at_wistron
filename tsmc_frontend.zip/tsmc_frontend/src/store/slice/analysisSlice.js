import { createSlice, current } from "@reduxjs/toolkit";

const INIT_ANALYSIS_STATE = {
  cols: [],
  originCols: [],
  rows: [],
  originRows: [],
  dataCnt: 0,
  isLoading: false,
  isEditing: false,
  editData: {},
  editModalVisible: false,
  uploadData: {},
};

export const analysisSlice = createSlice({
  name: 'analysis',
  initialState: INIT_ANALYSIS_STATE,
  reducers: {
    setCols: (state, action) => {
      state.cols = action.payload;
    },
    setRows: (state, action) => {
      state.rows = action.payload;
    },
    setDataCnt: (state, action) => {
      state.dataCnt = action.payload;
    },
    setIsLoading: (state, action) => {
      state.isLoading = action.payload;
    },
    setEditData: (state, action) => {
      state.editData = action.payload;
    },
    setEditModalVisible: (state, action) => {
      state.editModalVisible = action.payload;
    },
    modalSubmit: (state, action) => {
      const updateRows = state.rows.map(obj => {
        if (obj['代碼'] === state.editData['代碼']) {
          // 若 代碼 相同，則進行修改
          return {
            ...obj,
            醫師分級: action.payload['醫師分級'] ? action.payload['醫師分級'] : '',
            醫師說明: action.payload['醫師說明'] ? action.payload['醫師說明'] : '',
          };
        } else {
          // 若 代碼 不同，則保持不變
          return { ...obj };
        }
      });
      const updateCols = state.cols.map((obj) => { return { ...obj } })
      // 編輯過後, 原始標題列沒有的欄位都加上去
      updateCols.findIndex((col) => col.dataIndex === '醫師分級') === -1 && updateCols.splice(updateCols.length-1, 0, { title: '醫師分級', dataIndex: '醫師分級', key: '醫師分級', width: 100, render: (value) => value === undefined ? '' : value });
      updateCols.findIndex((col) => col.dataIndex === '醫師說明') === -1 && updateCols.splice(updateCols.length-1, 0, { title: '醫師說明', dataIndex: '醫師說明', key: '醫師說明', render: (value) => value === undefined ? '' : value });
      state.rows = updateRows;
      state.cols = updateCols;
    },
    setIsEditing: (state, action) => {
      state.isEditing = action.payload;
      state.originCols = action.payload===true ? JSON.parse(JSON.stringify(current(state.cols))) : INIT_ANALYSIS_STATE.originCols;
      state.originRows = action.payload===true ? JSON.parse(JSON.stringify(current(state.rows))) : INIT_ANALYSIS_STATE.originRows;
    },
    updateTable: (state, action) => {
      state.cols = JSON.parse(JSON.stringify(current(action.payload === 'cancel' ? state.originCols : state.cols)));
      state.rows = JSON.parse(JSON.stringify(current(action.payload === 'cancel' ? state.originRows : state.rows)));
      state.originCols = INIT_ANALYSIS_STATE.originCols;
      state.originRows = INIT_ANALYSIS_STATE.originRows;
    },
    setUploadData: (state, action) => {
      state.uploadData = action.payload;
    }
  }
});

export const { setCols, setRows, setDataCnt, setIsLoading, setEditData, setEditModalVisible, modalSubmit, setIsEditing, updateTable, setUploadData } = analysisSlice.actions;
export default analysisSlice.reducer;