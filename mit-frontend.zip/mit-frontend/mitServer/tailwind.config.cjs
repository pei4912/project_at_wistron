const colors = require('tailwindcss/colors');
/** @type {import('tailwindcss').Config} */

const baseSizes = {
  1: '0.25rem',
  2: '0.5rem',
  3: '0.75rem',
  4: '1rem',
  5: '1.25rem',
  6: '1.5rem',
  7: '1.75rem',
  8: '2rem',
  9: '2.25rem',
  10: '2.5rem',
  11: '2.75rem',
  12: '3rem',
  13: '3.25rem',
  14: '3.5rem',
  15: '3.75rem',
  16: '4rem',
  18: '4.5rem',
  20: '5rem',
  24: '6rem',
  28: '7rem',
  32: '8rem',
  36: '9rem',
  40: '10rem',
  44: '11rem',
  48: '12rem',
  52: '13rem',
  56: '14rem',
  60: '15rem',
  64: '16rem',
  72: '18rem',
  80: '20rem',
  96: '24rem',
};

module.exports = {
  content: [
    "./index.html",
    "./src/**/*.{js,ts,jsx,tsx}",
    "./node_modules/@tremor/**/*.{js,ts,jsx,tsx}",
  ],
  theme: {
    extend: {
      fontFamily: {
        'jhengHei': 'Microsoft JhengHei'
      },
      colors: {
        'mit-black': '#000000',
        'mit-white': '#FFFFFF',
        'mit-hover-yellow': '#FFFBE7',
        'mit-yellow': '#F5C910',
        'mit-success': '#1CA465',
        'mit-attention': '#E9C237',
        'mit-error': '#D94C4C',
        'mit-white-hover': '#A9A9A9',
        'mit-gray': {
          ...colors.gray,
          200: '#E8E8E8',
          400: '#A9A9A9',
          600: '#4D4D4D',
          900: '#333333',
          DEFAULT: '#606060',
        }
      },
      maxHeight: {
        ...baseSizes,
      },
      maxWidth: {
        ...baseSizes,
      },
      minHeight: {
        ...baseSizes,
      },
      minWidth: {
        ...baseSizes,
      },
    },
  },
  plugins: [
    require('tailwind-scrollbar-hide')
  ],
}
