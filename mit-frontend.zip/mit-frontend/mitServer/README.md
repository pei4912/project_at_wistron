# MIT_DEMO_SERVER (New UI)

## UI

- figma: https://www.figma.com/file/zRacB1sf1cDZzZtl9FDzFT/MIT-Demo?node-id=0-1&t=canHnOSp4LRUMpG3-0
- flow: https://modao.cc/app/mD16DqJlrrunv8jNZ9zSw7#screen=sl2mw1t5dwxlfhnqyrtwv5lu1

## Route

- http://10.31.98.181:5515
- Only can use fake login
