import SvgIcon from '@/assets/SvgIcon';
import { twMerge } from 'tailwind-merge';

// title
export type BorderTitleProps = {
  title?: string;
  borderColor?: string;
};
export const BorderTitle = ({ title, borderColor = 'border-l-mit-yellow' }: BorderTitleProps) => {
  return (
    <div
      className={twMerge(
        'mt-6 border border-l-[6px] border-t-0 border-r-0 border-b-0 py-0.5 pl-2 text-xl font-extrabold',
        borderColor
      )}
    >
      {title}
    </div>
  );
};

// card
export type BorderCardProps = {
  icon?: string;
  borderColor?: string;
  title?: string;
  content?: React.ReactElement | string;
  buttonContent?: React.ReactElement;
};
export const BorderCard = ({ icon, borderColor, title, content, buttonContent }: BorderCardProps) => {
  return (
    <div className={twMerge('mt-6 rounded-lg border border-l-[6px] p-6', borderColor)}>
      <div className="flex items-center">
        {icon && <SvgIcon iconName={icon} svgProp={{ height: '32px' }} />}
        <div className="ml-5 text-xl font-extrabold">{title}</div>
      </div>
      <div className="my-6 break-words">{content}</div>
      <div className="flex justify-end">{buttonContent}</div>
    </div>
  );
};
