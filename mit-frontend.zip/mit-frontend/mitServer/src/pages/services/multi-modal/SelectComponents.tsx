import { useEffect, useRef, useState } from 'react';
import Select from '@/components/select/Select';
import {
  useGetServiceOptionQuery,
  useGetTypeOptionQuery,
  useGetModelSystemOptionQuery,
  useGetMaterialTempOptionQuery,
} from '@/api/multiModalApis';
import { twMerge } from 'tailwind-merge';
import RadioSelectGroup from '@/components/select/RadioSelectGroup';
import SvgIcon from '@/assets/SvgIcon';
import IconButton from '@/components/icon-button/IconButton';
import { useAppSelector } from '@/reducer/hooks';

export const SelectComponents = ({
  type,
  submitInvalid,
  setUploadFile,
}: {
  type: string;
  submitInvalid: boolean;
  setUploadFile: any;
}) => {
  const inputRef = useRef<HTMLInputElement>(null);
  const [fileName, setFileName] = useState('');
  const [selectModalOption, setSelectModalOption] = useState<string>('System');
  const [selectMaterialOption, setSelectMaterialOption] = useState<string>('');
  const [selectModal, setSelectModal] = useState<string>('');
  const [defaultVersion, setDefaultVersion] = useState<string>('');
  const [selectMaterial, setSelectMaterial] = useState<string>('');
  const {
    settingOptions: { material, modalName, materialName, version, modal },
    resetState,
  } = useAppSelector((state) => state.multimodal);

  const modalRadioOptions = [
    { label: 'System', groupName: 'modal' },
    { label: 'Custom Training', groupName: 'modal' },
  ];
  const materialRadioOptions = [
    { label: 'Template', groupName: 'material' },
    { label: 'Upload', groupName: 'material' },
  ];

  // GET select dataset type option
  const { data: typeOptions, isLoading: typeIsLoading } = useGetTypeOptionQuery();
  // GET select service option
  const { data: serviceOptions, isLoading: serviceIsLoading } = useGetServiceOptionQuery();
  // GET Material system option
  const [fetchModalOption, setFetchModalOption] = useState(false);
  const { data: modalSysOption, isLoading: modalIsLoading } = useGetModelSystemOptionQuery(
    { service: 'Multimodal', type: type, is_default: selectModalOption === 'System' ? 1 : 0 },
    {
      skip: !fetchModalOption,
    }
  );
  // GET Material template option
  const [fetchMatlOption, setFetchMatlOption] = useState(false);
  const { data: matlTempOption, isLoading: matlIsLoading } = useGetMaterialTempOptionQuery(
    { service: 'Multimodal', type: type, is_default: selectModalOption === 'System' ? 1 : 0 },
    {
      skip: !fetchMatlOption,
    }
  );

  // 選單內 Modal Name 的 Radio 變更事件
  const modalRadioChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setSelectModalOption(e.target.value);
    setFetchModalOption(true);
    setSelectModal('');
    setDefaultVersion('');
    setSelectMaterial('');
    if (selectMaterialOption === 'Template') {
      setFetchMatlOption(true);
    }
  };
  // 選單內 Material 的 Radio 變更事件
  const materialRadioChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setSelectMaterialOption(e.target.value);
    setSelectMaterial('');
    // 如果選擇System, 就要 Fetch Material 的選項內容
    if (e.target.value === 'Template') {
      setFetchMatlOption(true);
    }
  };

  // GET zip file
  const downloadZipFolder = () => {
    const url = `${import.meta.env.VITE_API_BASE_URL}inference/template/download?type=TEXT`;
    fetch(url)
      .then((response) => {
        if (response.ok) {
          return response.blob();
        } else {
          throw new Error('Download failed');
        }
      })
      .then((blob) => {
        const downloadUrl = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = downloadUrl;
        a.download = 'Download.zip';
        a.click();
        URL.revokeObjectURL(downloadUrl);
      })
      .catch((error) => {
        console.error('Error occurred while downloading:', error);
      });
  };

  const handleDragOver = (event: React.DragEvent<HTMLDivElement>) => {
    event.preventDefault();
  };

  const handleDrop = (event: React.DragEvent<HTMLDivElement>) => {
    event.preventDefault();
    const file = event.dataTransfer.files[0];
    handleFileChange(file);
  };

  const handleFileChange = (file: File) => {
    if (file.name.split('.')[1] === 'zip') {
      setFileName(file.name);
      setUploadFile(file);
    } else {
      setFileName('');
      alert('請上傳 zip 檔案');
    }
  };

  useEffect(() => {
    if (!modalIsLoading) {
      setFetchModalOption(false);
    } else if (!matlIsLoading) {
      setFetchMatlOption(false);
    }
  }, [modalIsLoading, matlIsLoading]);

  useEffect(() => {
    if (type !== '') {
      setFetchModalOption(true);
      setFetchMatlOption(true);
    }
  }, [type]);

  useEffect(() => {
    !resetState &&
      setDefaultVersion(
        modalSysOption?.modalSysOption !== undefined && selectModal !== ''
          ? modalSysOption?.modalSysOption.filter((option) => option.name === selectModal)[0].version
          : ''
      );
  }, [selectModal]);

  // 如果是從 Reset 導過來的, 需要預設選項
  useEffect(() => {
    if (resetState) {
      setSelectModal(modalName);
      setDefaultVersion(version);
      setSelectMaterial(materialName);
      setSelectModalOption(modal);
      setSelectMaterialOption(material);
    } else {
      setSelectMaterialOption('Template');
    }
  }, [resetState]);

  const formItemClassName = 'col-span-2 col-start-2';

  if (typeIsLoading || serviceIsLoading || selectMaterialOption === '' || selectMaterialOption === undefined) {
    return <></>;
  }
  return (
    <div className="grid grid-cols-4 gap-3">
      <Select
        label="Service"
        options={serviceOptions !== undefined ? serviceOptions : []}
        className={twMerge(formItemClassName)}
        selected="Multimodal"
        formName="Service"
        disabled
      />
      <Select
        label="Dataset Type"
        options={typeOptions !== undefined ? typeOptions : []}
        className={twMerge(formItemClassName)}
        selected={type}
        formName="DatasetType"
        disabled
      />
      <div className={twMerge(formItemClassName)}>
        <RadioSelectGroup
          options={modalRadioOptions}
          className="text-sm"
          title="Modal Name"
          titleClassName="text-gray-500"
          onChange={modalRadioChange}
          required
          selected={selectModalOption}
        />
        <Select
          options={modalSysOption !== undefined ? modalSysOption.modalSysOption : []}
          formName="ModalName"
          selected={selectModal}
          required
          invalid={submitInvalid}
          onChange={(value) => setSelectModal(value.name)}
        />
      </div>
      <Select
        options={
          (selectModal !== '' &&
            modalSysOption !== undefined &&
            modalSysOption.versionOption.find((option) => option.name === selectModal)?.data) ||
          []
        }
        formName="Version"
        label="Version"
        className={twMerge(formItemClassName)}
        invalid={submitInvalid}
        selected={defaultVersion}
        required
      />
      <div className={twMerge(formItemClassName)}>
        <RadioSelectGroup
          className="text-sm"
          options={materialRadioOptions}
          title="Material"
          titleClassName="text-gray-500"
          onChange={materialRadioChange}
          required
          selected={selectMaterialOption}
        />
        {selectMaterialOption === 'Template' ? (
          <Select
            options={matlTempOption !== undefined ? matlTempOption : []}
            formName="Material"
            required
            invalid={submitInvalid}
            selected={selectMaterial}
            onChange={(value) => setSelectMaterial(value.name)}
          />
        ) : (
          <div className="mt-1">
            <div
              className={twMerge(
                'flex h-32 cursor-pointer flex-col items-center justify-center rounded-sm border border-gray-300 text-sm',
                submitInvalid && fileName === '' && 'border-red-500'
              )}
              onClick={() => inputRef.current?.click()}
              onDragOver={handleDragOver}
              onDrop={handleDrop}
            >
              <SvgIcon iconName="icon-upload" />
              <div className="mt-6">Click or drag file to this area to upload</div>
              <input
                type="file"
                accept="zip/*"
                ref={inputRef}
                name="file"
                hidden
                onChange={({ target: { files } }) => {
                  if (files && files[0]) {
                    if (files[0].name.split('.')[1] === 'zip') {
                      setFileName(files[0].name);
                      setUploadFile(files[0]);
                    } else {
                      alert('請上傳zip檔');
                    }
                  }
                }}
              />
            </div>
            {fileName && (
              <div className="mt-2 flex items-center justify-between">
                <div className="flex flex-row">
                  <SvgIcon iconName="icon-file" />
                  <div className="ml-1.5 text-sm text-gray-500">{fileName}</div>
                </div>
                <IconButton
                  iconName="icon-delete"
                  onClick={() => {
                    setFileName('');
                    setUploadFile(null);
                    const fileInput = inputRef.current;
                    if (fileInput) {
                      fileInput.value = '';
                    }
                  }}
                />
              </div>
            )}
            <button type="button" onClick={() => downloadZipFolder()} className="text-sm text-[#45A2CD] underline">
              Download Template
            </button>
          </div>
        )}
      </div>
    </div>
  );
};
