export { default as Component } from './MultiModal';
