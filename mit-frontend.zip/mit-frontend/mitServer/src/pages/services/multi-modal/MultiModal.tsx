import TextButton from '@/components/text-button/TextButton';
import { BorderCard, BorderTitle } from './components';
import { useEffect, useState } from 'react';
import Modal from '@/components/modal/Modal';
import { useLocation, useNavigate } from 'react-router-dom';
import { setDemoData, setResetState, setSettingOptions } from '@/reducer/slice/multimodalSlice';
import { store } from '@/reducer/store';
import { SelectComponents } from './SelectComponents';
import { useAppDispatch, useAppSelector } from '@/reducer/hooks';
import { usePostInferenceFileMutation } from '@/api/multiModalApis';

const MultiModal = () => {
  const {
    settingOptions: { modelID, datasetType },
    resetState,
  } = useAppSelector((state) => state.multimodal);
  const [textModal, setTextModal] = useState<boolean>(false);
  const [tabularModal, setTabularModal] = useState<boolean>(false);
  const [imageModal, setImageModal] = useState<boolean>(false);
  const [submitInvalid, setSubmitInvalid] = useState<boolean>(false);
  const [uploadFile, setUploadFile] = useState<File | null>(null);
  const navigate = useNavigate();
  const location = useLocation();
  const dispatch = useAppDispatch();

  // 控制要開啟哪一個 Modal 並設定好 Modal 裡面不能變更的選項
  const setModalOpen = (type: string) => {
    switch (type) {
      case 'Text':
        setTextModal(true);
        break;
      case 'Text & Tabular':
        setTabularModal(true);
        break;
      case 'Text & Image':
        setImageModal(true);
        break;
    }
  };

  const [postInferenceFile] = usePostInferenceFileMutation();
  const handlePostInference = async () => {
    try {
      const response = await postInferenceFile({
        model_id: modelID,
        file: uploadFile,
      });
      if ('data' in response) {
        // 使用 response.data 獲取回應的資料
        store.dispatch(setDemoData({ heatmap: response.data.heatmap, result: response.data.result }));
      } else {
        console.error('Response does not contain data');
      }
    } catch (err) {
      console.error(err);
    }
  };

  // 表單送出如果沒選擇的話就會跳錯,
  const formSubmit = (e: any) => {
    setSubmitInvalid(false);

    // 將各選項存起來, 如果檢查通過就存到slice中, 跳頁之後可以使用
    const option = {
      modelID: Number(e['Version[id]']),
      materialID: Number(e['Material[id]']) | 0,
      service: e['Service[name]'],
      datasetType: e['DatasetType[name]'],
      modalName: e['ModalName[name]'],
      materialName: e['Material[name]'],
      version: e['Version[name]'],
      material: e['material'],
      modal: e['modal'],
    };
    // 檢查各個select, 如果是上傳資料(upload), 就不需要檢查MaterialName欄位
    const validateArr = ['ModalName[id]', 'Version[id]'];
    e['material'] !== 'Upload' && validateArr.push('Material[id]');
    const validate = validateArr.every((key) => {
      const value = e[key];
      return value !== '0' && value !== undefined;
    });
    const uploadValidate = e['material'] === 'Upload' ? uploadFile !== null : true;

    if (validate && uploadValidate) {
      // 如果是上傳檔案的話, 就先接api再換頁, 不是的話, 換頁之後才會接api
      e['material'] === 'Upload' && handlePostInference();
      store.dispatch(setSettingOptions(option));
      location.pathname === '/'
        ? navigate(`service/multi-modal/demo/${e['ModalName[name]']}`)
        : navigate(`demo/${e['ModalName[name]']}`);
    } else {
      setSubmitInvalid(true);
    }
  };

  useEffect(() => {
    store.dispatch(setDemoData({ heatmap: null, result: null }));
    if (resetState) {
      setModalOpen(datasetType);
    }
  }, []);

  return (
    <div className="m-6 h-[calc(100%-3rem)] overflow-auto bg-white p-6 text-left">
      <div className="text-2xl font-extrabold">MultiModal</div>
      <div className="mb-6 mt-4">
        A toolkit for incorporating multimodal data for classification and regression tasks. It uses HuggingFace
        <br></br>
        transformers as the base model for text features. <br></br>
        The toolkit adds a combining module that takes the outputs of the transformer in addition to tabular features to
        <br></br>
        produce rich multimodal features for downstream tasks. <br></br>
        The toolkit also adds the image encoder which is implemented as a series of residual blocks to jointly learn
        <br></br>
        effective feature representations from images and free text for downstream tasks.
      </div>
      <hr />

      <div className="grid grid-cols-2 gap-6">
        <BorderCard
          icon={'multi-demo-icon'}
          borderColor="border-l-[#DDE2F2]"
          title="Demo"
          content="Select which types of heterogeneous data to use in the demo inference service platform."
          buttonContent={
            <div>
              <TextButton className="mx-1.5 py-1 px-8" onClick={() => setModalOpen('Text')}>
                Text
              </TextButton>
              <TextButton className="mx-1.5 py-1 px-1.5" onClick={() => setModalOpen('Text & Tabular')} disabled>
                Text & Tabular
              </TextButton>
              <TextButton className="ml-1.5 py-1 px-1.5" onClick={() => setModalOpen('Text & Image')} disabled>
                Text & Image
              </TextButton>
            </div>
          }
        />
        <BorderCard
          icon={'multi-training-icon'}
          borderColor="border-l-[#E1EAD4]"
          title="Custom Training"
          content="Given a pre-trained transformer, the custom parameters of the combining module (tabular or image) and transformer are trained based on the supervised task."
          buttonContent={<TextButton className="py-1 px-2">Start Now</TextButton>}
        />
      </div>

      <BorderTitle title="Contact Information" />
      <div className="mt-4 px-4">
        <a
          className="underline decoration-solid hover:no-underline"
          href="mailto:Aga_liao@wistron.com"
          style={{ color: '#45A2CD' }}
        >
          Aga_liao@wistron.com
        </a>
        <a
          className="ml-2 underline decoration-solid hover:no-underline"
          href="mailto:Leo_YZ_lin@wistron.com"
          style={{ color: '#45A2CD' }}
        >
          Leo_YZ_lin@wistron.com
        </a>
      </div>
      <Modal
        width="sm"
        isForm={true}
        title="Demo Setting"
        isOpen={textModal}
        okButton="Analysis"
        handleOk={formSubmit}
        handleCancel={() => {
          setTextModal(false);
          setSubmitInvalid(false);
          dispatch(setResetState(false));
        }}
      >
        <SelectComponents type={'Text'} submitInvalid={submitInvalid} setUploadFile={setUploadFile} />
      </Modal>
      <Modal
        width="sm"
        isForm={true}
        title="Demo Setting"
        isOpen={tabularModal}
        okButton="Analysis"
        handleOk={formSubmit}
        handleCancel={() => {
          setTabularModal(false);
          setSubmitInvalid(false);
          dispatch(setResetState(false));
        }}
      >
        <SelectComponents type={'Text & Tabular'} submitInvalid={submitInvalid} setUploadFile={setUploadFile} />
      </Modal>
      <Modal
        width="sm"
        isForm={true}
        title="Demo Setting"
        isOpen={imageModal}
        okButton="Analysis"
        handleOk={formSubmit}
        handleCancel={() => {
          setImageModal(false);
          setSubmitInvalid(false);
          dispatch(setResetState(false));
        }}
      >
        <SelectComponents type={'Text & Image'} submitInvalid={submitInvalid} setUploadFile={setUploadFile} />
      </Modal>
    </div>
  );
};

export default MultiModal;
