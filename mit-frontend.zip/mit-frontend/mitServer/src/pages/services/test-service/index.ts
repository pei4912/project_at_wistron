export { default as Component } from './TestService';
