import { twMerge } from 'tailwind-merge';
// title
export type FormContentProps = {
  title?: string;
  content?: React.ReactElement | string;
  className?: string;
};
export const FormContent = ({ className, title, content }: FormContentProps) => {
  return (
    <div className={twMerge('border-l-2 border-[#B3B3B3]', className)}>
      <p className="ml-2 text-sm text-[#B3B3B3]">{title}</p>
      <p className="ml-2 mt-2 text-sm">{content}</p>
    </div>
  );
};

// table title
export type TableTitleProps = {
  row1?: string;
  row2?: string;
};
export const TableTitle = ({ row1, row2 }: TableTitleProps) => {
  return (
    <thead className=" bg-mit-black">
      <tr className="grid grid-cols-7">
        <th scope="col" className="col-span-5 py-3 pl-2 text-white">
          {row1}
        </th>
        <th scope="col" className=" py-3 pl-2 text-white ">
          {row2}
        </th>
      </tr>
    </thead>
  );
};

export type TableContentProps = {
  col1?: string;
  col2?: number | string;
};
export const TableContent = ({ col1, col2 }: TableContentProps) => {
  return (
    <tbody>
      <tr className="grid grid-cols-7 border-b-2">
        <td className="col-span-5 py-3  pl-2 ">{col1}</td>
        <td className="py-3 pl-2">{col2}</td>
      </tr>
    </tbody>
  );
};
