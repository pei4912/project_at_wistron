import { FormContent } from './components';
import { TableTitle } from './components';
import { TableContent } from './components';
import { useRef, useEffect } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import TextButton from '@/components/text-button/TextButton';
import { useAppDispatch, useAppSelector } from '@/reducer/hooks';
import { useGetInferenceQuery } from '@/api/multiModalApis';
import { twMerge } from 'tailwind-merge';
import { Alert, Space, Spin } from 'antd';
import './loading.css';
import { setResetState } from '@/reducer/slice/multimodalSlice';
import ColorBlock from '@/components/color-block/ColorBlock';

const TestService = () => {
  const navigate = useNavigate();
  const dispatch = useAppDispatch();
  const { modelID, materialID, material, service, datasetType, modalName, materialName, version } = useAppSelector(
    (state) => state.multimodal.settingOptions
  );
  const { heatmap: fileHeatMap, result: fileResult } = useAppSelector((state) => state.multimodal.demoData);
  // 取得這一頁資料的api
  const { data: demoData, isLoading: demoDataIsLoading } = useGetInferenceQuery(
    {
      model_id: modelID,
      dataset_id: materialID,
    },
    {
      skip: material === 'Upload',
    }
  );

  const elementRef = useRef<HTMLDivElement>(null);

  //predicted result
  const result = material !== 'Upload' ? demoData?.result[0] : fileResult !== null && fileResult[0];

  const sortable = [];
  for (const toxin in result) {
    sortable.push([toxin, result[toxin]]);
  }
  sortable.sort(function (a, b) {
    return b[1] - a[1];
  });

  const loadingStatus = demoDataIsLoading || (material === 'Upload' && fileHeatMap === null && fileResult === null);

  const handleReset = () => {
    dispatch(setResetState(true));
    navigate('../../service/multi-modal');
  };
  const handleCancel = () => {
    dispatch(setResetState(false));
    navigate('../../service/multi-modal');
  };

  const colorBlockArr = [
    { label: 'example 1', color: 'bg-[#F5C910]' },
    { label: 'example 2', color: 'bg-[#9DFFFF]' },
    { label: 'example 3', color: 'bg-[#BEFFFF]' },
  ];

  //heatmap
  useEffect(() => {
    if (elementRef.current) {
      elementRef.current.innerHTML = (material !== 'Upload' ? demoData?.heatmap : fileHeatMap) ?? '';
    }
  }, [elementRef.current, demoData, fileHeatMap]);

  return (
    <div className="flex min-w-[900px] justify-center">
      <div className={twMerge('w-3/4 bg-white p-6 pb-0 text-left', loadingStatus && 'h-[calc(100vh-48px)]')}>
        <div className="w-full rounded-lg bg-[#D7D7D733] bg-opacity-20">
          <div className="grid grid-cols-3 p-6">
            <FormContent title="Service" content={<span>{service}</span>} />
            <FormContent title="Dataset Type" content={<span>{datasetType}</span>} />
            <FormContent title="Modal Name" content={<span>{modalName}</span>} />
            <FormContent className="mt-4" title="Version" content={<span>{version}</span>} />
            <FormContent className="mt-4" title="Material" content={<span>{materialName || '--'}</span>} />
            <FormContent className="mt-4" title="Number of Prediction" content={<span>5</span>} />
          </div>
        </div>
        {loadingStatus ? (
          <div className="flex h-4/5 flex-col items-center justify-center">
            <Spin size="large"></Spin>
            <div className="p-3 text-[#F5C910]">please wait for a moment...</div>
          </div>
        ) : (
          <>
            <div className="mt-12">
              <b className="text-xl">Predicted Result</b>
              <table className="mt-4 w-full">
                <TableTitle row1="Class" row2="Probability"></TableTitle>
                {sortable.map((item: any) => (
                  <TableContent key={item} col1={item[0]} col2={(item[1] * 100).toFixed(5) + '%'}></TableContent>
                ))}
              </table>
            </div>

            <div className="mt-12 ">
              <b className="text-xl">Heap Map</b>
              <div className="mt-4 h-64 overflow-y-scroll rounded-lg border border-[#D7D7D7]">
                <div className="h-[280px] p-6 text-base leading-7" ref={elementRef}></div>
              </div>
              <div className="flex flex-row justify-end">
                {colorBlockArr.map((block, i) => (
                  <ColorBlock key={i} label={block.label} color={block.color} />
                ))}
              </div>
            </div>
            <div className="sticky bottom-0 -mx-2 mt-1 flex justify-end border border-x-0 border-b-0 border-t-black bg-white py-4">
              <TextButton onClick={() => handleCancel()} type="white" className="mx-2 px-3 py-1 ">
                Cancel
              </TextButton>
              <TextButton onClick={() => handleReset()} type="fill" className="mx-2 px-4 py-1">
                Reset
              </TextButton>
            </div>
          </>
        )}
      </div>
    </div>
  );
};

export default TestService;
