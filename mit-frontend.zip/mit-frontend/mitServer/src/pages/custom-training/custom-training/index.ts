export { default as Component } from './CustomTraining';
