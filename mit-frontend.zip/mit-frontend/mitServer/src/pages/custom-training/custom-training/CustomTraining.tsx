import { useState } from 'react';
import TextButton from '@/components/text-button/TextButton';
import Select from '@/components/select/Select';
import { Checkbox, Table, Tag, Space, Dropdown } from 'antd';
import type { ColumnsType } from 'antd/lib/table';
import SvgIcon from '@/assets/SvgIcon';
import Modal from '@/components/modal/Modal';
import DeleteModal from '@/components/modal/DeleteModal';
import { SelectComponents } from './SelectComponents';
import { useAppDispatch } from '@/reducer/hooks';
import { useNavigate } from 'react-router-dom';
import moment, { Moment } from 'moment';
import {
  useGetTrainingTableQuery,
  useDeleteCustomModelMutation,
  useGetCustomModelQuery,
} from '@/api/customTrainingApis';
import { store } from '@/reducer/store';
import { setSettingOptions } from '@/reducer/slice/customTrainingSlice';
import './index.css';

const CustomTraining = () => {
  // GET select service option
  const [deleteCustomModel] = useDeleteCustomModelMutation();
  const statusOptions = ['Success', 'Processing', 'Failed'];
  const [addModal, setAddModal] = useState<boolean>(false);
  const [deleteModal, setDeleteModal] = useState<boolean>(false);
  const [selectModalId, setSelectedModelId] = useState(0);
  const [submitInvalid, setSubmitInvalid] = useState<boolean>(false);
  const [uploadFile, setUploadFile] = useState<File | null>(null);
  const [selectedOptions, setSelectedOptions] = useState<string>('');
  const navigate = useNavigate();

  const selectOption = [
    { name: 'Multimodal', id: 1 },
    { name: 'Service', id: 2 },
  ];

  interface DataType {
    key: string | number;
    model_id: number;
    service: string;
    type: string;
    name: string;
    version: string;
    status: string;
    remark: string;
    created_at: Moment;
    updated_at: Moment;
  }

  const columns: ColumnsType<DataType> = [
    {
      title: 'Service',
      dataIndex: 'service',
      key: 'service',
    },
    {
      title: 'Dataset Type',
      dataIndex: 'type',
      key: 'type',
    },
    {
      title: 'Modal Name',
      dataIndex: 'name',
      key: 'name',
    },
    {
      title: 'Version',
      dataIndex: 'version',
      key: 'version',
    },
    {
      title: 'Status',
      key: 'status',
      dataIndex: 'status',
      width: '143px',
      sorter: (a, b) => a.status.length - b.status.length,
      render: (_, { status }) => {
        let color = status.length > 7 ? '#E9C237' : '#1CA465';
        if (status === 'Failed') {
          color = '#CD4B4A';
        }
        return (
          <Tag
            className="rounded-2xl border px-[10px] py-[7px]"
            style={{ backgroundColor: `${color}20`, color: color, borderColor: color }}
          >
            {status}
          </Tag>
        );
      },
    },
    {
      title: 'Remark',
      dataIndex: 'remark',
      key: 'remark',
    },
    {
      title: 'Created Time',
      dataIndex: 'created_at',
      key: 'created_at',
      sorter: (a, b) => moment(a.created_at).unix() - moment(b.created_at).unix(),
      render: (created_at: Moment) => moment(created_at).format('YYYY-MM-DD HH:mm:ss'),
    },
    {
      title: 'Uptime Time',
      dataIndex: 'updated_at',
      key: 'updated_at',
      sorter: (a, b) => moment(a.updated_at).unix() - moment(b.updated_at).unix(),
      render: (updated_at: Moment) => moment(updated_at).format('YYYY-MM-DD HH:mm:ss'),
    },
    {
      title: 'Action',
      dataIndex: 'action',
      key: 'action',
      render: (_, { model_id, key, status }) => {
        const items = [
          {
            key: '1',
            label: 'Detail',
            onClick: () => {
              setSelectedModelId(model_id);
              detailSubmit(key);
            },
          },
          {
            key: '2',
            label: 'Deleted',
            onClick: () => {
              setDeleteModal(true);
              setSelectedModelId(model_id);
            },
          },
          {
            key: '3',
            label: 'Version',
          },
          { key: '4', label: 'Demo' },
          { key: '5', label: 'Edit' },
        ];

        const filteredItems = status === 'Success' ? items : items.slice(0, 3);
        const menuProps = {
          items: filteredItems,
        };

        return (
          <Space size="small" key={model_id}>
            <Dropdown menu={menuProps} trigger={['click']}>
              <a>
                <SvgIcon iconName="dropdown-icon" />
              </a>
            </Dropdown>
          </Space>
        );
      },
    },
  ];

  const {
    data: tableSysOption,
    isLoading: tableIsLoading,
    refetch: refetchTrainingTable,
  } = useGetTrainingTableQuery({
    service: 'ALL',
    status: selectedOptions,
    page_size: 10,
    page: 1,
  });

  //點選Version(查看全部version的資訊)
  const { data: getData } = useGetCustomModelQuery({
    modelId: selectModalId,
    page_size: 10,
    page: 1,
  });

  const handleCheckboxChange = (selectedValues: any) => {
    const selectedString = selectedValues.join(',');
    setSelectedOptions(selectedString);
  };
  console.log(selectedOptions);
  // Add Modal表單送出如果沒選擇的話就會跳錯,
  const addSubmit = (e: any) => {
    setSubmitInvalid(false);

    const service = e['Service[name]'];
    const datasetType = e['DatasetType[name]'];
    const modalName = e['ModalName'];
    const version = 'V1';

    const uploadValidate = uploadFile !== null;
    if (service !== '' && datasetType !== '' && modalName !== '' && uploadValidate) {
      console.log(
        'Service : ' +
          service +
          '\n' +
          'DatasetType : ' +
          datasetType +
          '\n' +
          'ModalName : ' +
          modalName +
          '\n' +
          'Version : ' +
          version
      );
      setAddModal(false);
    } else {
      setSubmitInvalid(true);
    }
  };

  //delete table data
  const deleteSubmit = (e: any) => {
    console.log(selectModalId);
    deleteCustomModel(selectModalId);
    setDeleteModal(false);
    refetchTrainingTable();
  };

  // 查詢table詳細資料
  const detailSubmit = (e: any) => {
    navigate(`detail/${e}`);
    const targetItem = tableSysOption?.data?.find((item) => item.id === e);
    const option = {
      service: targetItem?.service,
      datasetType: targetItem?.type,
      modalName: targetItem?.name,
      version: targetItem?.version,
    };
    store.dispatch(setSettingOptions(option));
  };

  return (
    <div className="my-6 text-left">
      <div className="mx-[26px]">
        <p className="text-sm">Service</p>
        <div className="mt-2 flex">
          <Select options={selectOption} selected="Multimodal" formName="Service" />
          <TextButton type="fill" className="mx-4 mt-1 px-[18px]">
            Search
          </TextButton>
        </div>
      </div>
      <div className="mx-6 my-4">
        <div className="h-[calc(100%-5rem)] overflow-auto bg-white p-6 ">
          <div className="mb-4 mr-4 flex">
            Status
            <Checkbox.Group
              className="ml-4"
              options={statusOptions}
              onChange={handleCheckboxChange}
              // value={selectedOptions}
            />
            <div className="absolute right-14 flex">
              <button onClick={() => setAddModal(true)}>
                <SvgIcon iconName="add-icon" />
              </button>
              <p className="ml-2">Add</p>
            </div>
          </div>
          <Table
            columns={columns}
            dataSource={tableSysOption?.data}
            pagination={{
              defaultPageSize: 10,
              showSizeChanger: true,
              showQuickJumper: true,
              showTotal: () => `Total ${tableSysOption?.data.length} items`,
            }}
          />
        </div>
      </div>
      <Modal
        width="sm"
        isForm={true}
        title="Add"
        isOpen={addModal}
        okButton="Confirm"
        handleOk={addSubmit}
        handleCancel={() => {
          setAddModal(false);
          setSubmitInvalid(false);
          // dispatch(setResetState(false));
        }}
      >
        <SelectComponents type={'Add'} submitInvalid={submitInvalid} setUploadFile={setUploadFile} />
      </Modal>

      <DeleteModal
        width="sm"
        isForm={true}
        isOpen={deleteModal}
        okButton="Confirm"
        handleOk={deleteSubmit}
        handleCancel={() => {
          setDeleteModal(false);
          // setSubmitInvalid(false);
        }}
      ></DeleteModal>
    </div>
  );
};

export default CustomTraining;
