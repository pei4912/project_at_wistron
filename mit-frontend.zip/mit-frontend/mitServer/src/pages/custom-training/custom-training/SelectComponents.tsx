import { useEffect, useRef, useState } from 'react';
import Select from '@/components/select/Select';
import Input from '@/components/input/Input';
import {
  useGetServiceOptionQuery,
  useGetTypeOptionQuery,
  useGetModelSystemOptionQuery,
  useGetMaterialTempOptionQuery,
} from '@/api/multiModalApis';
import { twMerge } from 'tailwind-merge';
import SvgIcon from '@/assets/SvgIcon';
import IconButton from '@/components/icon-button/IconButton';
import { useAppSelector } from '@/reducer/hooks';

export const SelectComponents = ({
  type,
  submitInvalid,
  setUploadFile,
}: {
  type: string;
  submitInvalid: boolean;
  setUploadFile: any;
}) => {
  const inputRef = useRef<HTMLInputElement>(null);
  const [fileName, setFileName] = useState('');
  const [selectService, setSelectService] = useState<string>('');
  const [selectType, setSelectType] = useState<string>('');
  const [selectModal, setSelectModal] = useState<string>('');
  const [modalValue, setModalValue] = useState<string>('');

  // GET select service option
  const { data: serviceOptions, isLoading: serviceIsLoading } = useGetServiceOptionQuery();
  // GET select dataset type option
  const { data: typeOptions, isLoading: typeIsLoading } = useGetTypeOptionQuery();

  // GET zip file
  const downloadZipFolder = () => {
    const url = `${import.meta.env.VITE_API_BASE_URL}inference/template/download?type=TEXT`;
    fetch(url)
      .then((response) => {
        if (response.ok) {
          return response.blob();
        } else {
          throw new Error('Download failed');
        }
      })
      .then((blob) => {
        const downloadUrl = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = downloadUrl;
        a.download = 'Download.zip';
        a.click();
        URL.revokeObjectURL(downloadUrl);
      })
      .catch((error) => {
        console.error('Error occurred while downloading:', error);
      });
  };

  const handleDragOver = (event: React.DragEvent<HTMLDivElement>) => {
    event.preventDefault();
  };

  const handleDrop = (event: React.DragEvent<HTMLDivElement>) => {
    event.preventDefault();
    const file = event.dataTransfer.files[0];
    handleFileChange(file);
  };

  const handleFileChange = (file: File) => {
    if (file.name.split('.')[1] === 'zip') {
      setFileName(file.name);
      setUploadFile(file);
    } else {
      setFileName('');
      alert('請上傳 zip 檔案');
    }
  };

  const handleInputChange = (value: string) => {
    setModalValue(value); // 更新值的狀態
  };

  const formItemClassName = 'col-span-2 col-start-2';

  return (
    <div className="grid grid-cols-4 gap-3">
      <Select
        label="Service"
        options={serviceOptions !== undefined ? serviceOptions : []}
        className={twMerge(formItemClassName)}
        formName="Service"
        required
        invalid={submitInvalid}
        onChange={(value) => setSelectService(value.name)}
      />
      <Select
        label="Dataset Type"
        options={typeOptions !== undefined ? typeOptions : []}
        className={twMerge(formItemClassName)}
        formName="DatasetType"
        required
        invalid={submitInvalid}
        onChange={(value) => setSelectType(value.name)}
      />
      <Input
        label="Modal Name"
        className={twMerge(formItemClassName)}
        formName="ModalName"
        invalid={submitInvalid}
        value={modalValue}
        onChange={handleInputChange}
        required
      />
      <Input
        label="Version"
        formName="Version"
        className={twMerge(formItemClassName)}
        value="V1"
        onChange={handleInputChange}
        disabled
      />
      <div className={twMerge(formItemClassName)}>
        <div className="flex flex-row">
          <div className="text-red-500">＊</div>
          <div className="mb-1 text-sm text-gray-500">Base Data</div>
        </div>
        <div className="mt-1">
          <div
            className={twMerge(
              'flex h-32 cursor-pointer flex-col items-center justify-center rounded-sm border border-gray-300 text-sm',
              submitInvalid && fileName === '' && 'border-red-500'
            )}
            onClick={() => inputRef.current?.click()}
            onDragOver={handleDragOver}
            onDrop={handleDrop}
          >
            <SvgIcon iconName="icon-upload" />
            <div className="mt-6">Click or drag file to this area to upload</div>
            <input
              type="file"
              accept="zip/*"
              ref={inputRef}
              name="file"
              hidden
              onChange={({ target: { files } }) => {
                if (files && files[0]) {
                  if (files[0].name.split('.')[1] === 'zip') {
                    setFileName(files[0].name);
                    setUploadFile(files[0]);
                  } else {
                    alert('請上傳zip檔');
                  }
                }
              }}
            />
          </div>
          {fileName && (
            <div className="mt-2 flex items-center justify-between">
              <div className="flex flex-row">
                <SvgIcon iconName="icon-file" />
                <div className="ml-1.5 text-sm text-gray-500">{fileName}</div>
              </div>
              <IconButton
                iconName="icon-delete"
                onClick={() => {
                  setFileName('');
                  setUploadFile(null);
                  const fileInput = inputRef.current;
                  if (fileInput) {
                    fileInput.value = '';
                  }
                }}
              />
            </div>
          )}
          <button type="button" onClick={() => downloadZipFolder()} className="text-sm text-[#45A2CD] underline">
            Download Template
          </button>
        </div>
        <div className="mt-4 text-sm text-gray-500">Parameter</div>
      </div>
    </div>
  );
};
