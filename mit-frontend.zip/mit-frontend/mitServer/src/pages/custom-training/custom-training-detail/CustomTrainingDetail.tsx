import { FormContent } from '@/pages/services/test-service/components';
import { useAppSelector } from '@/reducer/hooks';
import { twMerge } from 'tailwind-merge';

const CustomTrainingDetail = () => {
  const { service, datasetType, modalName, version } = useAppSelector((state) => state.customTraining.settingOptions);

  return (
    <div className="flex h-[calc(100%-3rem)] min-w-[900px]  justify-center">
      <div className={twMerge('w-3/4 bg-white p-6 pb-0 text-left')}>
        <div className="w-full rounded-lg bg-[#D7D7D733] bg-opacity-20">
          <div className="grid grid-cols-4 p-6">
            <FormContent title="Service" content={<span>{service}</span>} />
            <FormContent title="Dataset Type" content={<span>{datasetType}</span>} />
            <FormContent title="Modal Name" content={<span>{modalName}</span>} />
            <FormContent title="Version" content={<span>{version}</span>} />
            {/* <FormContent className="mt-4" title="Material" content={<span>{materialName || '--'}</span>} />
            <FormContent className="mt-4" title="Number of Prediction" content={<span>5</span>} /> */}
          </div>
        </div>
        <div className="mt-12">
          <b className="text-xl">Predicted Result</b>
        </div>
      </div>
    </div>
  );
};

export default CustomTrainingDetail;
