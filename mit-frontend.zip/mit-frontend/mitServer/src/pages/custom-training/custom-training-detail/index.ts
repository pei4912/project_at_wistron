export { default as Component } from './CustomTrainingDetail';
