import { useRouteError } from 'react-router-dom';

const ErrorPage = () => {
  const error = useRouteError();
  console.error(error);
  return (
    <div>
      <div className="grid h-screen place-items-center text-2xl font-extrabold">
        Sorry! An unexpected error has occurred.
      </div>
    </div>
  );
};

export default ErrorPage;
