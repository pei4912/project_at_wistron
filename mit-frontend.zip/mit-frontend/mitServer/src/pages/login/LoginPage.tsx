import Background from '@/assets/images/login-background.png';
import { Navigate, useLocation, useNavigate } from 'react-router-dom';
import useAuth from '@/auth/useAuth';
import { useEffect } from 'react';

const LoginPage = () => {
  const { login, authenticated } = useAuth();
  const navigate = useNavigate();
  const { state } = useLocation();

  if (authenticated) {
    const sessionItem = sessionStorage.getItem('location-from');
    const from = typeof sessionItem === 'string' ? JSON.parse(sessionItem) : null;

    return <Navigate replace to={state?.from || from || '/'} />;
  }
  localStorage.clear();

  return (
    <div
      style={{
        backgroundImage: `url(${Background})`,
        backgroundRepeat: 'no-repeat',
        backgroundSize: 'cover',
        width: '100vw',
        height: '100vh',
        backgroundColor: '#353535',
      }}
      className="grid grid-rows-3 gap-0"
    >
      <div className="row-span-1 row-start-2">
        <div className="mb-24 text-center font-jhengHei text-4xl text-mit-white">MIT Demo Server</div>
        <div className="text-center text-xl font-bold">
          <button onClick={login} className="w-56 rounded bg-black py-3 px-20 text-mit-white">
            Log in
          </button>
        </div>
        <div className="text-center text-xl font-bold">
          <button
            onClick={() => {
              localStorage.setItem('auth', 'success');
              navigate('/');
            }}
            className="mt-3 rounded bg-mit-gray py-3 px-20 text-black"
          >
            Fake login
          </button>
        </div>
      </div>
      <div className="row-span-1 row-start-3 mb-12 self-end text-center text-mit-white">MIT Demo (Ver.202304)</div>
    </div>
  );
};

export default LoginPage;
