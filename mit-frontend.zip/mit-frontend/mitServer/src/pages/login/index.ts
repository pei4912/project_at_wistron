export { default as Component } from './LoginPage';
