import { createApi } from '@reduxjs/toolkit/dist/query/react';
import { axiosBaseQuery } from './helplers';
import { I_MENU_LIST_TYPE } from './types';

export const appApi = createApi({
  reducerPath: 'api',
  baseQuery: axiosBaseQuery(),
  tagTypes: ['SUB_MENU', 'MULTIMODAL', 'CUSTOM_TRAINING'],
  endpoints: (builder) => ({
    getSubMenu: builder.query<I_MENU_LIST_TYPE[], string>({
      query: (query: string) => ({ query, url: `model/${query}` }),
    }),
  }),
});

export const { useGetSubMenuQuery } = appApi;
