import msalInstance from '@/aad/aad';
import axios from '@/axios';
import tokenInterceptor from '@/axios/tokenInterceptor';
import qs from 'query-string';

interface QueryObject {
  [key: string]: any;
}

interface QueryParams {
  permission?: any;
  query?: QueryObject;
}

export const axiosBaseQuery =
  ({ baseUrl = '/' } = {}) =>
  async ({ headers = {}, url = '', method = 'GET', data = {}, query = {} } = {}) => {
    const { permission, ...q }: QueryParams = query;
    const search = qs.stringify(q);

    try {
      const result = await axios({
        method,
        data,
        url: `${baseUrl}${url}${search ? `?${search}` : ''}`,
        ...(headers && { headers }),
      });

      return { data: result.data, meta: { permission, query: q } };
    } catch (axiosError: any) {
      const err = axiosError;
      if (err.response) {
        if (err.response.status === 403 || err.response.status === 401) {
          const { accessToken } = await msalInstance.acquireTokenSilent({
            scopes: ['https://graph.microsoft.com/.default'],
          });
          if (accessToken) {
            localStorage.setItem('graph-access-token', accessToken);
            axios.interceptors.request.use(tokenInterceptor);
            const accessResult = await axios({
              method,
              data,
              url: `${baseUrl}${url}${search ? `?${search}` : ''}`,
              ...(headers && { headers }),
            });

            return { data: accessResult.data, meta: { permission, query: q } };
          }
        }
      }

      return {
        error: { status: err.response?.status, data: err.response?.data, meta: { permission, query: q } },
      };
    }
  };
