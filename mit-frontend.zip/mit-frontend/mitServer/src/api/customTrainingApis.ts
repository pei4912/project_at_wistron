import { appApi } from './app';
import { I_TABLE_MODEL_DATA, I_TABLE_OPTIONS_PARAMS, I_GET_TABLE_DATA, I_GET_TABLE_DATA_PARAMS } from './types';

export const customTrainingApi = appApi.injectEndpoints({
  endpoints: (builder) => ({
    getTrainingTable: builder.query<{ data: I_TABLE_MODEL_DATA[] }, I_TABLE_OPTIONS_PARAMS>({
      query: (query) => ({ query, url: 'model/versions' }),
      transformResponse: (res) => {
        const transformedData = res?.data.map((item: any) => ({
          ...item,
          key: item.id, // 将 id 转换为 key
        }));
        return {
          data: transformedData || [],
        };
      },
    }),
    deleteCustomModel: builder.mutation({
      query: (data) => ({
        url: `model/versions/${data}`,
        method: 'DELETE',
      }),
    }),
    getCustomModel: builder.query<{ data: I_TABLE_MODEL_DATA[] }, I_GET_TABLE_DATA_PARAMS>({
      query: ({ modelId }) => ({
        url: `model/versions/${modelId}`,
      }),
    }),
  }),
  overrideExisting: true,
});

export const { useDeleteCustomModelMutation, useGetTrainingTableQuery, useGetCustomModelQuery } = customTrainingApi;
