import moment, { Moment } from 'moment';

export interface I_MENU_LIST_TYPE {
  id: number;
  name: string;
}
// ---------------------------------------------------------
// Multimodal Page
export interface I_MULTIMODAL_MODEL_VERSION {
  id: number;
  name: string;
  version: string;
}
export interface I_MULTIMODAL_MODEL_LIST {
  model_list: I_MULTIMODAL_MODEL_VERSION[];
  name: string;
  versions: string[];
}

export interface I_MULTIMODAL_OPTIONS_TYPE {
  id: number;
  name: string;
}

export interface I_MULTIMODAL_OPTIONS_PARAMS {
  service: string;
  type: string;
  is_default: number;
}
// ---------------------------------------------------------
// TrainingTable Page
export interface I_TABLE_MODEL_DATA {
  key: string | number;
  id: number;
  model_id: number;
  service: string;
  type: string;
  name: string;
  version: string;
  status: string;
  remark: string;
  created_at: Moment;
  updated_at: Moment;
}
export interface I_TABLE_DATA_LIST {
  total: number;
  data: I_TABLE_MODEL_DATA[];
}
export interface I_TABLE_OPTIONS_PARAMS {
  service: string;
  status: string;
  page_size: number;
  page: number;
}
export interface I_GET_TABLE_DATA_PARAMS {
  modelId:number
  page_size: number;
  page: number;
}
export interface I_GET_TABLE_DATA {
  // key: string | number;
  id: number;
  version: string;
  status: string;
  remark: string;
  created_at: Moment;
  updated_at: Moment;
}
