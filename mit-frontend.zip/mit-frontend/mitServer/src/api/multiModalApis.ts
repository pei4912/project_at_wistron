import { appApi } from './app';
import {
  I_MENU_LIST_TYPE,
  I_MULTIMODAL_OPTIONS_PARAMS,
  I_MULTIMODAL_OPTIONS_TYPE,
  I_MULTIMODAL_MODEL_LIST,
  I_MULTIMODAL_MODEL_VERSION,
} from './types';

export const multiModalApi = appApi.injectEndpoints({
  endpoints: (builder) => ({
    getServiceOption: builder.query<I_MULTIMODAL_OPTIONS_TYPE[], void>({
      query: () => ({ url: 'model/services' }),
    }),
    getTypeOption: builder.query<I_MULTIMODAL_OPTIONS_TYPE[], void>({
      query: () => ({ url: 'model/types' }),
    }),
    getModelSystemOption: builder.query<
      { modalSysOption: I_MULTIMODAL_MODEL_VERSION[]; versionOption: { name: string; data: I_MENU_LIST_TYPE[] }[] },
      I_MULTIMODAL_OPTIONS_PARAMS
    >({
      query: (query) => ({ query, url: 'model/models' }),
      transformResponse: (res) => {
        const versionOption: { name: string; data: I_MENU_LIST_TYPE[] }[] = [];
        res?.map((modal: I_MULTIMODAL_MODEL_LIST) => {
          const versionArray: I_MENU_LIST_TYPE[] = [];
          modal.model_list.map((list) => versionArray.push({ id: list.id, name: list.version }));
          versionOption.push({ name: modal.name, data: versionArray });
        });

        return {
          modalSysOption: res.map((modal: I_MULTIMODAL_MODEL_LIST) => modal.model_list[modal.model_list.length - 1]),
          versionOption: versionOption,
        };
      },
    }),
    getMaterialTempOption: builder.query<I_MULTIMODAL_OPTIONS_TYPE[], I_MULTIMODAL_OPTIONS_PARAMS>({
      query: (query) => ({ query, url: 'model/datasets' }),
    }),
    getInference: builder.query<{ heatmap: string; result: any[] }, { model_id: number; dataset_id: number }>({
      query: (query) => ({ query, url: 'inference/template' }),
    }),
    postInferenceFile: builder.mutation({
      invalidatesTags: ['MULTIMODAL'],
      query: (data) => ({
        data,
        url: 'inference/file',
        method: 'POST',
        headers: {
          'Content-Type': 'multipart/form-data',
        },
      }),
    }),
  }),
  overrideExisting: true,
});

export const {
  useGetServiceOptionQuery,
  useGetTypeOptionQuery,
  useGetModelSystemOptionQuery,
  useGetMaterialTempOptionQuery,
  useGetInferenceQuery,
  usePostInferenceFileMutation,
} = multiModalApi;
