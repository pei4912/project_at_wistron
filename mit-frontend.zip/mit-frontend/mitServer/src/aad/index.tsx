import { useState } from 'react';

import {
  MsalProvider as _MsalProvider,
  useIsAuthenticated as _useIsAuthenticated,
  useMsal as _useMsal,
} from '@azure/msal-react';
import { useUpdateEffect } from 'react-use';

import _msalInstance from './aad';

let authenticated = true;

export const accounts = [{ username: 'dummy' }];

export const instance = {
  loginRedirect: () => {},
  logoutRedirect: () => {},
  loginPopup: () => {},
  logoutPopup: () => {},
  getAllAccounts: () => accounts,
  setActiveAccount: () => {},
  getActiveAccount: () => accounts[0],
  acquireTokenSilent: () => ({}),
};

export const msalInstance = import.meta.env.VITE_MOCK_AD === '1' ? instance : _msalInstance;
export const MsalProvider =
  import.meta.env.VITE_MOCK_AD === '1'
    ? ({ children }: { children: React.ReactElement }) => <>{children}</>
    : _MsalProvider;
export const useIsAuthenticated = import.meta.env.VITE_MOCK_AD === '1' ? () => authenticated : _useIsAuthenticated;

export const useMsal =
  import.meta.env.VITE_MOCK_AD === '1'
    ? () => {
        const [_authenticated, setAuthenticated] = useState(authenticated);
        const [msalInstance, setMsalInstance] = useState({
          ...instance,
          loginRedirect: () => setAuthenticated(true),
          logoutRedirect: () => setAuthenticated(false),
        });

        useUpdateEffect(() => {
          authenticated = _authenticated;
          setMsalInstance((prev) => ({ ...prev, authenticated: _authenticated }));

          if (!_authenticated) {
            window.location.replace('/login');
          }
        }, [_authenticated]);

        return { accounts, instance: msalInstance, inProgress: 'none' };
      }
    : _useMsal;
