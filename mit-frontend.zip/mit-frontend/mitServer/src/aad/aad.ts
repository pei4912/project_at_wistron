import { PublicClientApplication, EventType } from '@azure/msal-browser';

import { msalConfig } from './authConfig';
import { store } from '@/reducer/store';
import { setUserProfile } from '@/reducer/slice/authSlice';

import type { EventMessage, AuthenticationResult } from '@azure/msal-browser';

const msalInstance = new PublicClientApplication(msalConfig);
const accounts = msalInstance.getAllAccounts();

if (accounts.length > 0) {
  msalInstance.setActiveAccount(accounts[0]);
}

msalInstance.addEventCallback((event: EventMessage) => {
  if (
    [EventType.HANDLE_REDIRECT_START, EventType.POPUP_OPENED].includes(event.eventType) &&
    !['/login'].includes(window.location.pathname)
  ) {
    sessionStorage.setItem(
      'location-from',
      JSON.stringify({ pathname: window.location.pathname, search: window.location.search, hash: window.location.hash })
    );
  }

  if (event.eventType === EventType.LOGOUT_START) {
    sessionStorage.removeItem('location-from');
  }

  if (event.eventType === EventType.LOGOUT_SUCCESS) {
    sessionStorage.clear();
  }

  if (
    (event.eventType === EventType.LOGIN_SUCCESS || event.eventType === EventType.ACQUIRE_TOKEN_SUCCESS) &&
    event.payload
  ) {
    const payload = event.payload as AuthenticationResult;
    localStorage.setItem('token', payload.idToken);
    const account = payload.account;
    msalInstance.setActiveAccount(account);
    msalInstance.acquireTokenSilent({ scopes: ['https://graph.microsoft.com/.default'] }).then(({ accessToken }) => {
      if (import.meta.env.VITE_MOCK_AD === '1') {
        return;
      }

      if (accessToken) {
        localStorage.setItem('graph-access-token', accessToken);
        fetch(
          `${
            import.meta.env.VITE_GRAPH_API_URL
          }/me?$select=businessPhones,department,displayName,mail,givenName,surname,mailNickname,id,officeLocation,userPrincipalName`,
          { headers: { Authorization: `Bearer ${accessToken}` } }
        ).then((res) => res.json().then((data) => store.dispatch(setUserProfile(data))));
      }
    });
  }
});

export default msalInstance;
