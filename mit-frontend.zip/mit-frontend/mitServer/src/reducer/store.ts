import { configureStore, ThunkAction, Action } from '@reduxjs/toolkit';
import menuReducer, { MenuState } from './slice/menuSlice';
import authReducer, { AuthState } from './slice/authSlice';
import storage from 'redux-persist/lib/storage';
import { persistReducer, persistStore, FLUSH, REHYDRATE, PAUSE, PERSIST, PURGE, REGISTER } from 'redux-persist';
import { setupListeners } from '@reduxjs/toolkit/query';
import { appApi } from '@/api/app';
import multimodalReducer, { MultimodalState } from './slice/multimodalSlice';
import CustomTrainingReducer, { CustomTrainingState } from './slice/customTrainingSlice';

const persistConfig = {
  key: 'root',
  storage,
};

export const store = configureStore({
  reducer: {
    menu: persistReducer<MenuState>(persistConfig, menuReducer),
    auth: persistReducer<AuthState>(persistConfig, authReducer),
    multimodal: persistReducer<MultimodalState>(persistConfig, multimodalReducer),
    customTraining: persistReducer<CustomTrainingState>(persistConfig, CustomTrainingReducer),
    [appApi.reducerPath]: appApi.reducer,
  },
  middleware: (getDefaultMiddleware) =>
    getDefaultMiddleware({
      serializableCheck: {
        ignoredActions: [FLUSH, REHYDRATE, PAUSE, PERSIST, PURGE, REGISTER],
      },
    }).concat([appApi.middleware]),
  devTools: import.meta.env.DEV,
});

setupListeners(store.dispatch);
export const persistor = persistStore(store);
export type AppDispatch = typeof store.dispatch;
export type RootState = ReturnType<typeof store.getState>;
export type AppThunk<ReturnType = void> = ThunkAction<ReturnType, RootState, unknown, Action<string>>;
