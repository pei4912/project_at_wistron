import { createSlice } from '@reduxjs/toolkit';

export interface MultimodalState {
  settingOptions: {
    service: string;
    datasetType: string;
    modalName: string;
    materialName: string;
    version: string;
    material: string;
    modal: string;
    modelID: number;
    materialID: number;
  };
  demoData: {
    heatmap: string | null;
    result: any[] | null;
  };
  resetState: boolean;
}

const initialState: MultimodalState = {
  settingOptions: {
    service: '',
    datasetType: '',
    modalName: '',
    materialName: '',
    version: '',
    material: '',
    modal: '',
    modelID: 0,
    materialID: 0,
  },
  demoData: {
    heatmap: null,
    result: null,
  },
  resetState: false,
};

export const multimodalSlice = createSlice({
  name: 'multimodal',
  initialState: initialState,
  reducers: {
    setSettingOptions: (state, action) => {
      state.settingOptions = action.payload;
    },
    setDemoData: (state, action) => {
      state.demoData = action.payload;
    },
    setResetState: (state, action) => {
      state.resetState = action.payload;
    },
  },
});

export const { setSettingOptions, setDemoData, setResetState } = multimodalSlice.actions;
export default multimodalSlice.reducer;
