import { createSlice } from '@reduxjs/toolkit';

export interface AuthState {
  userProfile: any;
}

const initialState: AuthState = {
  userProfile: null,
};

export const authSlice = createSlice({
  name: 'auth',
  initialState: initialState,
  reducers: {
    setUserProfile: (state, action) => {
      state.userProfile = action.payload;
      return state;
    },
  },
});

export const { setUserProfile } = authSlice.actions;
export default authSlice.reducer;
