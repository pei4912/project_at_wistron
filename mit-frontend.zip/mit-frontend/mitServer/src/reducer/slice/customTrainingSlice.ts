import { createSlice } from '@reduxjs/toolkit';

export interface CustomTrainingState {
  settingOptions: {
    service: string;
    datasetType: string;
    modalName: string;
    version: string;
  };
}

const initialState: CustomTrainingState = {
  settingOptions: {
    service: '',
    datasetType: '',
    modalName: '',
    version: '',
  },
};

export const customTrainingSlice = createSlice({
  name: 'customTraining',
  initialState: initialState,
  reducers: {
    setSettingOptions: (state, action) => {
      state.settingOptions = action.payload;
    },
  },
});

export const { setSettingOptions } = customTrainingSlice.actions;
export default customTrainingSlice.reducer;
