import { createSlice } from '@reduxjs/toolkit';

export interface MenuState {
  visible: boolean;
}

const initialState: MenuState = {
  visible: true,
};

export const menuSlice = createSlice({
  name: 'menu',
  initialState: initialState,
  reducers: {
    setVisible: (state: MenuState) => {
      state.visible = !state.visible;
      return state;
    },
  },
});

export const { setVisible } = menuSlice.actions;
export default menuSlice.reducer;
