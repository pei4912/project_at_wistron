import { useCallback, useMemo } from 'react';

import { useMsal, accounts as dummyAccounts } from '@/aad';
import { loginRequest } from '@/aad/authConfig';

export type User = {
  email?: string;
  first_name: string;
  id: number;
  last_name: string;
  roles: string[];
  username: string;
};

export default function useAuth() {
  const { accounts, inProgress, instance } = useMsal();
  const getActiveAccount = useCallback(() => instance?.getActiveAccount(), [instance]);
  const authenticated = useMemo(() => inProgress === 'none' && !!getActiveAccount(), [inProgress, getActiveAccount]);

  const authenticating = useMemo(() => inProgress !== 'none', [inProgress]);

  const user = useMemo(() => getActiveAccount()?.username, [getActiveAccount]);

  const login = useCallback(() => {
    if (window.parent === window) {
      instance.loginRedirect(loginRequest);
    } else {
      instance.loginPopup(loginRequest);
    }
  }, [instance]);

  const logout = useCallback(() => {
    if (window.parent === window) {
      instance.logoutRedirect({
        postLogoutRedirectUri: '/login',
      });
    } else {
      instance.logoutPopup({
        postLogoutRedirectUri: '/login',
      });
    }
  }, [instance]);

  return {
    accounts,
    authenticated,
    authenticating,
    login,
    logout,
    getActiveAccount,
    user: import.meta.env.VITE_MOCK_AD === '1' ? dummyAccounts[0] : user,
  };
}
