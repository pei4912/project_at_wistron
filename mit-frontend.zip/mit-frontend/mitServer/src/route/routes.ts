import LoginPage from '@/pages/login/LoginPage';

export const publicRoutes = [
  {
    path: '/login',
    Component: LoginPage,
  },
];

export const childrenRoutes = [
  { index: true, lazy: () => import('@/pages/services/multi-modal'), breadcrumb: 'Service / Multimodal' },
  {
    path: 'service',
    icon: 'service-icon',
    collapse: true,
    children: [
      {
        index: true,
        lazy: () => import('@/pages/services/multi-modal'),
        breadcrumb: 'Service',
        show: true,
      },
      {
        path: 'multi-modal',
        lazy: () => import('@/pages/services/multi-modal'),
        breadcrumb: 'Multimodal',
        show: true,
      },
      {
        path: 'multi-modal/demo/:id',
        lazy: () => import('@/pages/services/test-service'),
        show: false,
      },
    ],
  },
  {
    path: 'custom-training',
    lazy: () => import('@/pages/custom-training/custom-training'),
    breadcrumb: 'Custom Training',
    icon: 'custom-training-icon',
    show: true,
  },
  {
    path: 'custom-training/detail/:id',
    lazy: () => import('@/pages/custom-training/custom-training-detail'),
    breadcrumb: 'Custom Training Detail',
    show: false,
  },
];
