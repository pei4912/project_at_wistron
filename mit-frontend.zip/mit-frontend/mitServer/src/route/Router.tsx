import { createBrowserRouter } from 'react-router-dom';
import ErrorPage from '@/pages/ErrorPage';
import Root from './Root';
import { childrenRoutes, publicRoutes } from './routes';
import RequireAuth from './RequireAuth';

export const router = createBrowserRouter([
  ...publicRoutes,
  {
    path: '/',
    element: (
      <RequireAuth>
        <Root />
      </RequireAuth>
    ),
    children: childrenRoutes,
    errorElement: <ErrorPage />,
  },
]);
