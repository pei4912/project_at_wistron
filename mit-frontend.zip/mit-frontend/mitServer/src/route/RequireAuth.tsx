import useAuth from '@/auth/useAuth';
import { Navigate, useLocation } from 'react-router-dom';

export default function RequireAuth({ children }: { children: JSX.Element }) {
  const { authenticated, authenticating } = useAuth();
  const { pathname, search, hash } = useLocation();

  if (authenticating) {
    return <div>loading...</div>;
  }

  if (!authenticated && localStorage.getItem('auth') === null) {
    return <Navigate replace to="/login" state={{ from: { pathname, search, hash } }} />;
  }

  return children;
}
