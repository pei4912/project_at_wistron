import { Outlet } from 'react-router-dom';
import Aside from '@/components/aside';
import PageContainer from '@/components/page-container/PageContainer';

export default function Root() {
  return (
    <>
      <div className="flex h-screen w-screen text-center">
        <Aside />
        <PageContainer>
          <Outlet />
        </PageContainer>
      </div>
    </>
  );
}
