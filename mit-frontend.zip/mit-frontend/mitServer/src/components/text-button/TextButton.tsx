import { twMerge } from 'tailwind-merge';

const typeTheme = {
  white: (disable: boolean) =>
    twMerge(
      'bg-white hover:bg-mit-gray-200',
      disable && 'bg-white border-mit-gray-300 text-mit-gray-400 hover:bg-white'
    ),
  default: (disable: boolean) =>
    twMerge(
      'bg-transparent hover:bg-mit-gray-200',
      disable && 'bg-white border-mit-gray-300 text-mit-gray-400 hover:bg-white'
    ),
  fill: (disable: boolean) =>
    twMerge(
      'bg-black text-white hover:bg-mit-gray-600 hover:border-mit-gray-600',
      disable && 'bg-mit-gray-400 border-mit-gray-400 hover:bg-mit-gray-400 hover:border-mit-gray-400'
    ),
};

export type TextButtonProps = {
  type?: keyof typeof typeTheme;
  children?: React.ReactElement | string;
  disabled?: boolean;
  onClick?: () => void;
  className?: string;
  isFormSubmit?: boolean;
};

const TextButton = ({
  type = 'default',
  children,
  disabled = false,
  onClick,
  className,
  isFormSubmit = false,
}: TextButtonProps) => {
  return (
    <button
      type={isFormSubmit ? 'submit' : 'button'}
      className={twMerge('rounded border border-black', className, typeTheme[type](disabled))}
      disabled={disabled}
      onClick={onClick}
    >
      {children}
    </button>
  );
};

export default TextButton;
