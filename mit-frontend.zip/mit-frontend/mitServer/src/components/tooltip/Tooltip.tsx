import { cloneElement, Fragment, isValidElement, useRef, useMemo, useState, useEffect } from 'react';

import {
  offset,
  shift,
  arrow,
  autoUpdate,
  autoPlacement,
  useFloating,
  useInteractions,
  useClick,
  useFocus,
  useRole,
  useDismiss,
  FloatingPortal,
  useMergeRefs,
} from '@floating-ui/react';
import { Transition } from '@headlessui/react';
import { twMerge } from 'tailwind-merge';

import type { Strategy, Placement } from '@floating-ui/react';

const FLIP_SIDES: { [key: string]: string } = {
  left: 'right',
  right: 'left',
  top: 'bottom',
  bottom: 'top',
};

type TooltipProps = {
  label: React.ReactNode | (({ isOpen, close }: { isOpen: boolean; close?: () => void }) => React.ReactNode);
  children:
    | (React.ReactNode & { ref?: any })
    | (({ isOpen, close }: { isOpen: boolean; close?: () => void }) => React.ReactNode & { ref?: any });
  className?: string;
  strategy?: Strategy;
  placement?: 'auto' | Placement;
  show?: boolean;
  interactive?: boolean;
};

export default function Tooltip({
  children,
  label,
  className = '',
  strategy = 'fixed',
  placement = 'auto',
  show = true,
}: TooltipProps): JSX.Element {
  const [open, setOpen] = useState<boolean>(false);
  const arrowRef = useRef<HTMLDivElement>(null);
  const {
    x,
    y,
    reference,
    floating,
    context,
    middlewareData,
    strategy: _strategy,
    placement: _placement,
  } = useFloating({
    open,
    strategy,
    onOpenChange: setOpen,
    middleware: [
      offset(8),
      shift({ padding: 8 }),
      ...(placement === 'auto' ? [autoPlacement()] : []),
      ...(arrowRef.current ? [arrow({ element: arrowRef.current })] : []),
    ],
    ...(placement !== 'auto' && { placement }),
    whileElementsMounted: autoUpdate,
  });

  const { getReferenceProps, getFloatingProps } = useInteractions([
    useClick(context),
    useFocus(context),
    useRole(context, { role: 'tooltip' }),
    useDismiss(context),
  ]);

  const myChildren = useMemo(
    () => (typeof children === 'function' ? children({ isOpen: open }) : children),
    [children, open]
  );

  const ref = useMergeRefs([reference, ...('ref' in myChildren ? [myChildren.ref] : [])]);
  const [timeId, setTimeId] = useState<any>(null);

  useEffect(() => {
    if (open) {
      const id = setTimeout(() => {
        setOpen(false);
      }, 8000);
      setTimeId(id);
    }
    clearTimeout(timeId);
  }, [open]);

  return (
    <>
      {isValidElement(myChildren) && cloneElement(myChildren, getReferenceProps({ ref, ...myChildren.props }))}
      <FloatingPortal>
        <Transition show={show && open && !!label}>
          <div
            {...getFloatingProps({
              ref: floating,
              className: 'z-100',
              style: {
                position: _strategy,
                top: y ?? '',
                left: x ?? '',
              },
            })}
          >
            <Transition.Child
              as={Fragment}
              enter="transition-opacity ease-in-out"
              enterFrom="opacity-0"
              enterTo="opacity-100"
              leave="transition-opacity ease-in-out"
              leaveFrom="opacity-100"
              leaveTo="opacity-0"
            >
              <div className={twMerge('whitespace-nowrap rounded shadow', className)}>
                {typeof label === 'function' ? label({ isOpen: open, close: () => setOpen(false) }) : label}
                <div
                  className="absolute h-3 w-3 rotate-45"
                  ref={arrowRef}
                  style={{
                    top: middlewareData.arrow?.y ? middlewareData.arrow.y + middlewareData.arrow.centerOffset : '',
                    left: middlewareData.arrow?.x ? middlewareData.arrow.x + middlewareData.arrow.centerOffset : '',
                    [FLIP_SIDES[_placement.split('-')[0]]]: '-0.375rem',
                  }}
                />
              </div>
            </Transition.Child>
          </div>
        </Transition>
      </FloatingPortal>
    </>
  );
}
