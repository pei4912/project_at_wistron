import { useEffect, useRef, useState } from 'react';
import { twMerge } from 'tailwind-merge';
import { CheckboxSelectOption } from '../select/MultiSelect';
import SvgIcon from '@/assets/SvgIcon';

type CountEllipseProps = {
  className?: string;
  width: number;
  ellipseArray?: CheckboxSelectOption[];
  click?: (value: CheckboxSelectOption) => void;
};

const CountEllipse = ({ className, width, ellipseArray, click = () => {} }: CountEllipseProps) => {
  const ref = useRef<HTMLInputElement>(null);
  const [displayItemCount, setDisplayItemCount] = useState(0);

  const getContentWidth = (content: string) => {
    const tempEl = document.createElement('div');
    tempEl.style.display = 'inline-block';
    tempEl.style.visibility = 'hidden';
    tempEl.innerText = content;
    document.body.appendChild(tempEl);
    const tempWidth = tempEl.offsetWidth;
    document.body.removeChild(tempEl);
    return tempWidth;
  };

  const calculateDisplayItemCount = (array: CheckboxSelectOption[] = []) => {
    let totalWidth = 0;
    let i = 0;
    for (i; i < array.length; i++) {
      totalWidth += 70 + getContentWidth(array[i].value);
      if (totalWidth > width + 70) {
        break;
      }
    }

    return totalWidth > width + 70 ? Math.max(i, 0) : i;
  };

  useEffect(() => {
    if (ref.current) {
      const newWidth = ref.current.offsetWidth;
      if (newWidth !== 0) {
        const newItemCount = calculateDisplayItemCount(ellipseArray);
        setDisplayItemCount(newItemCount);
      }
    }
  }, [ellipseArray]);

  const lastItem = ellipseArray && ellipseArray[ellipseArray.length - 1];

  return (
    <div className={twMerge('flex', className)} style={{ width: 'fit-content' }} ref={ref}>
      {ellipseArray?.map((content, i) => (
        <div
          key={i}
          className={twMerge(
            'mr-1 flex cursor-default items-center rounded bg-black pl-2 pr-1 text-sm text-white',
            i >= displayItemCount && 'hidden'
          )}
        >
          {content.value}
          <button
            onClick={(e) => {
              e.stopPropagation();
              e.preventDefault();
              click(content);
            }}
            className="cursor-pointer"
          >
            <SvgIcon iconName="close-icon-white" wrapperStyle="ml-1" />
          </button>
        </div>
      ))}
      {ellipseArray && ellipseArray.length > displayItemCount && (
        <div className="flex items-center rounded bg-black px-2 text-sm text-white">+{ellipseArray.length}..</div>
      )}
      {!ellipseArray || (displayItemCount > ellipseArray.length && lastItem) ? (
        <div className="flex items-center rounded bg-black px-2 text-sm text-white">{lastItem?.value}</div>
      ) : null}
    </div>
  );
};

export default CountEllipse;
