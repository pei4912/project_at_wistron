import { InputHTMLAttributes } from 'react';
import { twMerge } from 'tailwind-merge';

interface RadioSelectProps extends InputHTMLAttributes<HTMLInputElement> {
  label: string;
  groupName?: string;
  className?: string;
  disabled?: boolean;
  selected?: boolean;
}

const RadioSelect = ({
  label = '',
  groupName = 'group',
  className,
  disabled = false,
  selected = false,
  ...rest
}: RadioSelectProps) => {
  return (
    <div className={twMerge('flex items-center', className)}>
      <input
        type="radio"
        className={twMerge('accent-black', disabled && 'accent-mit-gray-400')}
        name={groupName}
        id={label}
        disabled={disabled}
        defaultChecked={selected}
        {...rest}
      />
      <label htmlFor={label} className={twMerge('ml-1', disabled && 'text-mit-gray-400')}>
        {label}
      </label>
    </div>
  );
};

export default RadioSelect;
