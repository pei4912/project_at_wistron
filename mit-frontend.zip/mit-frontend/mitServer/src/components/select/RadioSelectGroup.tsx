import { twMerge } from 'tailwind-merge';
import RadioSelect from './RadioSelect';

export type OptionProps = {
  label: string;
  groupName?: string;
  disabled?: boolean;
};

type RadioSelectProps = {
  options: OptionProps[];
  title?: string;
  titleClassName?: string;
  className?: string;
  onChange?: (e: React.ChangeEvent<HTMLInputElement>) => void;
  required?: boolean;
  selected?: string;
};

const RadioSelectGroup = ({
  options,
  title,
  titleClassName,
  className,
  onChange,
  required,
  selected,
}: RadioSelectProps) => {
  const selectedIndex = selected !== undefined ? options.findIndex((option) => option.label === selected) : 0;
  return (
    <div className={twMerge('w-full', className)}>
      <div className="flex flex-row">
        {required && title && <div className="text-red-500">＊</div>}
        <div className={twMerge('mb-1', titleClassName)}>{title}</div>
      </div>
      <div className="flex flex-row">
        {options.map((option, i) => (
          <RadioSelect
            key={i}
            label={option.label}
            value={option.label}
            className="mr-2"
            groupName={option.groupName}
            disabled={option.disabled}
            selected={i === selectedIndex}
            onChange={onChange}
          />
        ))}
      </div>
    </div>
  );
};

export default RadioSelectGroup;
