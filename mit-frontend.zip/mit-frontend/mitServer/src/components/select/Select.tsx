import { twMerge } from 'tailwind-merge';
import { Fragment, useEffect, useState } from 'react';
import { Combobox, Transition } from '@headlessui/react';
import SvgIcon from '@/assets/SvgIcon';

export type SelectProps = {
  label?: string;
  className?: string;
  disabled?: boolean;
  placeholder?: string;
  options: { id: number; name: string }[];
  selected?: string;
  formName?: string;
  required?: boolean;
  onChange?: (selected: { name: string; id: number }) => void;
  invalid?: boolean;
};

const Select = ({
  label,
  options,
  className,
  disabled = false,
  placeholder = 'Please select',
  selected = '',
  formName = '',
  required = false,
  invalid,
  onChange,
}: SelectProps) => {
  const defaultSelect = selected === '' ? {} : options.filter((option) => option.name === selected)[0];
  const [select, setSelect] = useState<{ name?: string; id?: number }>(defaultSelect);
  const [query, setQuery] = useState('');
  const [inputActive, setInputActive] = useState(false);

  const handleChange = (value: { name: string; id: number }) => {
    setSelect(value);
    onChange && onChange(value);
  };

  const filterOption =
    query === ''
      ? options
      : options.filter((option) =>
          option.name.toLowerCase().replace(/\s+/g, '').includes(query.toLowerCase().replace(/\s+/g, ''))
        );

  useEffect(() => {
    selected === ''
      ? setSelect({ name: '', id: 0 })
      : selected && setSelect(options.filter((option) => option.name === selected)[0]);
  }, [selected]);

  return (
    <div className={twMerge(className, 'flex h-fit flex-col text-sm')}>
      <Combobox value={select} onChange={handleChange} disabled={disabled} name={formName}>
        {({ open }) => (
          <>
            <Combobox.Label className="flex flex-row text-gray-500">
              {required && label && <div className="text-red-500">＊</div>}
              {label}
            </Combobox.Label>
            <div className="relative mt-1">
              <div
                className={twMerge(
                  'relative flex w-full cursor-pointer items-center justify-between rounded border border-gray-400 bg-white px-2 py-1 text-left hover:border-black active:border-mit-yellow sm:text-sm',
                  disabled &&
                    'cursor-not-allowed bg-mit-gray-200 text-gray-500 hover:border-mit-gray-400 active:border-mit-gray-400',
                  inputActive && 'border-mit-yellow', // 焦點時邊框顏色
                  invalid && (select.id === undefined || select.id === 0) && 'border-red-500'
                )}
              >
                <Combobox.Button
                  className={twMerge(
                    'inset-y-0 right-0 flex w-full items-center justify-between focus:border-mit-yellow',
                    disabled && 'cursor-not-allowed'
                  )}
                >
                  <Combobox.Input
                    className={twMerge(
                      'w-full border-none text-sm leading-5 text-gray-900 focus:outline-none focus:ring-0 active:border-none',
                      // select.name === placeholder && 'text-gray-500',
                      disabled && 'cursor-not-allowed text-gray-500',
                      open && 'text-gray-300'
                    )}
                    displayValue={(option: { name: string; value: string }) => option.name}
                    onChange={(e) => setQuery(e.target.value)}
                    onClick={() => setSelect(select)}
                    onFocus={() => !open && setInputActive(true)}
                    onBlur={() => setInputActive(false)}
                    placeholder={placeholder}
                  />
                  {disabled ? <SvgIcon iconName="chevron-down-gray-icon" /> : <SvgIcon iconName="chevron-down-icon" />}{' '}
                </Combobox.Button>
              </div>
              {invalid && (select.id === undefined || select.id === 0) && !open && (
                <div className="absolute right-0 z-10 text-red-500">This field is required</div>
              )}
              <Transition as={Fragment} afterLeave={() => setQuery('')}>
                <Combobox.Options className="absolute z-10 max-h-60 w-full overflow-auto rounded-md bg-white py-1 text-base shadow-md ring-1 ring-black ring-opacity-5 focus:outline-none sm:text-sm">
                  {filterOption.length === 0 ? (
                    query !== '' ? (
                      <div className="cursor-default select-none px-4 py-2 text-gray-700">Nothing found.</div>
                    ) : (
                      <div className="cursor-default select-none px-4 py-2 text-gray-700">No data.</div>
                    )
                  ) : (
                    filterOption.map((option, i) => (
                      <Combobox.Option
                        id={`option-${option.id}`}
                        key={i}
                        className={({ active }) =>
                          `cursor-default select-none px-4 py-2 ${active ? 'bg-mit-hover-yellow' : 'text-gray-900'} ${
                            option.name === select.name && 'bg-mit-hover-yellow'
                          }`
                        }
                        value={option}
                      >
                        {({ selected }) => (
                          <>
                            <span className={twMerge('block truncate', selected ? 'font-medium' : 'font-normal')}>
                              {option.name}
                            </span>
                          </>
                        )}
                      </Combobox.Option>
                    ))
                  )}
                </Combobox.Options>
              </Transition>
            </div>
          </>
        )}
      </Combobox>
    </div>
  );
};

export default Select;
