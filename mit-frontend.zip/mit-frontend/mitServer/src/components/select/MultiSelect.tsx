import { Fragment, useCallback, useRef, useState } from 'react';

import { Listbox, Transition } from '@headlessui/react';
import { twMerge } from 'tailwind-merge';
import { useMeasure } from 'react-use';
import SvgIcon from '@/assets/SvgIcon';
import CountEllipse from '../ellipse/CountEllipse';

type CheckboxSelectProps = {
  className?: string;
  buttonClassName?: string;
  optionClassName?: string;
  label?: React.ReactNode;
  labelClassName?: string;
  options?: CheckboxSelectOption[];
  selected?: CheckboxSelectOption[];
  placeholder?: string;
  onChange?: (value: CheckboxSelectOption[]) => void;
  firstAll?: boolean;
  disabled?: boolean;
  formName?: string;
};

export type CheckboxSelectOption = {
  key: string;
  value: string;
  disabled?: boolean;
};

export default function CheckboxSelect({
  className,
  buttonClassName,
  optionClassName,
  labelClassName,
  label,
  options = [],
  selected = [],
  placeholder = 'Please select',
  onChange = () => {},
  disabled = false,
  formName = '',
}: CheckboxSelectProps) {
  const getSelectedItems = useCallback((items: CheckboxSelectOption[]) => items, [options]);

  const handleOnChange = useCallback(
    (curr: CheckboxSelectOption[]) => {
      setSelectedItems(() => {
        const setValue = (_value: CheckboxSelectOption[]) => {
          selectedRef.current = _value;

          return _value;
        };

        return setValue(curr);
      });
    },
    [options]
  );

  const [selectedItems, setSelectedItems] = useState(() => getSelectedItems(selected));
  const [ref, { width }] = useMeasure<HTMLDivElement>();

  const selectedRef = useRef<CheckboxSelectOption[]>(getSelectedItems(selected));

  const selectOnCancel = (option: CheckboxSelectOption) => {
    setSelectedItems(() => {
      const setTargetOption = (_option: CheckboxSelectOption) => {
        selectedRef.current = selectedRef.current.filter((item) => item.key !== _option.key);
        return selectedRef.current.filter((item) => item.key !== _option.key);
      };
      return setTargetOption(option);
    });
  };

  return (
    <div className={twMerge('flex flex-col text-sm', className)}>
      <Listbox
        by="key"
        value={selectedItems}
        onChange={(curr) => {
          handleOnChange(curr);
          onChange(selectedRef.current);
        }}
        multiple
        disabled={disabled}
        name={formName}
      >
        {({ open }) => (
          <>
            <Listbox.Label className={twMerge('mb-1 text-gray-500', labelClassName)}>{label}</Listbox.Label>
            <div className="relative" ref={ref}>
              <Listbox.Button as={Fragment}>
                <div
                  className={twMerge(
                    'flex w-full cursor-pointer items-center justify-between rounded border border-gray-400 bg-transparent py-1 px-2 text-left shadow-sm hover:border-black focus:border-mit-yellow focus:outline-none sm:text-sm',
                    open && 'border-mit-yellow',
                    disabled &&
                      'cursor-not-allowed bg-mit-gray-200 text-gray-500 hover:border-mit-gray-400  active:border-mit-gray-400',
                    buttonClassName
                  )}
                >
                  {selectedItems.length > 0 ? (
                    <div style={{ maxWidth: `calc(${width} - 35px)` }}>
                      <CountEllipse
                        width={width - 35}
                        ellipseArray={selectedItems}
                        className="text-sm"
                        click={(e) => selectOnCancel(e)}
                      />
                    </div>
                  ) : (
                    <span className="text-gray-500">{placeholder}</span>
                  )}
                  {open ? (
                    <SvgIcon iconName="chevron-down-icon" wrapperStyle="rotate-180" />
                  ) : (
                    <SvgIcon iconName="chevron-down-icon" />
                  )}
                </div>
              </Listbox.Button>
              <Transition
                as={Fragment}
                leave="transition ease-in duration-100"
                leaveFrom="opacity-100"
                leaveTo="opacity-0"
              >
                <Listbox.Options
                  className={twMerge(
                    'border-divider z-10 max-h-60 w-full overflow-auto rounded-md border bg-mit-white py-1 text-sm shadow-lg focus:outline-none',
                    optionClassName
                  )}
                >
                  {options.length === 0 ? (
                    <Listbox.Option
                      disabled
                      value={{}}
                      className="relative cursor-default select-none py-2 pl-3 pr-9 text-black"
                    >
                      <Ellipsis label="No Options" className="opacity-50"></Ellipsis>
                    </Listbox.Option>
                  ) : (
                    options.map((option) => (
                      <Listbox.Option
                        aria-label={`option-${option.key}`}
                        disabled={option.disabled}
                        key={option.key}
                        className={({ selected, active }) =>
                          twMerge(
                            active ? 'bg-mit-hover-yellow text-black' : 'text-black',
                            'relative cursor-default select-none px-2.5 py-2',
                            selected && 'bg-mit-hover-yellow'
                          )
                        }
                        value={option}
                      >
                        {({ selected, active, disabled }) => (
                          <div className={twMerge('flex items-center justify-between')}>
                            <Ellipsis
                              label={option.value}
                              className={twMerge(selected ? 'font-semibold' : 'font-normal', disabled && 'opacity-50')}
                            />
                            {selected && <SvgIcon iconName="check-icon-yellow" />}
                          </div>
                        )}
                      </Listbox.Option>
                    ))
                  )}
                </Listbox.Options>
              </Transition>
            </div>
          </>
        )}
      </Listbox>
    </div>
  );
}

function Ellipsis({ label, className }: { label?: React.ReactNode; className?: string }) {
  return <span className={twMerge('block truncate', className)}>{label}</span>;
}
