import { twMerge } from 'tailwind-merge';

export default function Loading({ className = '' }: { className?: string }) {
  return (
    <div className={twMerge('flex h-screen w-screen flex-col items-center justify-center space-y-2', className)}>
      <picture className="h-32 w-32 animate-pulse">
        <source srcSet="../assets/icons/mit-logo-icon.svg" type="image/svg" />
        <source srcSet="../assets/icons/mit-logo-icon.svg" type="image/svg" />
        <img src="../assets/icons/mit-logo-icon.svg" alt="logo" className="h-32 w-32 animate-pulse" />
      </picture>
    </div>
  );
}
