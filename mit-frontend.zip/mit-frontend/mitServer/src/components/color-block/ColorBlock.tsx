import { twMerge } from 'tailwind-merge';

type ColorBlockProps = {
  label: string;
  color: string;
  width?: string;
  height?: string;
};

const ColorBlock = ({ label, color, width = 'w-4', height = 'h-4' }: ColorBlockProps) => {
  return (
    <div className="my-2 ml-3 flex items-center">
      <div className={twMerge(color, width, height)} />
      <div className="ml-1">{label}</div>
    </div>
  );
};

export default ColorBlock;
