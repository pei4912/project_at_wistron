import { useState } from 'react';
import MenuLink from '../menu-link/MenuLink';
import { useAppSelector } from '@/reducer/hooks';

type MenuItem = {
  label: string;
  path: string;
  show: boolean;
};

type CollapseMenuProps = {
  title: string;
  items: MenuItem[];
  path: string;
  className?: string;
  icon?: any;
};

const CollapseMenu = ({ title, items, className, path, icon }: CollapseMenuProps) => {
  const [isOpen, setIsOpen] = useState(false);
  const asideVisible = useAppSelector((state) => state.menu.visible);

  return (
    <div className={className}>
      <MenuLink
        onClick={() => setIsOpen(!isOpen)}
        path={`${path}/${items[0].path}`}
        type="drop"
        collapseIcon={isOpen ? 'down' : 'up'}
        icon={icon}
        items={items}
      >
        {title}
      </MenuLink>
      {isOpen && asideVisible && (
        <div className="flex flex-col">
          {items?.map(
            (subMenu, i) =>
              subMenu.show && (
                <MenuLink key={i} type="sub" path={`${path}/${subMenu.path}`}>
                  {subMenu.label}
                </MenuLink>
              )
          )}
        </div>
      )}
    </div>
  );
};

export default CollapseMenu;
