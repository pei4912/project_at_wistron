import { twMerge } from 'tailwind-merge';
import { Fragment, ChangeEvent, useState } from 'react';

export type InputProps = {
  label?: string;
  className?: string;
  disabled?: boolean;
  placeholder?: string;
  formName?: string;
  required?: boolean;
  onChange?: (value: string) => void;
  onBlur?: () => void;
  value?: string;
  invalid?: boolean;
};

const Input = ({
  label,
  className,
  disabled = false,
  placeholder = 'Please Enter',
  formName,
  required = false,
  onChange = () => {},
  value,
  invalid,
}: InputProps) => {
  const [inputActive, setInputActive] = useState(false);

  const handleInputChange = (e: ChangeEvent<HTMLInputElement>) => {
    const newValue = e.target.value;
    if (onChange) {
      onChange(newValue);
    }
  };
  return (
    <div className={twMerge(className, 'flex h-fit flex-col text-sm')}>
      <label className="flex flex-row text-gray-500">
        {required && label && <div className="text-red-500">＊</div>}
        {label}
      </label>
      <div className="relative mt-1">
        <div
          className={twMerge(
            'relative flex w-full cursor-pointer items-center justify-between rounded border border-gray-400 bg-white px-2 py-1 text-left hover:border-black active:border-mit-yellow sm:text-sm',
            disabled &&
              'cursor-not-allowed bg-mit-gray-200 text-gray-500 hover:border-mit-gray-400 active:border-mit-gray-400',
            inputActive && 'border-mit-yellow', // 焦點時邊框顏色
            invalid && (value == undefined || value === '') && 'border-red-500' //Error的提示訊息
          )}
        >
          <input
            type="text"
            name={formName}
            disabled={disabled}
            className={twMerge(
              'w-full border-none text-sm leading-5 text-gray-900 focus:outline-none focus:ring-0 active:border-none',
              disabled && 'cursor-not-allowed text-gray-500'
            )}
            value={value}
            onChange={handleInputChange}
            onFocus={() => setInputActive(true)}
            onBlur={() => setInputActive(false)}
            placeholder={placeholder}
          />
        </div>
        {invalid && (value == undefined || value === '') && (
          <div className="absolute right-0 z-10 text-red-500">This field is required</div>
        )}
      </div>
    </div>
  );
};

export default Input;
