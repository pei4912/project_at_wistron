import SvgIcon from '@/assets/SvgIcon';
import { twMerge } from 'tailwind-merge';

export type IconButtonProps = {
  iconName: string;
  onClick?: () => void;
  iconClass?: string;
  wrapperStyle?: string;
};

const IconButton = ({ iconName, onClick, iconClass, wrapperStyle }: IconButtonProps) => {
  return (
    <button
      onClick={onClick}
      className={twMerge(
        'border-0 bg-transparent shadow-none hover:border-0 hover:bg-transparent focus:outline-0 focus:ring-0 focus:ring-offset-0',
        iconClass
      )}
    >
      <SvgIcon iconName={iconName} wrapperStyle={wrapperStyle} />
    </button>
  );
};

export default IconButton;
