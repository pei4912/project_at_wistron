import { twMerge } from 'tailwind-merge';
import Header from '../header';

type Props = {
  className?: string;
  children: React.ReactNode;
};

export default function PageContainer({ className, children }: Props) {
  return (
    <main className="h-full w-full overflow-hidden bg-mit-gray-100">
      <Header />
      <div className={twMerge('h-[calc(100%-3rem)] overflow-auto', className)}>{children}</div>
    </main>
  );
}
