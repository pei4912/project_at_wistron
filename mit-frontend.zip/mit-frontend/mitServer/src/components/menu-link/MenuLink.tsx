import { ChevronDownIcon, ChevronUpIcon } from '@heroicons/react/24/solid';
import { Icon } from '@tremor/react';
import { Link, useLocation } from 'react-router-dom';
import { twMerge } from 'tailwind-merge';
import SvgIcon from '@/assets/SvgIcon';
import Tooltip from '../tooltip/Tooltip';
import { useAppSelector } from '@/reducer/hooks';

const types = {
  drop: 'flex items-center',
  sub: 'pl-9 pr-3',
  normal: 'px-3',
};
const selectClassName = 'bg-mit-yellow text-mit-gray-900 hover:bg-mit-yellow';
export type MenuButtonProps = {
  path: string;
  children?: React.ReactNode;
  className?: string;
  collapseIcon?: string;
  type?: keyof typeof types;
  onClick?: () => void;
  icon?: any;
  items?: {
    label: string;
    path: string;
  }[];
};

const MenuLink = ({
  path,
  children,
  className,
  collapseIcon = 'up',
  type = 'normal',
  onClick,
  icon,
  items,
}: MenuButtonProps) => {
  const location = useLocation();
  const asideVisible = useAppSelector((state) => state.menu.visible);

  const dropdownSelect = asideVisible
    ? (location.pathname.match(path.split('/')[0]) && collapseIcon === 'up') ||
      (collapseIcon === 'up' && location.pathname === '/' && children === 'Service')
    : location.pathname.match(path.split('/')[0]) || (location.pathname === '/' && children === 'Service');
  const normalSelect = location.pathname.match(path);

  return type === 'drop' ? (
    asideVisible ? (
      <Link
        to={path}
        className={twMerge(
          className,
          types[type],
          !asideVisible ? 'justify-center' : 'justify-between',
          'border-0 py-3 pl-3 pr-3 text-left hover:bg-mit-gray',
          dropdownSelect && selectClassName
        )}
        onClick={onClick}
      >
        <div className={twMerge('flex flex-row items-center', !asideVisible && 'justify-center')}>
          {icon !== undefined && (
            <SvgIcon
              iconName={icon}
              svgProp={{
                fill: `${dropdownSelect ? 'black' : 'white'}`,
                height: '30px',
              }}
            />
          )}
          <div className="ml-3 text-sm">{children}</div>
        </div>
        {collapseIcon === 'up' ? (
          <Icon
            size="sm"
            icon={ChevronDownIcon}
            className={twMerge(
              'bg-transparent text-white',
              (location.pathname.match(path.split('/')[0]) || (location.pathname === '/' && children === 'Service')) &&
                'text-mit-gray-900'
            )}
          />
        ) : (
          <Icon size="sm" icon={ChevronUpIcon} className="text-white" />
        )}
      </Link>
    ) : (
      <div
        className={twMerge(
          className,
          'justify-center',
          'border-0 py-3 pl-3 pr-3 text-left hover:bg-mit-gray',
          dropdownSelect && selectClassName
        )}
      >
        <Tooltip
          interactive
          placement="right-start"
          strategy="absolute"
          className="ml-3 w-44 bg-mit-gray-900 text-mit-white"
          label={({ close }) => (
            <div className="flex flex-col">
              {items?.map((subMenu, i) => (
                <Link
                  key={i}
                  to={`${path.split('/')[0]}/${subMenu.path}`}
                  className={twMerge(
                    className,
                    'border-0 px-3 py-2 text-left hover:bg-mit-gray',
                    (location.pathname.match(subMenu.path) ||
                      (location.pathname === '/' && subMenu.path === 'multi-modal')) &&
                      selectClassName,
                    i === 0 && 'rounded-t-sm',
                    i === items.length - 1 && 'rounded-b-sm'
                  )}
                  onClick={() => close?.()}
                >
                  <div className="text-sm">{subMenu.label}</div>
                </Link>
              ))}
            </div>
          )}
        >
          <div className={twMerge('flex flex-row items-center justify-center')}>
            {icon !== undefined && (
              <SvgIcon
                iconName={icon}
                svgProp={{
                  fill: `${dropdownSelect ? 'black' : 'white'}`,
                  transform: 'scale(1.2)',
                  height: '32px',
                }}
              />
            )}
          </div>
        </Tooltip>
      </div>
    )
  ) : asideVisible ? (
    <Link
      to={path}
      className={twMerge(
        className,
        types[type],
        'border-0 py-4 text-left hover:bg-mit-gray',
        normalSelect && selectClassName
      )}
    >
      <div className={twMerge('flex flex-row items-center', !asideVisible && 'justify-center')}>
        {icon !== undefined && (
          <SvgIcon
            iconName={icon}
            svgProp={{
              fill: `${dropdownSelect ? 'black' : 'white'}`,
              height: '30px',
            }}
          />
        )}
        <div className="ml-3 text-sm">{children}</div>
      </div>
    </Link>
  ) : (
    <div
      className={twMerge(
        className,
        'justify-center',
        'border-0 py-3 pl-3 pr-3 text-left hover:bg-mit-gray',
        dropdownSelect && selectClassName
      )}
    >
      <Tooltip
        interactive
        placement="right"
        strategy="absolute"
        className="ml-3 w-44 bg-mit-gray-900 text-mit-white"
        label={({ close }) => (
          <div className="flex flex-col">
            <Link
              to={path}
              className={twMerge(
                className,
                'rounded-sm border-0 px-3 py-2 hover:bg-mit-gray',
                location.pathname.match(path) && selectClassName
              )}
              onClick={() => close?.()}
            >
              <div className="text-sm">{children}</div>
            </Link>
          </div>
        )}
      >
        <div className={twMerge('flex flex-row items-center justify-center')}>
          {icon !== undefined && (
            <SvgIcon
              iconName={icon}
              svgProp={{
                fill: `${dropdownSelect ? 'black' : 'white'}`,
                transform: 'scale(1.2)',
                height: '32px',
              }}
            />
          )}
        </div>
      </Tooltip>
    </div>
  );
};

export default MenuLink;
