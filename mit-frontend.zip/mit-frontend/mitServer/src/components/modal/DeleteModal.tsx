import { Dialog, Transition } from '@headlessui/react';
import { Fragment, ReactElement } from 'react';
import SvgIcon from '@/assets/SvgIcon';
import { twMerge } from 'tailwind-merge';
import TextButton from '../text-button/TextButton';

const widthTypes = {
  sm: 'w-[600px]',
  md: 'w-[900px]',
  xl: 'w-[1200px]',
};
export type DeleteModalProps = {
  isOpen?: boolean;
  children?: ReactElement | string;
  buttonChildren?: ReactElement;
  isForm?: boolean;
  okButton?: string;
  cancelButton?: string;
  handleOk?: (e: any) => void;
  handleCancel?: () => void;
  width: keyof typeof widthTypes;
};

const DeleteModal = ({
  isOpen = false,
  // title = 'Modal',
  children,
  buttonChildren,
  width,
  isForm = false,
  okButton = 'OK',
  cancelButton = 'Cancel',
  handleOk = () => {},
  handleCancel = () => {},
}: DeleteModalProps) => {
  const handleSubmit = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const formData = new FormData(e.currentTarget);
    const data = Object.fromEntries(formData.entries());
    handleOk(data);
    // handleCancel();
  };

  return (
    <Transition show={isOpen} as={Fragment}>
      <Dialog as="div" className="relative z-10" onClose={() => handleCancel}>
        <Transition.Child
          as={Fragment}
          enter="ease-out duration-300"
          enterFrom="opacity-0"
          enterTo="opacity-100"
          leave="ease-in duration-200"
          leaveFrom="opacity-0"
          leaveTo="opacity-0"
        >
          <div className="fixed inset-0 bg-black bg-opacity-75 " />
        </Transition.Child>

        <div className="fixed inset-0">
          <div className="flex min-h-full items-center justify-center px-4 text-center">
            <Transition.Child
              as={Fragment}
              enter="ease-out duration-300"
              enterFrom="opacity-0 scale-95"
              enterTo="opacity-100 scale-100"
              leave="ease-in duration-200"
              leaveFrom="opacity-100 scale-100"
              leaveTo="opacity-0 scale-95"
            >
              <Dialog.Panel
                className={twMerge(
                  'h-2/5 max-h-screen max-w-[1200px] transform bg-white px-4 text-left align-middle transition-all',
                  widthTypes[width]
                )}
              >
                <div className="my-6 flex justify-center">
                  <SvgIcon iconName="notice-icon" />
                </div>{' '}
                <p className="flex justify-center ">Confirmation</p>
                <p className=" my-4 flex justify-center">Would you like to delete the item?</p>
                {isForm ? (
                  <form onSubmit={handleSubmit}>
                    <div
                      className={'border-t-1 overflow-auto border border-x-0 border-y-mit-gray-400 '}
                      style={{ maxHeight: 'calc(100vh - 128px)' }}
                      id="modal-content"
                    ></div>
                    <div className="flex h-16 items-center justify-center">
                      <TextButton className="mx-2 py-1 px-3" onClick={handleCancel}>
                        {cancelButton}
                      </TextButton>
                      <TextButton type="fill" className="mx-2 py-1 px-3" isFormSubmit={true}>
                        {okButton}
                      </TextButton>
                    </div>
                  </form>
                ) : (
                  <div>
                    <div
                      className={'overflow-auto border border-x-0 border-t-2 border-y-mit-gray-400 pt-6 pb-12'}
                      style={{ maxHeight: 'calc(100vh - 128px)' }}
                      id="modal-content"
                    >
                      {children}
                    </div>

                    <div className="flex h-16 items-center justify-end">{buttonChildren}</div>
                  </div>
                )}
              </Dialog.Panel>
            </Transition.Child>
          </div>
        </div>
      </Dialog>
    </Transition>
  );
};

export default DeleteModal;
