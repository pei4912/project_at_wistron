import { childrenRoutes } from '@/route/routes';
import { Link, useNavigate } from 'react-router-dom';
import useReactRouterBreadcrumbs from 'use-react-router-breadcrumbs';
import IconButton from '../icon-button/IconButton';
import { useAppSelector } from '@/reducer/hooks';
import { setVisible } from '@/reducer/slice/menuSlice';
import useAuth from '@/auth/useAuth';
import Tooltip from '../tooltip/Tooltip';
import { useState } from 'react';
import { store } from '@/reducer/store';
import SvgIcon from '@/assets/SvgIcon';

const Header = () => {
  const userInfo = useAppSelector((state) => state.auth.userProfile);
  const breadcrumbs = useReactRouterBreadcrumbs(childrenRoutes);
  const [language, setLanguage] = useState<string>('English');
  const { logout } = useAuth();
  const navigate = useNavigate();

  return (
    <header className="flex h-12 w-full items-center justify-between border-x-0 border-b border-t-0 border-b-gray-300 bg-gray-300 px-4">
      <div className="flex flex-row items-center">
        <IconButton iconName="aside-button-icon" iconClass="p-2" onClick={() => store.dispatch(setVisible())} />
        {breadcrumbs.map(({ breadcrumb, match }, index) => (
          <div key={match.pathname} className="cursor-default">
            {((breadcrumbs.length > 0 && index !== 0) || breadcrumbs.length === 1) && breadcrumb}
            {index !== 0 && index < breadcrumbs.length - 1 && ' /'}
            &nbsp;
          </div>
        ))}
      </div>
      <div className="flex text-sm">
        <div className="mr-3 cursor-default">{userInfo !== null ? userInfo.mailNickname : 'test@microsoft.com'}</div>
        <div className="cursor-pointer">
          <Tooltip
            interactive
            placement="bottom"
            strategy="absolute"
            className="mt-1.5 w-44 rounded bg-mit-white text-center shadow-[2px_2px_4px_rgba(0,0,0,0.25)]"
            label={({ close }) => (
              <div className="grid cursor-pointer grid-cols-1 py-1.5">
                <Tooltip
                  interactive
                  placement="left-start"
                  strategy="absolute"
                  className="-mr-2 w-44 rounded bg-mit-white text-center shadow-[2px_2px_4px_rgba(0,0,0,0.25)]"
                  label={
                    <div className="mt-2 grid cursor-pointer grid-cols-1 py-1.5 ">
                      <button
                        className={`flex items-center justify-between px-5 py-1 hover:bg-mit-hover-yellow  ${
                          language === 'English' ? 'bg-mit-hover-yellow' : ''
                        }`}
                        // {`p-1 hover:bg-mit-hover-yellow ${language === 'English' ? 'bg-red-500' : ''}`}
                        onClick={() => {
                          setLanguage('English');
                          close?.();
                        }}
                      >
                        English
                        {language === 'English' && (
                          <div>
                            <SvgIcon iconName="select-language-icon" />
                          </div>
                        )}
                      </button>

                      <button
                        className={`flex items-center justify-between px-5 py-1 hover:bg-mit-hover-yellow  ${
                          language === 'Chinese' ? 'bg-mit-hover-yellow' : ''
                        }`}
                        onClick={() => {
                          setLanguage('Chinese');
                          close?.();
                        }}
                      >
                        Chinese
                        {language === 'Chinese' && (
                          <div>
                            <SvgIcon iconName="select-language-icon" />
                          </div>
                        )}
                      </button>
                    </div>
                  }
                >
                  <div className="flex items-center justify-between px-5 py-1 hover:bg-mit-hover-yellow">
                    {language}
                    <div>
                      <SvgIcon iconName="language-chevron-icon" />
                    </div>
                  </div>
                </Tooltip>
                <Link
                  to={'/login'}
                  onClick={() => (localStorage.getItem('auth') ? navigate('login') : logout())}
                  className="flex px-5 py-1 hover:bg-mit-hover-yellow"
                >
                  Log out
                </Link>
              </div>
            )}
          >
            <div>{userInfo !== null ? userInfo.displayName.split('/')[0] : 'test'}</div>
          </Tooltip>
        </div>
      </div>
    </header>
  );
};

export default Header;
