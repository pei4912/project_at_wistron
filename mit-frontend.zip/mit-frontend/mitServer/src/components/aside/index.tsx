import { childrenRoutes } from '@/route/routes';
import MenuLink from '../menu-link/MenuLink';
import CollapseMenu from '../collapse-menu/CollapseMenu';
import { twMerge } from 'tailwind-merge';
import SvgIcon from '@/assets/SvgIcon';
import { useAppSelector } from '@/reducer/hooks';

const Aside = () => {
  const asideVisible = useAppSelector((state) => state.menu.visible);
  const getItems = (subMenu: any[]) => {
    const lastSub: any[] = [];
    subMenu.forEach(
      (subRoute: any) =>
        subRoute.path !== undefined &&
        lastSub.push({
          label: subRoute.breadcrumb,
          path: subRoute.path,
          show: subRoute.show,
        })
    );
    return lastSub;
  };

  return (
    <aside
      className={twMerge(
        'z-10 h-full w-1/6 border border-y-0 border-l-0 border-r-gray-300 bg-mit-gray-900 pb-6 text-white',
        !asideVisible ? 'w-16 min-w-16' : 'w-1/6 min-w-44',
        'flex flex-col justify-between'
      )}
    >
      <div className={twMerge('h-fit bg-mit-black', !asideVisible ? 'py-5' : 'py-6')}>
        {!asideVisible ? (
          <div className="flex justify-center">
            <SvgIcon iconName="mit-logo-icon" />
          </div>
        ) : (
          <div className="text-lg font-extrabold">MIT DEMO</div>
        )}
      </div>
      <div className="flex flex-col">
        {childrenRoutes.map(
          (route, i) =>
            route?.path &&
            (route.children === undefined
              ? route.show !== false && (
                  <MenuLink path={route.path} key={i} type="normal" icon={route.icon}>
                    {route.breadcrumb}
                  </MenuLink>
                )
              : route.children[0]?.breadcrumb && (
                  <CollapseMenu
                    key={i}
                    path={route.path}
                    title={route.children[0].breadcrumb}
                    items={getItems(route.children)}
                    icon={route.icon}
                  />
                ))
        )}
      </div>

      <div className="mt-auto -mb-4 text-sm">Ver. 202004221715.06.46(DEV)</div>
    </aside>
  );
};

export default Aside;
