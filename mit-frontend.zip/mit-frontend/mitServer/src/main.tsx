import React from 'react';
import ReactDOM from 'react-dom/client';
import './index.css';
import { RouterProvider } from 'react-router-dom';
import { router } from './route/Router';
import { Suspense } from 'react';
import { Provider } from 'react-redux';
import { MsalProvider, msalInstance } from './aad';
import { PublicClientApplication } from '@azure/msal-browser';
import { persistor, store } from './reducer/store';
import { PersistGate } from 'redux-persist/integration/react';
import { ApiProvider } from '@reduxjs/toolkit/query/react';
import { appApi } from './api/app';

ReactDOM.createRoot(document.getElementById('root') as HTMLElement).render(
  <React.StrictMode>
    <Provider store={store}>
      <PersistGate loading={null} persistor={persistor}>
        {/* <ApiProvider api={appApi}> */}
        <MsalProvider instance={msalInstance as PublicClientApplication}>
          <Suspense fallback={<>loading...</>}>
            <RouterProvider router={router} />
          </Suspense>
        </MsalProvider>
        {/* </ApiProvider> */}
      </PersistGate>
    </Provider>
  </React.StrictMode>
);
