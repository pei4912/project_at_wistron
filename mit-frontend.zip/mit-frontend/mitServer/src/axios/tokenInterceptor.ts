export default function tokenInterceptor(config: any) {
  const token = localStorage.getItem('graph-access-token');
  if (token) {
    config.headers.Authorization = `Bearer ${token}`;
  }

  return config;
}
