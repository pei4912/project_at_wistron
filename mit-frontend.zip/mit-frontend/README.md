# MIT_DEMO_SERVER

## Prerequisites
 - Node.js package manager: [pnpm](https://pnpm.io/) 

### Tools
 - [Tailwind](https://tailwindcss.com/)
 - [Tremor](https://www.tremor.so/)
 - [Headlessui](https://headlessui.com/)
 - [Floating UI](https://floating-ui.com/)
 - [React Router](https://reactrouter.com/en/main)

### VSCode Extensions
 - [ESLint](https://marketplace.visualstudio.com/items?itemName=dbaeumer.vscode-eslint)
 - [Prettier](https://marketplace.visualstudio.com/items?itemName=esbenp.prettier-vscode)
 - [Editor Config](https://marketplace.visualstudio.com/items?itemName=EditorConfig.EditorConfig)
 - [Tailwind CSS IntelliSense](https://marketplace.visualstudio.com/items?itemName=bradlc.vscode-tailwindcss)
 - [Code Spell Checker](https://marketplace.visualstudio.com/items?itemName=streetsidesoftware.code-spell-checker)

## Started

### Setup frontend

```bash
git clone https://{username}:{gitlab-accesstoken}@gitlab.devpack.cc/mit_demo_server/frontend.git
cd frontend/mitServer
pnpm i
pnpm dev // or pnpm start
```