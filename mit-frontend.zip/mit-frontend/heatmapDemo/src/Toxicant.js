import React, { useState, useEffect, useRef } from 'react';
import logo from './logo.png';
import openfile from './toxin_demo-2.csv'
import Papa from 'papaparse';
import "../node_modules/bootstrap/dist/css/bootstrap.min.css";
import { Navbar, Row, Col, Container, Button, Table, FormGroup, FormControl } from 'react-bootstrap';
import NavbarCollapse from 'react-bootstrap/esm/NavbarCollapse';

function Toxicant() {
    // 直接讀檔案
    // State to store parsed data
    const elementRef = useRef(null);
    const sortable = [];
    const [resultData, setResult] = useState([]);

    const [parsedData, setParsedData] = useState([]);

    //State to store table Column name
    const [tableRows, setTableRows] = useState([]);

    //State to store the values
    const [values, setValues] = useState([]);

    const [selectedData, setSelectedData] = useState(false);

    const [isLoading, setIsLoading] = useState(false);

    const [apiDuration, setApiDuration] = useState(null);

    useEffect(() => {
        const fetchParseData = async () => {
            Papa.parse(openfile, {
                download: true,
                header: true,
                complete: function (input) {
                    const rowsArray = [];
                    const valuesArray = [];


                    // Iterating data to get column name and their values
                    input.data.map((d) => {
                        rowsArray.push(Object.keys(d));
                        valuesArray.push(Object.values(d));
                    });

                    // Parsed Data Response in array format
                    setParsedData(input.data);

                    // Filtered Column Names
                    setTableRows(rowsArray[0]);

                    // Filtered Values
                    setValues(valuesArray);
                }
            });
        }
        fetchParseData()
        if (selectedData) {
            elementRef.current.innerHTML = 'loading...';
            fetch('http://10.31.98.181:5513', {
                method: 'POST',
                body: JSON.stringify({
                    "content": selectedData
                }),
                headers: {
                    "Content-Type": "application/json",
                },
            })
                .then((response2) => response2.text())
                .then((data2) => {
                    if (elementRef.current) {
                        elementRef.current.innerHTML = data2;
                    }

                })
                .catch((err) => {
                    console.log(err.message);
                });


            const start = window.performance.now();
            setApiDuration(null);
            setIsLoading(true)
            fetch('http://10.31.98.181:5512', {
                method: 'POST',
                body: JSON.stringify({
                    "content": selectedData
                }),
                headers: {
                    "Content-Type": "application/json",
                },
            })
                .then((response) => response.json())
                .then((data) => {
                    setIsLoading(false)
                    const end = window.performance.now();
                    setApiDuration((end - start) / 1000);
                    let result = data[0]
                    console.log(data[0]);

                    for (var toxin in result) {
                        sortable.push([toxin, result[toxin]])

                    }
                    sortable.sort(function (a, b) {
                        return b[1] - a[1];
                    })
                    setResult(sortable);
                })
                .catch((err) => {
                    console.log(err.message);
                });

        }
    }, [selectedData]);

    const handleSelect = (index) => {
        setValues(prevState => {
            const newData = [...prevState];
            newData.forEach(item => item.selected = false);
            newData[index].selected = true;
            setSelectedData(newData[index][1])
            return newData;
        });
    }

   


    return (
        <div>
            <Navbar className="navbar-expand-md navbar-dark fixed-top" style={{ background: 'rgb(63, 150, 182)' }}>
                <div style={{ width: '10%', height: '100%' }}>
                    <a className="navbar-brand" href="/index">
                        <img src={logo} alt="logo" width="100%" height="100%" />
                    </a>
                </div>
                <NavbarCollapse id="navbarCollapse">
                    <h2 style={{ paddingLeft: '30px', marginTop: '10px', fontFamily: 'Arial, Helvetica, sans-serif', color: 'white' }}>
                        {/* TextHeatmap-Demo */}
                    </h2>
                </NavbarCollapse>
            </Navbar >
            <Container fluid style={{ height: '100%', color: 'white' }}>
                <Row style={{ paddingTop: '7%' }} >
                    <Col xs='4'>
                        <h4 style={{ paddinfRight: '4%' }}><b>Toxicant Kaggle</b></h4>
                        <Button variant='warning' >毒物</Button>
                        <Button border variant='warning' className='m-2'>公開資料</Button>
                        <div style={{ paddingTop: '2%', overflowY: 'scroll', height: '800px' }}>
                            <Table hover bordered style={{ border: '#fff' }}>
                                <thead >
                                    {/* <tr>
                                        <th>case_id</th>
                                        <th>combined_r</th>
                                    </tr> */}
                                    <tr>
                                        <th></th>
                                        {tableRows.map((rows, index) => {
                                            return <th key={index}>{rows}</th>;
                                        })}
                                    </tr>
                                </thead>
                                <tbody>
                                    {/* <tr>
                                        <td>20131042</td>
                                        <td>Blurred vision視力模糊|Slurred speech言語不清 body temperature:normal AST(GOT) U/L|其他 Clr?: |ALT(GPT) U/L|WBC /uL 職業: 種番茄 中午喝 ml，進ER，住院 Blurred vision 手無法定位 Slurred speech HF hydration 中 / : 左右自行服用固殺草ml，經急診住院 / : 病房醫師詢問blurred vision / 雙手無法定位 / slurred speech, EVM / 早上仍嗜睡，可喚醒，約八點多一口痰卡住，cyanosis，intubation，住加護病房中</td>
                                    </tr> */}
                                    {values.map((value, index) => {
                                        return (
                                            <tr key={index}>
                                                <td>
                                                    <Button variant='light' onClick={() => handleSelect(index)} disabled={value.selected}>
                                                        選擇   {/* {value.selected ? "取消選擇" : "選擇"} */}
                                                    </Button>
                                                </td>
                                                {/* <td><Button variant='light'>選擇</Button></td> */}
                                                {value.map((val, i) => {
                                                    return <td key={i}>{val}</td>;
                                                })}
                                            </tr>
                                        );
                                    })}
                                </tbody>


                            </Table>
                        </div>
                    </Col>
                    <Col xs='4'>
                        <FormGroup>
                            <h4><b>Heatmap Result</b></h4>
                            <div className='form-control content' id='content' ref={elementRef} style={{ height: '400px' }}></div>
                            <br></br>
                            <h5><label for="top_k">Number of Prediction</label></h5>
                            <FormControl type='number' defaultValue={5} id='top_k' min='2' max='20'></FormControl>
                        </FormGroup>
                        <Button variant='primary' className='mt-3'>Submit</Button>
                    </Col>
                    <Col xs='4'>
                        <h4><b>Predict Result:</b></h4>
                        {apiDuration && <p>本次運算時間：{apiDuration.toFixed()} 秒</p>}
                        {/* <p className='d-inline-block'>本次運算時間:</p> */}
                        <Table>
                            <thead>
                                <tr>

                                    <th scope='col'>Rank</th>
                                    <th scope='col'>農藥類別</th>
                                    <th scope='col'>農藥機率</th>
                                </tr>
                            </thead>
                            {/* <tbody> */}
                            {isLoading ? (
                                <div>Loading...</div>
                            ) : (
                                <tbody>
                                    {resultData.map((result, index) => {
                                        return (
                                            <tr key={index}>
                                                <p>{index + 1}</p>
                                                {result.map((res, i) => {
                                                    return <td key={i}>{res}</td>;
                                                })}
                                            </tr>
                                        );
                                    })}
                                </tbody>
                            )}
                            {/* </tbody> */}
                        </Table>
                    </Col>
                </Row>
            </Container>

        </div >
    );
}

export default Toxicant;