import { useState } from 'react';

function App() {
  const [selectedData, setSelectedData] = useState([]);

  const handleSelect = (event) => {

    const selectedValue = event.target.value;
    if (selectedValue !== '') {
      setSelectedData([...selectedData, selectedValue]);
      console.log(selectedValue)
    }
  };

  return (
    <div>
      <select onChange={handleSelect}>
        <option value="">請選擇</option>
        <option value="option1">選項1</option>
        <option value="option2">選項2</option>
        <option value="option3">選項3</option>
      </select>
      <p>你選擇了：{selectedData.join(', ')}</p>
    </div>
  );
}

export default App;