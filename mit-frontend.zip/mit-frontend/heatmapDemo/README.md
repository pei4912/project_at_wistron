# Heatmap Demo

## Started

### Setup frontend
```bash
npm install
npm start // or npm run start
```

## Site
http://10.31.98.181:5510/