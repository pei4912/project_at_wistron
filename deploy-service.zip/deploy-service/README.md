# 部署AOI-GEN服務

## 透過Gitlab CI/CD部署
### Build -> Pipelines -> Run pipeline -> 輸入Variable
- DEPLOY:
    1. ~~DEV: 部署`dev branch`至[dev server](http://10.31.98.159:3000)~~
    2. QAS: 部署`qas branch`至[qas server](http://10.34.40.126:3000)
    3. PRD: 部署`prd branch`至[prd server](http://10.34.40.127:3000)
- BUILD_ON: LOCAL

## 透過Shell Script部署
### 1. git clone所有submodules
```
git config --global submodule.recurse true .git/config
git submodule update --init --recursive
git pull
```

### 2-1. 建立docker images並部署所有服務
- 需將.env放入`deploy-service/aoi-gen-frontend/.env`
- 必要檔案:
    1. `aoi-gen-backend`
    2. `aoi-gen-frontend`
    3. `aoi-gen-train`
    4. `aoi-gen-frontend/.env`
```
bash run_aoi-gen-build.sh
```

### 2-2. 讀取docker images並部署所有服務
- 需將.env放入`deploy-service/.env`
- 必要檔案:
    1. `docker-compose.yaml`
    2. `.env`
    3. `aoi-gen-backend.tar`
    4. `aoi-gen-frontend.tar`
    5. `aoi-gen-train.tar`
```
bash run_aoi-gen.sh
```

---
### Scripts說明
-  `run_aoi-gen-build.sh`
    1. 更新最新版本程式碼
    2. 重新build docker image
    3. 啟動服務
    4. 儲存docker image(.tar) (需使用到`save_docker_images.sh`)
-   `run_aoi-gen.sh`
    1. 讀取docker image(.tar)
    2. 啟動服務
    3. 儲存docker compose logs至logs資料夾 (需使用到`save_logs.sh`)
-   `save_docker_images.sh`
    1. 刪除資料夾下的docker image(.tar)
    2. 重新儲存docker image(.tar)
-  `save_logs.sh`
    1. 儲存docker compose logs
