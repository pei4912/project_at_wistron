#! /bin/bash

# time stamp
TIMESTAMP=$(date +"%Y-%m-%d_%H-%M-%S")

# log path
LOG_FILE="./logs/docker-compose-logs-$TIMESTAMP.log"

# save 
docker compose logs > $LOG_FILE

# remove old logs
find ./logs/ -type f -mtime +7 -name "docker-compose-logs-\*.log" -exec rm {} \;
