#! /bin/bash

# check build which branch
read -p "Deploy? Enter prd/qas/dev [prd]: " deploy_type
: ${deploy_type:="prd"}
if [ "$deploy_type" == "prd" ]; then
   branch="main"
elif [ "$deploy_type" == "qas" ] || [ "$deploy_type" == "dev" ]; then
   branch="dev"
fi
# check save images to local or not
read -p "Save docker images? Enter yes/no [yes]: " save_images
: ${save_images:="yes"}

# start backend services
cd aoi-gen-backend && \
   git checkout $branch && \
   git pull && \
   docker compose up -d --build;
cd ..;
# start frontend services
cd aoi-gen-frontend && \
   git checkout $branch && \
   git pull && \
   docker compose up -d --build;
cd ..;
# start training services
cd aoi-gen-train && \
   git checkout $branch && \
   git pull && \
   docker compose up -d --build;
cd ..;

# save docker images
if [ "$save_images" == "yes" ]
then
   bash save_docker_images.sh;
fi
