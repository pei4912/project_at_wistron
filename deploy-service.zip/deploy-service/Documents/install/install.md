# 安裝說明
1. 下載[安裝用資料夾](https://wistron-my.sharepoint.com/personal/leo_zy_lin_wistron_com/_layouts/15/onedrive.aspx?csf=1&web=1&e=hV0UKq&cid=72ec836a%2D8b96%2D4aa2%2Dac0f%2Dd1ef277c74ac&FolderCTID=0x01200016CD243B4987F341BEDED65729E2D801&id=%2Fpersonal%2Fleo%5Fzy%5Flin%5Fwistron%5Fcom%2FDocuments%2Fp8%20AOI%20dataset)
![download](./images/download.png)
![download-2](./images/download-2.png)

2. 到下載資料夾並打開Terminal
```
CTRL + ALT + T
```

3. 解壓縮`安裝用資料夾`, 指令:
```bash
unzip deploy-service.zip
```
![unzip](./images/unzip.png)

4. 進入`安裝用資料夾`, 指令:
```bash
cd deploy-service
```
![cd](./images/cd.png)

5. 執行安裝指令, 並輸入linux登入密碼:
```bash
sudo bash run_aoi-gen.sh
```
![run](./images/run.png)
