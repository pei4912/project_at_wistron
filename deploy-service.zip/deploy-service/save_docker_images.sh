#! /bin/bash

# save backend images
fileName="aoi-gen-backend.tar"
if [ -e $fileName ]
then
    rm $fileName
fi
docker save aoi-gen-backend-general_method aoi-gen-backend-voxelmorph aoi-gen-backend-random_deform aoi-gen-backend-surface_defect > $fileName
# save frontend images
fileName="aoi-gen-frontend.tar"
if [ -e $fileName ]
then
    rm $fileName
fi
docker save aoi-gen-frontend > $fileName
# save train images
fileName="aoi-gen-train.tar"
if [ -e $fileName ]
then
    rm $fileName
fi
docker save aoi-gen-train-app_voxel aoi-gen-train-app_random_deform aoi-gen-train-app_opt  > $fileName
