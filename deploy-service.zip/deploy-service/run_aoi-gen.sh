#! /bin/bash

# install git
apt update -y
apt upgrade -y
apt install -y git

# change nginx settings
apt update -y
apt-get install -y nginx
mkdir -p /etc/nginx/sites-available/
cp nginx-settings /etc/nginx/sites-available/default
systemctl restart nginx

#uninstall nvidia-driver
apt --purge remove -y "*nvidia*${DRIVER_BRANCH}*"

# uninstall docker
for pkg in docker.io docker-doc docker-compose docker-compose-v2 podman-docker containerd runc; do sudo apt -y remove $pkg; done

#uninstall docker and old images completely
apt purge -y docker-engine docker docker.io docker-ce
apt autoremove -y --purge docker-engine docker docker.io docker-ce
rm -rf /var/lib/docker /etc/docker
rm /etc/apparmor.d/docker
groupdel docker
rm -rf /var/run/docker.sock
rm -rf /usr/bin/docker-compose
rm -rf /var/lib/containerd
rm -r ~/.docker
rm -rf /usr/local/bin/docker-compose
rm -rf /etc/docker
rm /usr/share/keyrings/docker-archive-keyring.gpg

#remove nv docker
rm /usr/share/keyrings/nvidia-container-toolkit-keyring.gpg
apt remove -y nvidia-container-toolkit

# install nvidia-driver
add-apt-repository -y ppa:graphics-drivers/ppa
apt update -y
ubuntu-drivers list
apt install -y nvidia-driver-535

# install docker
apt-get -y update
apt-get install -y ca-certificates curl
install -m 0755 -d /etc/apt/keyrings
curl -fsSL https://download.docker.com/linux/ubuntu/gpg -o /etc/apt/keyrings/docker.asc
chmod a+r /etc/apt/keyrings/docker.asc

# Add the repository to Apt sources:
echo \
    "deb [arch=$(dpkg --print-architecture) signed-by=/etc/apt/keyrings/docker.asc] https://download.docker.com/linux/ubuntu \
    $(. /etc/os-release && echo "$VERSION_CODENAME") stable" | \
    sudo tee /etc/apt/sources.list.d/docker.list > /dev/null
apt-get -y update
apt-get -y install docker-ce docker-ce-cli containerd.io docker-buildx-plugin docker-compose-plugin

# install NV docker
curl -fsSL https://nvidia.github.io/libnvidia-container/gpgkey | sudo gpg --dearmor -o /usr/share/keyrings/nvidia-container-toolkit-keyring.gpg \
    && curl -s -L https://nvidia.github.io/libnvidia-container/stable/deb/nvidia-container-toolkit.list | \
    sed 's#deb https://#deb [signed-by=/usr/share/keyrings/nvidia-container-toolkit-keyring.gpg] https://#g' | \
    sudo tee /etc/apt/sources.list.d/nvidia-container-toolkit.list
apt-get -y update
apt-get install -y nvidia-container-toolkit
nvidia-ctk runtime configure --runtime=docker

# restart docker
chmod 666 /var/run/docker.sock
systemctl restart docker

# load backend images
docker load -i aoi-gen-backend.tar;
# load frontend images
docker load -i aoi-gen-frontend.tar;
# load train images
docker load -i aoi-gen-train.tar;
# start service
docker compose up -d;

# add cronjob to save logs
mkdir -p logs | chmod -R 775 logs;
chmod +x save_logs.sh;
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)";
CRON_JOB="0 0 * * * /bin/bash $SCRIPT_DIR/save_logs.sh";
(echo "$CRON_JOB") | crontab -;
service cron restart;

# reboot to activate nvidia driver
reboot
